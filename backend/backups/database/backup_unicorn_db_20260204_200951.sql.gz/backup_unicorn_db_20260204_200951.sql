--
-- PostgreSQL database dump
--

\restrict BIvEkEgXBMpf9W9R7TpA72ups0jyrq2NrvTSGgDUXhXmV5R2FSShuSy2OtUdbvc

-- Dumped from database version 16.11
-- Dumped by pg_dump version 17.7 (Debian 17.7-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: invitationstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invitationstatus AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED'
);


--
-- Name: migrationstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.migrationstatus AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED',
    'ROLLED_BACK'
);


--
-- Name: organizationmemberrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.organizationmemberrole AS ENUM (
    'OWNER',
    'ADMIN',
    'MEMBER',
    'VIEWER'
);


--
-- Name: cleanup_expired_saml_sessions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_expired_saml_sessions() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    UPDATE saml_sessions
    SET is_active = false,
        logout_at = NOW()
    WHERE is_active = true
    AND (
        session_expiry < NOW()
        OR not_on_or_after < NOW()
    );
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


--
-- Name: FUNCTION cleanup_expired_saml_sessions(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cleanup_expired_saml_sessions() IS 'Deactivate expired SAML sessions';


--
-- Name: update_model_lists_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_model_lists_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_organization_branding_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_organization_branding_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: add_on_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.add_on_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    icon character varying(255),
    display_order integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: add_on_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.add_on_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: add_on_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.add_on_categories_id_seq OWNED BY public.add_on_categories.id;


--
-- Name: add_on_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.add_on_purchases (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    add_on_id integer NOT NULL,
    stripe_session_id character varying(255),
    stripe_payment_intent_id character varying(255),
    amount_paid numeric(10,2) NOT NULL,
    currency character varying(3),
    status character varying(50),
    promo_code character varying(100),
    discount_amount numeric(10,2),
    features_granted jsonb,
    activated_at timestamp without time zone,
    expires_at timestamp without time zone,
    refunded_at timestamp without time zone,
    refund_reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: add_on_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.add_on_purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: add_on_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.add_on_purchases_id_seq OWNED BY public.add_on_purchases.id;


--
-- Name: add_on_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.add_on_reviews (
    id integer NOT NULL,
    add_on_id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_purchase boolean,
    helpful_count integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: add_on_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.add_on_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: add_on_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.add_on_reviews_id_seq OWNED BY public.add_on_reviews.id;


--
-- Name: add_ons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.add_ons (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    long_description text,
    category_id integer,
    base_price numeric(10,2) NOT NULL,
    currency character varying(3),
    stripe_product_id character varying(255),
    stripe_price_id character varying(255),
    version character varying(50),
    author character varying(255),
    icon_url character varying(500),
    screenshot_urls jsonb,
    features jsonb,
    requirements jsonb,
    compatibility jsonb,
    download_url character varying(500),
    documentation_url character varying(500),
    is_active boolean,
    is_featured boolean,
    install_count integer,
    rating numeric(3,2),
    review_count integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    category text DEFAULT 'general'::text,
    launch_url text,
    feature_key text,
    billing_type text DEFAULT 'monthly'::text,
    metadata jsonb DEFAULT '{}'::jsonb,
    banner_url text,
    support_url text,
    trial_days integer DEFAULT 0,
    is_public boolean DEFAULT true,
    sort_order integer DEFAULT 0
);


--
-- Name: add_ons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.add_ons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: add_ons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.add_ons_id_seq OWNED BY public.add_ons.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alert_correlations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_correlations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    correlation_group_id uuid NOT NULL,
    alert_id uuid NOT NULL,
    is_root_cause boolean DEFAULT false NOT NULL,
    correlation_score double precision,
    correlation_type character varying(50),
    detected_at timestamp with time zone DEFAULT now(),
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: alert_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id uuid NOT NULL,
    user_id uuid NOT NULL,
    feedback_type character varying(50) NOT NULL,
    rating integer,
    comment text,
    action_taken character varying(100),
    time_to_acknowledge_seconds integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: alert_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_predictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid NOT NULL,
    metric_name character varying(100) NOT NULL,
    prediction_type character varying(50) NOT NULL,
    predicted_at timestamp with time zone DEFAULT now(),
    will_occur_at timestamp with time zone NOT NULL,
    confidence double precision NOT NULL,
    current_value double precision,
    predicted_value double precision,
    threshold_value double precision,
    time_to_critical_minutes integer,
    recommendation text,
    alert_id uuid,
    actually_occurred boolean,
    accuracy_score double precision,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: alert_suppression_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_suppression_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    rule_type character varying(50) NOT NULL,
    conditions jsonb NOT NULL,
    action character varying(50) DEFAULT 'suppress'::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    organization_id character varying(255),
    created_by uuid,
    alerts_suppressed integer DEFAULT 0 NOT NULL,
    last_matched_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


--
-- Name: anomaly_detections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anomaly_detections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid NOT NULL,
    metric_name character varying(100) NOT NULL,
    detected_at timestamp with time zone DEFAULT now(),
    metric_value double precision NOT NULL,
    expected_value double precision,
    expected_range_min double precision,
    expected_range_max double precision,
    anomaly_score double precision NOT NULL,
    model_id uuid,
    model_type character varying(50),
    confidence double precision,
    severity character varying(20),
    alert_id uuid,
    false_positive boolean,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(20) NOT NULL,
    email character varying(255) NOT NULL,
    subscription_id integer,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    revoked_at timestamp without time zone,
    revoked_reason text,
    rate_limit_per_minute integer,
    rate_limit_per_hour integer,
    rate_limit_per_day integer,
    monthly_quota integer,
    scopes jsonb DEFAULT '["all"]'::jsonb,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone,
    total_requests bigint DEFAULT 0 NOT NULL,
    metadata jsonb
);


--
-- Name: TABLE api_keys; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.api_keys IS 'API keys for programmatic access with usage tracking';


--
-- Name: COLUMN api_keys.key_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.key_hash IS 'SHA-256 hash of the API key for secure storage';


--
-- Name: COLUMN api_keys.key_prefix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.key_prefix IS 'First 8 characters for user identification (e.g., sk_live_abcd1234)';


--
-- Name: COLUMN api_keys.scopes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.scopes IS 'Permission scopes for API key (for future fine-grained access control)';


--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: app_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_definitions (
    id integer NOT NULL,
    app_key character varying(100) NOT NULL,
    app_name character varying(255) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: app_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_definitions_id_seq OWNED BY public.app_definitions.id;


--
-- Name: app_model_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_model_list_items (
    id integer NOT NULL,
    list_id integer NOT NULL,
    model_id character varying(255) NOT NULL,
    display_name character varying(255),
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    sort_order integer DEFAULT 0,
    is_free boolean DEFAULT false,
    context_length integer,
    tier_trial boolean DEFAULT true,
    tier_starter boolean DEFAULT true,
    tier_professional boolean DEFAULT true,
    tier_enterprise boolean DEFAULT true,
    tier_vip_founder boolean DEFAULT true,
    tier_byok boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_featured boolean DEFAULT false,
    is_active boolean DEFAULT true,
    metadata jsonb
);


--
-- Name: TABLE app_model_list_items; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.app_model_list_items IS 'Models included in each curated list with tier access control';


--
-- Name: COLUMN app_model_list_items.tier_trial; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.app_model_list_items.tier_trial IS 'Can Trial tier users see this model?';


--
-- Name: COLUMN app_model_list_items.tier_starter; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.app_model_list_items.tier_starter IS 'Can Starter tier users see this model?';


--
-- Name: COLUMN app_model_list_items.tier_professional; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.app_model_list_items.tier_professional IS 'Can Professional tier users see this model?';


--
-- Name: COLUMN app_model_list_items.tier_enterprise; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.app_model_list_items.tier_enterprise IS 'Can Enterprise tier users see this model?';


--
-- Name: COLUMN app_model_list_items.tier_vip_founder; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.app_model_list_items.tier_vip_founder IS 'Can VIP Founder tier users see this model?';


--
-- Name: COLUMN app_model_list_items.tier_byok; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.app_model_list_items.tier_byok IS 'Can BYOK tier users see this model?';


--
-- Name: app_model_list_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_model_list_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_model_list_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_model_list_items_id_seq OWNED BY public.app_model_list_items.id;


--
-- Name: app_model_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_model_lists (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    app_identifier character varying(100),
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255)
);


--
-- Name: TABLE app_model_lists; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.app_model_lists IS 'Stores app-specific curated model list definitions';


--
-- Name: app_model_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_model_lists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_model_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_model_lists_id_seq OWNED BY public.app_model_lists.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id character varying(36) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    user_id character varying(255),
    organization_id character varying(36),
    action character varying(255) NOT NULL,
    resource_type character varying(100),
    resource_id character varying(255),
    details json,
    ip_address character varying(45),
    user_agent text,
    status character varying(50),
    metadata_json json
);


--
-- Name: branding_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_assets (
    id integer NOT NULL,
    org_id character varying(100) NOT NULL,
    asset_type character varying(50) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer,
    mime_type character varying(100),
    width integer,
    height integer,
    is_active boolean DEFAULT true,
    uploaded_at timestamp with time zone DEFAULT now(),
    uploaded_by character varying(255)
);


--
-- Name: TABLE branding_assets; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.branding_assets IS 'Uploaded branding assets (logos, favicons, etc.)';


--
-- Name: branding_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branding_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branding_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branding_assets_id_seq OWNED BY public.branding_assets.id;


--
-- Name: branding_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_audit_log (
    id integer NOT NULL,
    org_id character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    changes jsonb,
    performed_by character varying(255),
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE branding_audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.branding_audit_log IS 'Audit trail for branding configuration changes';


--
-- Name: branding_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branding_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branding_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branding_audit_log_id_seq OWNED BY public.branding_audit_log.id;


--
-- Name: branding_tier_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_tier_limits (
    id integer NOT NULL,
    tier_code character varying(50) NOT NULL,
    max_logo_size_mb numeric(5,2) DEFAULT 2.0,
    max_assets integer DEFAULT 5,
    custom_colors boolean DEFAULT false,
    custom_fonts boolean DEFAULT false,
    custom_domain boolean DEFAULT false,
    custom_email_branding boolean DEFAULT false,
    remove_powered_by boolean DEFAULT false,
    custom_login_page boolean DEFAULT false,
    custom_css boolean DEFAULT false,
    api_white_label boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE branding_tier_limits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.branding_tier_limits IS 'Branding feature limits per subscription tier';


--
-- Name: branding_tier_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branding_tier_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branding_tier_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branding_tier_limits_id_seq OWNED BY public.branding_tier_limits.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id character varying(36) DEFAULT replace((gen_random_uuid())::text, '-'::text, ''::text) NOT NULL,
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    budget_type character varying(50) NOT NULL,
    total_limit numeric(12,2) NOT NULL,
    warning_threshold numeric(5,4) DEFAULT 0.8 NOT NULL,
    critical_threshold numeric(5,4) DEFAULT 0.95 NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    current_spend numeric(12,6) DEFAULT 0 NOT NULL,
    last_calculated_at timestamp without time zone,
    alert_enabled boolean DEFAULT true,
    alert_contacts jsonb,
    last_alert_sent timestamp without time zone,
    alert_level character varying(20),
    is_active boolean DEFAULT true,
    created_by character varying(36),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT budgets_threshold_check CHECK (((warning_threshold < critical_threshold) AND (critical_threshold <= 1.0)))
);


--
-- Name: byok_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.byok_keys (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    key_name character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    encrypted_key text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_tested_at timestamp without time zone,
    is_valid boolean
);


--
-- Name: TABLE byok_keys; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.byok_keys IS 'Encrypted API keys for BYOK (Bring Your Own Key) feature';


--
-- Name: COLUMN byok_keys.provider; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.byok_keys.provider IS 'API provider: openai, anthropic, huggingface, cohere, replicate, custom';


--
-- Name: COLUMN byok_keys.encrypted_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.byok_keys.encrypted_key IS 'Fernet-encrypted API key';


--
-- Name: byok_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.byok_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: byok_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.byok_keys_id_seq OWNED BY public.byok_keys.id;


--
-- Name: byok_pricing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.byok_pricing_rules (
    id integer NOT NULL,
    model_pattern character varying(255) NOT NULL,
    markup_percentage numeric(5,2) DEFAULT 20.00 NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: byok_pricing_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.byok_pricing_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: byok_pricing_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.byok_pricing_rules_id_seq OWNED BY public.byok_pricing_rules.id;


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_items (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    add_on_id integer NOT NULL,
    quantity integer,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cart_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cart_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cart_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cart_items_id_seq OWNED BY public.cart_items.id;


--
-- Name: cloud_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloud_credentials (
    credential_id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    provider text NOT NULL,
    credentials jsonb NOT NULL,
    region text,
    description text,
    created_by text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp without time zone,
    is_default boolean DEFAULT false
);


--
-- Name: TABLE cloud_credentials; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cloud_credentials IS 'Cloud provider credentials for Terraform';


--
-- Name: cloudflare_dns_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloudflare_dns_records (
    id character varying(36) NOT NULL,
    zone_id character varying(255) NOT NULL,
    record_id character varying(255) NOT NULL,
    record_type character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    content text NOT NULL,
    proxied boolean,
    ttl integer,
    priority integer,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cloudflare_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloudflare_domains (
    id character varying(36) NOT NULL,
    domain_name character varying(255) NOT NULL,
    domain_id character varying(255),
    user_id character varying(255) NOT NULL,
    zone_id character varying(255),
    registration_date timestamp without time zone,
    expiration_date timestamp without time zone,
    auto_renew boolean,
    is_locked boolean,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cloudflare_firewall_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloudflare_firewall_rules (
    id character varying(36) NOT NULL,
    zone_id character varying(255) NOT NULL,
    rule_id character varying(255) NOT NULL,
    rule_name character varying(255) NOT NULL,
    expression text NOT NULL,
    action character varying(50) NOT NULL,
    enabled boolean,
    priority integer,
    description text,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cloudflare_zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloudflare_zones (
    id character varying(36) NOT NULL,
    zone_id character varying(255) NOT NULL,
    zone_name character varying(255) NOT NULL,
    account_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    name_servers json,
    created_on timestamp without time zone,
    modified_on timestamp without time zone,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: compliance_controls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_controls (
    id integer NOT NULL,
    control_id character varying(50) NOT NULL,
    category character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    implementation_status character varying(50) DEFAULT 'not_implemented'::character varying,
    automated boolean DEFAULT false,
    check_frequency character varying(50),
    last_check_at timestamp without time zone,
    last_check_status character varying(50),
    last_check_result jsonb,
    evidence_required text[],
    assigned_to character varying(255),
    target_completion_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE compliance_controls; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.compliance_controls IS 'SOC2 compliance controls and their implementation status';


--
-- Name: compliance_controls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_controls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_controls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_controls_id_seq OWNED BY public.compliance_controls.id;


--
-- Name: compliance_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_evidence (
    id integer NOT NULL,
    evidence_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    control_id character varying(50),
    evidence_type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    collected_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    collected_by character varying(255),
    collection_method character varying(50),
    data jsonb,
    file_path text,
    file_hash character varying(64),
    retention_period_days integer DEFAULT 2555,
    expires_at timestamp without time zone,
    tags text[],
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE compliance_evidence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.compliance_evidence IS 'Evidence collected for SOC2 compliance audits';


--
-- Name: compliance_evidence_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_evidence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_evidence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_evidence_id_seq OWNED BY public.compliance_evidence.id;


--
-- Name: compliance_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_metrics (
    id integer NOT NULL,
    metric_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_category character varying(50),
    metric_value numeric,
    metric_unit character varying(50),
    threshold_warning numeric,
    threshold_critical numeric,
    status character varying(50),
    dimensions jsonb,
    collected_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE compliance_metrics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.compliance_metrics IS 'Time-series compliance metrics for monitoring';


--
-- Name: compliance_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_metrics_id_seq OWNED BY public.compliance_metrics.id;


--
-- Name: compliance_overview; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.compliance_overview AS
 SELECT category,
    count(*) AS total_controls,
    count(*) FILTER (WHERE ((implementation_status)::text = 'implemented'::text)) AS implemented,
    count(*) FILTER (WHERE ((implementation_status)::text = 'verified'::text)) AS verified,
    count(*) FILTER (WHERE ((implementation_status)::text = 'in_progress'::text)) AS in_progress,
    count(*) FILTER (WHERE ((implementation_status)::text = 'not_implemented'::text)) AS not_implemented,
    count(*) FILTER (WHERE (automated = true)) AS automated_controls,
    count(*) FILTER (WHERE ((last_check_status)::text = 'passed'::text)) AS checks_passed,
    count(*) FILTER (WHERE ((last_check_status)::text = 'failed'::text)) AS checks_failed,
    count(*) FILTER (WHERE ((last_check_status)::text = 'warning'::text)) AS checks_warning
   FROM public.compliance_controls
  GROUP BY category;


--
-- Name: VIEW compliance_overview; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.compliance_overview IS 'Compliance status overview by category';


--
-- Name: compliance_readiness_score; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.compliance_readiness_score AS
 SELECT round((((count(*) FILTER (WHERE ((implementation_status)::text = ANY ((ARRAY['implemented'::character varying, 'verified'::character varying])::text[]))))::numeric / (count(*))::numeric) * (100)::numeric), 2) AS overall_readiness_percentage,
    count(*) AS total_controls,
    count(*) FILTER (WHERE ((implementation_status)::text = ANY ((ARRAY['implemented'::character varying, 'verified'::character varying])::text[]))) AS controls_ready,
    count(*) FILTER (WHERE ((automated = true) AND ((last_check_status)::text = 'passed'::text))) AS automated_checks_passed,
    count(*) FILTER (WHERE (automated = true)) AS total_automated_checks
   FROM public.compliance_controls;


--
-- Name: VIEW compliance_readiness_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.compliance_readiness_score IS 'Overall SOC2 readiness score';


--
-- Name: compliance_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_reports (
    id integer NOT NULL,
    report_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    period_start date NOT NULL,
    period_end date NOT NULL,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    generated_by character varying(255),
    format character varying(20) DEFAULT 'pdf'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying,
    file_path text,
    file_size_bytes bigint,
    findings_summary jsonb,
    controls_passed integer,
    controls_failed integer,
    controls_warning integer,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE compliance_reports; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.compliance_reports IS 'Generated SOC2 compliance reports';


--
-- Name: compliance_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_reports_id_seq OWNED BY public.compliance_reports.id;


--
-- Name: compliance_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_schedules (
    id integer NOT NULL,
    schedule_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    control_id character varying(50),
    schedule_type character varying(50) NOT NULL,
    frequency character varying(50) NOT NULL,
    next_run_at timestamp without time zone NOT NULL,
    last_run_at timestamp without time zone,
    last_run_status character varying(50),
    enabled boolean DEFAULT true,
    notification_emails text[],
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE compliance_schedules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.compliance_schedules IS 'Scheduled compliance checks and evidence collection';


--
-- Name: compliance_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_schedules_id_seq OWNED BY public.compliance_schedules.id;


--
-- Name: cost_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_analysis (
    id character varying(36) DEFAULT replace((gen_random_uuid())::text, '-'::text, ''::text) NOT NULL,
    organization_id character varying(36) NOT NULL,
    user_id character varying(36),
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type character varying(20) NOT NULL,
    model_name character varying(255) NOT NULL,
    provider character varying(100) NOT NULL,
    total_requests integer DEFAULT 0 NOT NULL,
    total_tokens bigint DEFAULT 0 NOT NULL,
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    total_cost numeric(12,6) DEFAULT 0 NOT NULL,
    input_cost numeric(12,6) DEFAULT 0 NOT NULL,
    output_cost numeric(12,6) DEFAULT 0 NOT NULL,
    avg_latency_ms integer,
    error_count integer DEFAULT 0,
    error_rate numeric(5,4),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: cost_forecasts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_forecasts (
    id character varying(36) DEFAULT replace((gen_random_uuid())::text, '-'::text, ''::text) NOT NULL,
    organization_id character varying(36) NOT NULL,
    budget_id character varying(36),
    forecast_date date NOT NULL,
    forecast_horizon_days integer NOT NULL,
    predicted_cost numeric(12,6) NOT NULL,
    confidence_lower numeric(12,6) NOT NULL,
    confidence_upper numeric(12,6) NOT NULL,
    confidence_level numeric(3,2) DEFAULT 0.95,
    forecast_model character varying(100) NOT NULL,
    model_accuracy numeric(5,4),
    historical_days_used integer,
    seasonality_detected boolean DEFAULT false,
    trend_direction character varying(20),
    trend_strength numeric(5,4),
    budget_exhaustion_date date,
    days_until_exhaustion integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: cost_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_recommendations (
    id character varying(36) DEFAULT replace((gen_random_uuid())::text, '-'::text, ''::text) NOT NULL,
    organization_id character varying(36) NOT NULL,
    recommendation_type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    current_monthly_cost numeric(12,6) NOT NULL,
    projected_monthly_cost numeric(12,6) NOT NULL,
    estimated_savings numeric(12,6) NOT NULL,
    savings_percentage numeric(5,2) NOT NULL,
    priority_score integer NOT NULL,
    confidence_score numeric(5,4) NOT NULL,
    implementation_difficulty character varying(20),
    quality_impact character varying(20),
    quality_score_change numeric(5,4),
    recommended_action jsonb NOT NULL,
    analysis_data jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    implemented_at timestamp without time zone,
    implemented_by character varying(36),
    actual_savings numeric(12,6),
    results_verified_at timestamp without time zone,
    valid_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: credit_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_packages (
    id integer NOT NULL,
    package_code character varying(50) NOT NULL,
    package_name character varying(255) NOT NULL,
    credits integer NOT NULL,
    price_usd numeric(10,2) NOT NULL,
    discount_percentage integer DEFAULT 0,
    badge_text character varying(100),
    description text,
    is_featured boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    display_order integer DEFAULT 0,
    stripe_price_id character varying(255),
    stripe_product_id character varying(255)
);


--
-- Name: credit_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_packages_id_seq OWNED BY public.credit_packages.id;


--
-- Name: credit_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_purchases (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    package_name character varying(255) NOT NULL,
    amount_credits numeric(20,2) NOT NULL,
    amount_paid numeric(10,2) NOT NULL,
    stripe_checkout_session_id character varying(255),
    stripe_payment_id character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    stripe_payment_intent_id character varying(255),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_purchases_id_seq OWNED BY public.credit_purchases.id;


--
-- Name: credit_usage_attribution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_usage_attribution (
    id character varying(255) DEFAULT (gen_random_uuid())::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    credits_used numeric(20,4) DEFAULT 0 NOT NULL,
    model_name character varying(255),
    request_id character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    service_type character varying(100) DEFAULT 'llm'::character varying
);


--
-- Name: custom_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    organization_id character varying(36),
    description text,
    is_system_role boolean DEFAULT false,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE custom_roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.custom_roles IS 'User-defined and system roles';


--
-- Name: custom_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_roles_id_seq OWNED BY public.custom_roles.id;


--
-- Name: data_retention_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_retention_policies (
    id integer NOT NULL,
    policy_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_type character varying(100) NOT NULL,
    retention_period_days integer NOT NULL,
    deletion_method character varying(50) DEFAULT 'soft_delete'::character varying,
    legal_hold boolean DEFAULT false,
    legal_hold_reason text,
    compliance_basis character varying(100),
    last_purge_at timestamp without time zone,
    next_purge_at timestamp without time zone,
    auto_purge_enabled boolean DEFAULT true,
    notification_before_days integer DEFAULT 30,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE data_retention_policies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.data_retention_policies IS 'Data retention and deletion policies for compliance';


--
-- Name: data_retention_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.data_retention_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_retention_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.data_retention_policies_id_seq OWNED BY public.data_retention_policies.id;


--
-- Name: email_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_history (
    id integer NOT NULL,
    provider_id integer,
    recipient character varying(255) NOT NULL,
    subject character varying(500),
    status character varying(50) NOT NULL,
    message_id character varying(255),
    error_message text,
    sent_at timestamp without time zone DEFAULT now()
);


--
-- Name: email_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_history_id_seq OWNED BY public.email_history.id;


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id integer NOT NULL,
    to_email character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    html_body text,
    text_body text,
    success boolean DEFAULT false NOT NULL,
    error_message text,
    metadata jsonb,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE email_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.email_logs IS 'Audit log of all emails sent from the system';


--
-- Name: COLUMN email_logs.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.email_logs.metadata IS 'Additional context: subscription_id, invoice_id, trial_id, etc.';


--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- Name: email_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_providers (
    id integer NOT NULL,
    provider_type character varying(50) NOT NULL,
    auth_method character varying(50) NOT NULL,
    enabled boolean DEFAULT false,
    smtp_host character varying(255),
    smtp_port integer,
    smtp_user character varying(255),
    smtp_from character varying(255),
    smtp_password text,
    api_key text,
    oauth2_client_id text,
    oauth2_client_secret text,
    oauth2_tenant_id character varying(255),
    oauth2_refresh_token text,
    provider_config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by character varying(255),
    name character varying(255)
);


--
-- Name: email_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_providers_id_seq OWNED BY public.email_providers.id;


--
-- Name: iac_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iac_templates (
    template_id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    category text,
    cloud_provider text NOT NULL,
    template_type text DEFAULT 'terraform'::text,
    source_code text NOT NULL,
    variables jsonb,
    outputs jsonb,
    version text DEFAULT '1.0.0'::text,
    created_by text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_public boolean DEFAULT false,
    downloads_count integer DEFAULT 0,
    tags text[]
);


--
-- Name: TABLE iac_templates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.iac_templates IS 'Reusable IaC templates library';


--
-- Name: invite_code_redemptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invite_code_redemptions (
    id integer NOT NULL,
    invite_code_id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    user_email character varying(255),
    redeemed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: invite_code_redemptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invite_code_redemptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invite_code_redemptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invite_code_redemptions_id_seq OWNED BY public.invite_code_redemptions.id;


--
-- Name: invite_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invite_codes (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    tier_code character varying(50) NOT NULL,
    max_uses integer,
    current_uses integer DEFAULT 0,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


--
-- Name: invite_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invite_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invite_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invite_codes_id_seq OWNED BY public.invite_codes.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    subscription_id integer NOT NULL,
    stripe_invoice_id character varying(255) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(10) DEFAULT 'usd'::character varying NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    invoice_url text,
    invoice_pdf text,
    issued_at timestamp without time zone NOT NULL,
    due_date timestamp without time zone,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: k8s_clusters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_clusters (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    kubeconfig_encrypted text NOT NULL,
    context_name character varying(255),
    api_server_url character varying(500) NOT NULL,
    cluster_version character varying(50),
    provider character varying(100),
    region character varying(100),
    environment character varying(50),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    health_status character varying(50) DEFAULT 'unknown'::character varying,
    last_sync_at timestamp without time zone,
    last_error text,
    total_nodes integer DEFAULT 0,
    total_namespaces integer DEFAULT 0,
    total_pods integer DEFAULT 0,
    total_deployments integer DEFAULT 0,
    estimated_monthly_cost numeric(10,2),
    cost_currency character varying(10) DEFAULT 'USD'::character varying,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by character varying(36)
);


--
-- Name: k8s_cost_attribution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_cost_attribution (
    id bigint NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    date date NOT NULL,
    hour integer,
    cpu_cost numeric(10,4),
    memory_cost numeric(10,4),
    storage_cost numeric(10,4),
    network_cost numeric(10,4),
    total_cost numeric(10,4),
    cpu_core_hours numeric(12,3),
    memory_gb_hours numeric(12,3),
    storage_gb_hours numeric(12,3),
    network_gb numeric(12,3),
    team_name character varying(255),
    cost_center character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_cost_attribution_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.k8s_cost_attribution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: k8s_cost_attribution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.k8s_cost_attribution_id_seq OWNED BY public.k8s_cost_attribution.id;


--
-- Name: k8s_deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_deployments (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    deployment_uid character varying(100) NOT NULL,
    replicas_desired integer,
    replicas_current integer,
    replicas_ready integer,
    replicas_available integer,
    replicas_unavailable integer,
    containers jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'Running'::character varying,
    health_status character varying(50) DEFAULT 'healthy'::character varying,
    strategy character varying(50),
    labels jsonb DEFAULT '{}'::jsonb,
    annotations jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_sync_at timestamp without time zone
);


--
-- Name: k8s_helm_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_helm_releases (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    chart_name character varying(255) NOT NULL,
    chart_version character varying(50),
    status character varying(50),
    revision integer,
    values_yaml text,
    first_deployed_at timestamp without time zone,
    last_deployed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_namespaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_namespaces (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    namespace_uid character varying(100) NOT NULL,
    status character varying(50) DEFAULT 'Active'::character varying,
    cpu_limit character varying(50),
    memory_limit character varying(50),
    pod_limit integer,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    pod_count integer DEFAULT 0,
    team_name character varying(255),
    cost_center character varying(255),
    estimated_daily_cost numeric(10,2),
    labels jsonb DEFAULT '{}'::jsonb,
    annotations jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_sync_at timestamp without time zone
);


--
-- Name: k8s_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_nodes (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    node_uid character varying(100) NOT NULL,
    node_type character varying(50),
    instance_type character varying(100),
    cpu_capacity character varying(50),
    memory_capacity character varying(50),
    pod_capacity integer,
    cpu_allocatable character varying(50),
    memory_allocatable character varying(50),
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    pod_count integer DEFAULT 0,
    status character varying(50) DEFAULT 'Ready'::character varying,
    conditions jsonb DEFAULT '[]'::jsonb,
    labels jsonb DEFAULT '{}'::jsonb,
    taints jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_sync_at timestamp without time zone
);


--
-- Name: k8s_pods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
)
PARTITION BY RANGE (created_at);


--
-- Name: k8s_pods_2026_01; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_01 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_02; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_02 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_03; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_03 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_04; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_04 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_05; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_05 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_06; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_06 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_07; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_07 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_08; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_08 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_09; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_09 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_10; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_10 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_11; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_11 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_pods_2026_12; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_pods_2026_12 (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36) NOT NULL,
    deployment_id character varying(36),
    name character varying(255) NOT NULL,
    pod_uid character varying(100) NOT NULL,
    node_name character varying(255),
    phase character varying(50),
    status character varying(50),
    reason text,
    containers jsonb DEFAULT '[]'::jsonb,
    init_containers jsonb DEFAULT '[]'::jsonb,
    cpu_request character varying(50),
    memory_request character varying(50),
    cpu_limit character varying(50),
    memory_limit character varying(50),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: k8s_resource_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics (
    id bigint NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (collected_at);


--
-- Name: k8s_resource_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.k8s_resource_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: k8s_resource_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.k8s_resource_metrics_id_seq OWNED BY public.k8s_resource_metrics.id;


--
-- Name: k8s_resource_metrics_2026_01; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_01 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_02; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_02 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_03; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_03 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_04; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_04 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_05; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_05 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_06; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_06 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_07; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_07 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_08; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_08 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_09; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_09 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_10; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_10 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_11; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_11 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: k8s_resource_metrics_2026_12; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.k8s_resource_metrics_2026_12 (
    id bigint DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass) NOT NULL,
    cluster_id character varying(36) NOT NULL,
    namespace_id character varying(36),
    deployment_id character varying(36),
    pod_id character varying(36),
    node_id character varying(36),
    resource_type character varying(50) NOT NULL,
    cpu_usage_cores numeric(10,3),
    memory_usage_bytes bigint,
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    storage_usage_bytes bigint,
    restarts integer,
    oom_kills integer,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: llm_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid,
    name character varying(200) NOT NULL,
    display_name character varying(200),
    cost_per_1m_input_tokens numeric(10,4),
    cost_per_1m_output_tokens numeric(10,4),
    context_length integer,
    enabled boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    avg_latency_ms integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    quality_score numeric(3,2),
    power_level character varying(20) DEFAULT 'balanced'::character varying
);


--
-- Name: TABLE llm_models; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.llm_models IS 'Available LLM models with cost and performance metadata';


--
-- Name: COLUMN llm_models.quality_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_models.quality_score IS 'Model quality rating (0.00-1.00)';


--
-- Name: COLUMN llm_models.power_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_models.power_level IS 'Suitable power level: eco, balanced, precision';


--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    api_key_encrypted text,
    api_base_url text,
    enabled boolean DEFAULT true,
    priority integer DEFAULT 0,
    config jsonb DEFAULT '{}'::jsonb,
    health_status character varying(20) DEFAULT 'unknown'::character varying,
    last_health_check timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    api_key_source character varying(20) DEFAULT 'not_set'::character varying,
    api_key_last_tested timestamp without time zone,
    api_key_test_status character varying(20),
    api_key_updated_at timestamp without time zone
);


--
-- Name: TABLE llm_providers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.llm_providers IS 'LLM provider configurations (admin-managed)';


--
-- Name: COLUMN llm_providers.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_providers.type IS 'Provider type: openrouter, openai, anthropic, groq, together, local';


--
-- Name: COLUMN llm_providers.priority; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_providers.priority IS 'Routing priority (higher = preferred)';


--
-- Name: COLUMN llm_providers.health_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_providers.health_status IS 'Health status: healthy, unhealthy, unknown';


--
-- Name: llm_routing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_routing_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    strategy character varying(50) DEFAULT 'balanced'::character varying NOT NULL,
    fallback_providers uuid[] DEFAULT '{}'::uuid[],
    model_aliases jsonb DEFAULT '{}'::jsonb,
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE llm_routing_rules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.llm_routing_rules IS 'Global routing rules and strategies';


--
-- Name: COLUMN llm_routing_rules.strategy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_routing_rules.strategy IS 'Routing strategy: cost, latency, balanced, custom';


--
-- Name: COLUMN llm_routing_rules.config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_routing_rules.config IS 'Strategy-specific config (cost_weight, latency_weight, etc.)';


--
-- Name: llm_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_usage_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(100) NOT NULL,
    provider_id uuid,
    model_name character varying(200),
    input_tokens integer,
    output_tokens integer,
    cost numeric(10,6),
    latency_ms integer,
    power_level character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    status character varying(20)
);


--
-- Name: TABLE llm_usage_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.llm_usage_logs IS 'LLM request usage tracking for billing and analytics';


--
-- Name: COLUMN llm_usage_logs.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.llm_usage_logs.status IS 'Request status: success, error, timeout';


--
-- Name: managed_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.managed_servers (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    hostname character varying(255) NOT NULL,
    api_url character varying(512) NOT NULL,
    api_token_hash character varying(255) NOT NULL,
    version character varying(50),
    region character varying(100),
    environment character varying(50),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    health_status character varying(50),
    last_seen_at timestamp with time zone,
    last_health_check_at timestamp with time zone,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    organization_id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migration_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_jobs (
    id character varying(36) NOT NULL,
    domain_name character varying(255) NOT NULL,
    source_registrar character varying(100) NOT NULL,
    target_registrar character varying(100) NOT NULL,
    status public.migrationstatus NOT NULL,
    auth_code character varying(255),
    initiated_by character varying(255) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text,
    steps json,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: model_access_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_access_audit (
    id integer NOT NULL,
    list_id integer,
    model_id character varying(255),
    action character varying(50) NOT NULL,
    actor_id character varying(255) NOT NULL,
    actor_email character varying(255),
    old_value jsonb,
    new_value jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE model_access_audit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.model_access_audit IS 'Audit trail for all model list changes';


--
-- Name: model_access_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_access_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_access_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_access_audit_id_seq OWNED BY public.model_access_audit.id;


--
-- Name: model_pricing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_pricing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider character varying(100) NOT NULL,
    model_name character varying(255) NOT NULL,
    model_tier character varying(50),
    input_price_per_million numeric(10,6) NOT NULL,
    output_price_per_million numeric(10,6) NOT NULL,
    context_window integer,
    max_output_tokens integer,
    supports_streaming boolean DEFAULT true,
    supports_function_calling boolean DEFAULT false,
    avg_latency_ms integer,
    quality_score numeric(5,4),
    is_active boolean DEFAULT true,
    deprecated_at timestamp without time zone,
    replacement_model character varying(255),
    effective_date date DEFAULT CURRENT_DATE NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: namecheap_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.namecheap_domains (
    id character varying(36) NOT NULL,
    domain_name character varying(255) NOT NULL,
    domain_id character varying(255),
    user_id character varying(255) NOT NULL,
    registration_date timestamp without time zone,
    expiration_date timestamp without time zone,
    auto_renew boolean,
    is_locked boolean,
    whois_guard boolean,
    nameservers json,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: org_billing_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_billing_history (
    id integer NOT NULL,
    org_id character varying(255) NOT NULL,
    subscription_id integer,
    event_type character varying(100) NOT NULL,
    amount numeric(20,4) DEFAULT 0,
    currency character varying(10) DEFAULT 'USD'::character varying,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: org_billing_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_billing_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_billing_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_billing_history_id_seq OWNED BY public.org_billing_history.id;


--
-- Name: organization_branding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_branding (
    id integer NOT NULL,
    org_id character varying(100) NOT NULL,
    org_name character varying(200) NOT NULL,
    logo_url text,
    logo_dark_url text,
    favicon_url text,
    background_image_url text,
    primary_color character varying(7) DEFAULT '#3B82F6'::character varying,
    secondary_color character varying(7) DEFAULT '#1E40AF'::character varying,
    accent_color character varying(7) DEFAULT '#10B981'::character varying,
    text_color character varying(7) DEFAULT '#1F2937'::character varying,
    background_color character varying(7) DEFAULT '#FFFFFF'::character varying,
    font_family character varying(100),
    heading_font character varying(100),
    company_name character varying(200),
    tagline text,
    description text,
    support_email character varying(255),
    support_phone character varying(50),
    website_url text,
    twitter_url text,
    linkedin_url text,
    github_url text,
    discord_url text,
    custom_domain character varying(255),
    custom_domain_verified boolean DEFAULT false,
    custom_domain_ssl_enabled boolean DEFAULT false,
    terms_of_service_url text,
    privacy_policy_url text,
    custom_terms_text text,
    custom_privacy_text text,
    email_from_name character varying(200),
    email_from_address character varying(255),
    email_logo_url text,
    email_footer_text text,
    custom_logo_enabled boolean DEFAULT false,
    custom_colors_enabled boolean DEFAULT false,
    custom_domain_enabled boolean DEFAULT false,
    custom_email_enabled boolean DEFAULT false,
    white_label_enabled boolean DEFAULT false,
    tier_code character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by character varying(255),
    updated_by character varying(255)
);


--
-- Name: TABLE organization_branding; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.organization_branding IS 'Organization-level branding and white-label configuration (Epic 4.5)';


--
-- Name: organization_branding_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organization_branding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_branding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organization_branding_id_seq OWNED BY public.organization_branding.id;


--
-- Name: organization_credit_pools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_credit_pools (
    id integer NOT NULL,
    org_id character varying(255) NOT NULL,
    total_credits numeric(20,4) DEFAULT 0 NOT NULL,
    allocated_credits numeric(20,4) DEFAULT 0 NOT NULL,
    used_credits numeric(20,4) DEFAULT 0 NOT NULL,
    available_credits numeric(20,4) GENERATED ALWAYS AS ((total_credits - allocated_credits)) STORED,
    monthly_refresh_amount numeric(20,4) DEFAULT 0 NOT NULL,
    last_refresh_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: organization_credit_pools_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organization_credit_pools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organization_credit_pools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organization_credit_pools_id_seq OWNED BY public.organization_credit_pools.id;


--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_invitations (
    id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    role public.organizationmemberrole NOT NULL,
    invited_by character varying(255) NOT NULL,
    status public.invitationstatus NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: organization_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_members (
    id character varying(255) NOT NULL,
    organization_id character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    role public.organizationmemberrole NOT NULL,
    is_active boolean,
    joined_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: organization_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_subscriptions (
    id character varying(255) DEFAULT (gen_random_uuid())::character varying NOT NULL,
    org_id character varying(255) NOT NULL,
    subscription_plan character varying(100) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    monthly_price numeric(20,2) DEFAULT 0 NOT NULL,
    start_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    end_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    website character varying(512),
    logo_url character varying(512),
    max_users integer,
    is_active boolean,
    settings json,
    metadata_json json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    stripe_customer_id character varying(255)
);


--
-- Name: payment_dunning; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_dunning (
    id integer NOT NULL,
    subscription_id integer NOT NULL,
    stripe_invoice_id character varying(255),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    first_failure_at timestamp without time zone DEFAULT now() NOT NULL,
    last_retry_at timestamp without time zone,
    next_retry_at timestamp without time zone,
    grace_period_ends_at timestamp without time zone,
    resolved_at timestamp without time zone,
    amount_due numeric(10,2) NOT NULL,
    currency character varying(10) DEFAULT 'usd'::character varying NOT NULL,
    failure_reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE payment_dunning; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.payment_dunning IS 'Tracks payment retry attempts and dunning campaigns for failed payments';


--
-- Name: COLUMN payment_dunning.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.payment_dunning.status IS 'active: retrying, resolved: payment succeeded, failed: max retries exhausted, cancelled: user cancelled subscription';


--
-- Name: COLUMN payment_dunning.retry_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.payment_dunning.retry_count IS 'Number of retry attempts made';


--
-- Name: COLUMN payment_dunning.grace_period_ends_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.payment_dunning.grace_period_ends_at IS 'When to suspend subscription if payment still failed';


--
-- Name: COLUMN payment_dunning.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.payment_dunning.metadata IS 'Additional context: email_sent_count, last_email_type, etc.';


--
-- Name: payment_dunning_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_dunning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_dunning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_dunning_id_seq OWNED BY public.payment_dunning.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.permissions IS 'Granular permissions for resource-based access control';


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: platform_pricing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_pricing_rules (
    id integer NOT NULL,
    tier_code character varying(50) NOT NULL,
    model_pattern character varying(255) NOT NULL,
    price_per_1k_tokens numeric(10,6),
    price_per_image numeric(10,6),
    price_per_request numeric(10,6),
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: platform_pricing_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_pricing_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_pricing_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_pricing_rules_id_seq OWNED BY public.platform_pricing_rules.id;


--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    id integer NOT NULL,
    category character varying(50) NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    is_encrypted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_secret boolean DEFAULT false
);


--
-- Name: platform_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_settings_id_seq OWNED BY public.platform_settings.id;


--
-- Name: policy_acknowledgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_acknowledgments (
    id integer NOT NULL,
    acknowledgment_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_email character varying(255) NOT NULL,
    policy_name character varying(255) NOT NULL,
    policy_version character varying(50) NOT NULL,
    policy_content_hash character varying(64),
    acknowledged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address inet,
    user_agent text,
    acknowledgment_method character varying(50),
    expires_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE policy_acknowledgments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.policy_acknowledgments IS 'User acknowledgments of security and compliance policies';


--
-- Name: policy_acknowledgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.policy_acknowledgments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: policy_acknowledgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.policy_acknowledgments_id_seq OWNED BY public.policy_acknowledgments.id;


--
-- Name: pricing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_rules (
    id integer NOT NULL,
    rule_type text NOT NULL,
    provider text,
    model_pattern text,
    pricing_formula text,
    base_cost numeric(10,4),
    markup_percentage numeric(5,2),
    priority integer DEFAULT 0,
    is_active boolean DEFAULT true,
    tier_restrictions jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tier_code text,
    markup_type text DEFAULT 'percentage'::text,
    markup_value numeric(10,4) DEFAULT 0,
    min_charge numeric(10,4) DEFAULT 0.001,
    free_credits_monthly numeric(12,2) DEFAULT 0,
    applies_to_tiers text[],
    rule_name text,
    description text,
    provider_overrides jsonb,
    created_by text,
    updated_by text,
    CONSTRAINT pricing_rules_rule_type_check CHECK ((rule_type = ANY (ARRAY['byok'::text, 'platform'::text])))
);


--
-- Name: pricing_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pricing_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pricing_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pricing_rules_id_seq OWNED BY public.pricing_rules.id;


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    api_key_id integer NOT NULL,
    window_type character varying(20) NOT NULL,
    window_start timestamp without time zone NOT NULL,
    request_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: TABLE rate_limits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rate_limits IS 'Rate limit counters per API key (prefer Redis in production)';


--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: rbac_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rbac_audit_log (
    id bigint NOT NULL,
    event_type character varying(50) NOT NULL,
    actor_email character varying(255) NOT NULL,
    target_user_email character varying(255),
    role_id integer,
    permission_id integer,
    resource_type character varying(50),
    resource_id character varying(100),
    changes jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE rbac_audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rbac_audit_log IS 'Audit trail for all RBAC changes';


--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rbac_audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rbac_audit_log_id_seq OWNED BY public.rbac_audit_log.id;


--
-- Name: security_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_incidents (
    id integer NOT NULL,
    incident_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    severity character varying(50) NOT NULL,
    incident_type character varying(100) NOT NULL,
    status character varying(50) DEFAULT 'open'::character varying,
    detected_at timestamp without time zone NOT NULL,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reported_by character varying(255),
    assigned_to character varying(255),
    resolved_at timestamp without time zone,
    resolution_notes text,
    affected_systems text[],
    affected_users text[],
    affected_data_types text[],
    estimated_impact character varying(50),
    root_cause text,
    remediation_steps text[],
    lessons_learned text,
    evidence_ids uuid[],
    related_controls character varying(50)[],
    notification_required boolean DEFAULT false,
    notification_sent boolean DEFAULT false,
    notification_sent_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE security_incidents; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.security_incidents IS 'Security incidents for SOC2 compliance tracking';


--
-- Name: recent_security_incidents; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.recent_security_incidents AS
 SELECT incident_id,
    title,
    severity,
    incident_type,
    status,
    detected_at,
    assigned_to,
    (EXTRACT(epoch FROM (CURRENT_TIMESTAMP - (detected_at)::timestamp with time zone)) / (3600)::numeric) AS hours_open
   FROM public.security_incidents
  WHERE ((status)::text = ANY ((ARRAY['open'::character varying, 'investigating'::character varying, 'contained'::character varying])::text[]))
  ORDER BY detected_at DESC
 LIMIT 100;


--
-- Name: VIEW recent_security_incidents; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.recent_security_incidents IS 'Recent open security incidents';


--
-- Name: terraform_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terraform_executions (
    execution_id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    execution_type text NOT NULL,
    status text DEFAULT 'running'::text,
    triggered_by text,
    triggered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    duration_seconds integer,
    plan_output jsonb,
    resources_to_add integer DEFAULT 0,
    resources_to_change integer DEFAULT 0,
    resources_to_destroy integer DEFAULT 0,
    error_message text,
    exit_code integer,
    log_file text,
    auto_applied boolean DEFAULT false
);


--
-- Name: TABLE terraform_executions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.terraform_executions IS 'History of Terraform plan/apply/destroy executions';


--
-- Name: terraform_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terraform_workspaces (
    workspace_id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    cloud_provider text NOT NULL,
    environment text NOT NULL,
    created_by text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_apply_at timestamp without time zone,
    state_version integer DEFAULT 0,
    locked boolean DEFAULT false,
    locked_by text,
    locked_at timestamp without time zone,
    auto_apply boolean DEFAULT false,
    terraform_version text DEFAULT '1.6.0'::text
);


--
-- Name: TABLE terraform_workspaces; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.terraform_workspaces IS 'Terraform workspaces for isolated infrastructure state';


--
-- Name: recent_terraform_executions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.recent_terraform_executions AS
 SELECT e.execution_id,
    e.workspace_id,
    w.name AS workspace_name,
    e.execution_type,
    e.status,
    e.triggered_by,
    e.triggered_at,
    e.duration_seconds,
    e.resources_to_add,
    e.resources_to_change,
    e.resources_to_destroy
   FROM (public.terraform_executions e
     JOIN public.terraform_workspaces w ON ((e.workspace_id = w.workspace_id)))
  ORDER BY e.triggered_at DESC
 LIMIT 100;


--
-- Name: resource_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_policies (
    id integer NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id character varying(100) NOT NULL,
    policy_document jsonb NOT NULL,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE resource_policies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.resource_policies IS 'Resource-specific access policies (JSON-based)';


--
-- Name: resource_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resource_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: resource_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resource_policies_id_seq OWNED BY public.resource_policies.id;


--
-- Name: terraform_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terraform_resources (
    resource_id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    state_id uuid,
    resource_type text NOT NULL,
    resource_name text NOT NULL,
    provider text NOT NULL,
    address text NOT NULL,
    attributes jsonb,
    dependencies text[],
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    destroyed_at timestamp without time zone
);


--
-- Name: TABLE terraform_resources; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.terraform_resources IS 'Infrastructure resources managed by Terraform';


--
-- Name: resource_type_distribution; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.resource_type_distribution AS
 SELECT provider,
    resource_type,
    count(*) AS count,
    count(
        CASE
            WHEN (status = 'active'::text) THEN 1
            ELSE NULL::integer
        END) AS active_count
   FROM public.terraform_resources
  GROUP BY provider, resource_type
  ORDER BY (count(*)) DESC;


--
-- Name: role_inheritance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_inheritance (
    id integer NOT NULL,
    parent_role_id integer,
    child_role_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT no_self_inheritance CHECK ((parent_role_id <> child_role_id))
);


--
-- Name: TABLE role_inheritance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role_inheritance IS 'Role inheritance hierarchy';


--
-- Name: role_inheritance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_inheritance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_inheritance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_inheritance_id_seq OWNED BY public.role_inheritance.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role_id integer,
    permission_id integer,
    granted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    granted_by character varying(255)
);


--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role_permissions IS 'Permissions assigned to roles';


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_email character varying(255) NOT NULL,
    role_id integer,
    organization_id character varying(36),
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    assigned_by character varying(255),
    expires_at timestamp without time zone
);


--
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_roles IS 'Roles assigned to users';


--
-- Name: role_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.role_summary AS
 SELECT cr.id,
    cr.name,
    cr.description,
    cr.is_system_role,
    count(rp.permission_id) AS permission_count,
    count(DISTINCT ur.user_email) AS user_count,
    cr.created_at
   FROM ((public.custom_roles cr
     LEFT JOIN public.role_permissions rp ON ((cr.id = rp.role_id)))
     LEFT JOIN public.user_roles ur ON ((cr.id = ur.role_id)))
  GROUP BY cr.id, cr.name, cr.description, cr.is_system_role, cr.created_at;


--
-- Name: saml_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_providers (
    provider_id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    entity_id character varying(500) NOT NULL,
    display_name character varying(255),
    description text,
    idp_entity_id character varying(500) NOT NULL,
    idp_sso_url character varying(1000) NOT NULL,
    idp_slo_url character varying(1000),
    idp_certificate text NOT NULL,
    sp_entity_id character varying(500) NOT NULL,
    sp_acs_url character varying(1000) NOT NULL,
    sp_slo_url character varying(1000),
    sp_private_key text,
    sp_certificate text,
    name_id_format character varying(255) DEFAULT 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress'::character varying,
    authn_context character varying(255) DEFAULT 'urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport'::character varying,
    want_assertions_signed boolean DEFAULT true,
    want_assertions_encrypted boolean DEFAULT false,
    sign_requests boolean DEFAULT false,
    binding_type character varying(50) DEFAULT 'HTTP-POST'::character varying,
    enable_jit_provisioning boolean DEFAULT true,
    default_role character varying(50) DEFAULT 'user'::character varying,
    auto_create_organizations boolean DEFAULT false,
    is_active boolean DEFAULT true,
    is_default boolean DEFAULT false,
    metadata jsonb,
    last_metadata_refresh timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    created_by character varying(255),
    updated_at timestamp without time zone DEFAULT now(),
    updated_by character varying(255)
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.saml_providers IS 'SAML 2.0 Identity Provider configurations';


--
-- Name: COLUMN saml_providers.idp_certificate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.saml_providers.idp_certificate IS 'X.509 certificate in PEM format for validating SAML assertions';


--
-- Name: COLUMN saml_providers.name_id_format; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.saml_providers.name_id_format IS 'Format for NameID in SAML assertions';


--
-- Name: COLUMN saml_providers.enable_jit_provisioning; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.saml_providers.enable_jit_provisioning IS 'Just-In-Time user provisioning on first SAML login';


--
-- Name: saml_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_sessions (
    session_id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    saml_session_id character varying(255),
    name_id character varying(500) NOT NULL,
    name_id_format character varying(255),
    user_id uuid,
    email character varying(255),
    session_start timestamp without time zone DEFAULT now(),
    session_expiry timestamp without time zone,
    not_on_or_after timestamp without time zone,
    authn_context character varying(255),
    authn_instant timestamp without time zone,
    attributes jsonb,
    is_active boolean DEFAULT true,
    logout_requested boolean DEFAULT false,
    logout_at timestamp without time zone,
    relay_state character varying(500),
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE saml_sessions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.saml_sessions IS 'Active SAML SSO sessions for authenticated users';


--
-- Name: COLUMN saml_sessions.saml_session_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.saml_sessions.saml_session_id IS 'SessionIndex from SAML assertion for logout';


--
-- Name: COLUMN saml_sessions.relay_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.saml_sessions.relay_state IS 'Original request URL to redirect after authentication';


--
-- Name: saml_active_sessions_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.saml_active_sessions_summary AS
 SELECT sp.provider_id,
    sp.name AS provider_name,
    count(DISTINCT ss.session_id) AS active_sessions,
    count(DISTINCT ss.user_id) AS unique_users,
    min(ss.session_start) AS oldest_session,
    max(ss.session_start) AS newest_session
   FROM (public.saml_providers sp
     LEFT JOIN public.saml_sessions ss ON (((sp.provider_id = ss.provider_id) AND (ss.is_active = true))))
  GROUP BY sp.provider_id, sp.name;


--
-- Name: VIEW saml_active_sessions_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.saml_active_sessions_summary IS 'Summary of active SAML sessions per provider';


--
-- Name: saml_assertions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_assertions (
    assertion_id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    session_id uuid,
    assertion_xml text,
    assertion_hash character varying(64),
    is_valid boolean NOT NULL,
    validation_errors jsonb,
    signature_verified boolean,
    certificate_thumbprint character varying(64),
    issue_instant timestamp without time zone,
    not_before timestamp without time zone,
    not_on_or_after timestamp without time zone,
    name_id character varying(500),
    name_id_format character varying(255),
    attributes jsonb,
    in_response_to character varying(255),
    relay_state character varying(500),
    ip_address character varying(45),
    received_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE saml_assertions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.saml_assertions IS 'Audit trail of all received SAML assertions';


--
-- Name: COLUMN saml_assertions.assertion_xml; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.saml_assertions.assertion_xml IS 'Full SAML assertion XML for compliance and debugging';


--
-- Name: saml_attribute_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_attribute_mappings (
    mapping_id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    saml_attribute character varying(255) NOT NULL,
    user_field character varying(100) NOT NULL,
    is_required boolean DEFAULT false,
    default_value text,
    transform_type character varying(50),
    transform_config jsonb,
    validation_regex character varying(500),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE saml_attribute_mappings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.saml_attribute_mappings IS 'Map SAML assertion attributes to user fields';


--
-- Name: saml_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_audit_log (
    log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid,
    session_id uuid,
    event_type character varying(50) NOT NULL,
    event_status character varying(20) NOT NULL,
    user_id uuid,
    email character varying(255),
    ip_address character varying(45),
    user_agent text,
    event_data jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE saml_audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.saml_audit_log IS 'Comprehensive audit trail for SAML operations';


--
-- Name: saml_login_activity; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.saml_login_activity AS
 SELECT sp.provider_id,
    sp.name AS provider_name,
    date(ss.session_start) AS login_date,
    count(DISTINCT ss.session_id) AS login_count,
    count(DISTINCT ss.user_id) AS unique_users
   FROM (public.saml_providers sp
     LEFT JOIN public.saml_sessions ss ON ((sp.provider_id = ss.provider_id)))
  WHERE (ss.session_start >= (now() - '30 days'::interval))
  GROUP BY sp.provider_id, sp.name, (date(ss.session_start))
  ORDER BY (date(ss.session_start)) DESC;


--
-- Name: VIEW saml_login_activity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.saml_login_activity IS 'SAML login activity for the last 30 days';


--
-- Name: saml_provider_health; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.saml_provider_health AS
 SELECT sp.provider_id,
    sp.name AS provider_name,
    sp.is_active,
    sp.last_metadata_refresh,
    count(DISTINCT ss.session_id) FILTER (WHERE (ss.is_active = true)) AS active_sessions,
    count(DISTINCT sa.assertion_id) FILTER (WHERE (sa.received_at >= (now() - '24:00:00'::interval))) AS assertions_24h,
    count(DISTINCT sa.assertion_id) FILTER (WHERE ((sa.is_valid = false) AND (sa.received_at >= (now() - '24:00:00'::interval)))) AS failed_assertions_24h,
    count(DISTINCT sal.log_id) FILTER (WHERE (((sal.event_type)::text = 'validation_error'::text) AND (sal.created_at >= (now() - '24:00:00'::interval)))) AS errors_24h
   FROM (((public.saml_providers sp
     LEFT JOIN public.saml_sessions ss ON ((sp.provider_id = ss.provider_id)))
     LEFT JOIN public.saml_assertions sa ON ((sp.provider_id = sa.provider_id)))
     LEFT JOIN public.saml_audit_log sal ON ((sp.provider_id = sal.provider_id)))
  GROUP BY sp.provider_id, sp.name, sp.is_active, sp.last_metadata_refresh;


--
-- Name: VIEW saml_provider_health; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.saml_provider_health IS 'Health metrics for SAML providers';


--
-- Name: savings_opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.savings_opportunities (
    id character varying(36) DEFAULT replace((gen_random_uuid())::text, '-'::text, ''::text) NOT NULL,
    organization_id character varying(36) NOT NULL,
    opportunity_type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    affected_models jsonb,
    affected_users jsonb,
    affected_period jsonb,
    current_monthly_cost numeric(12,6) NOT NULL,
    potential_savings numeric(12,6) NOT NULL,
    savings_percentage numeric(5,2) NOT NULL,
    detection_confidence numeric(5,4) NOT NULL,
    detection_method character varying(100),
    supporting_data jsonb,
    recommended_actions text[],
    estimated_implementation_hours numeric(5,2),
    status character varying(50) DEFAULT 'open'::character varying,
    assigned_to character varying(36),
    resolved_at timestamp without time zone,
    resolution_notes text,
    verified boolean DEFAULT false,
    actual_savings numeric(12,6),
    verified_at timestamp without time zone,
    verified_by character varying(36),
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: security_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_incidents_id_seq OWNED BY public.security_incidents.id;


--
-- Name: server_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_group_members (
    server_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_groups (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    color character varying(7),
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    regions jsonb DEFAULT '[]'::jsonb NOT NULL,
    environments jsonb DEFAULT '[]'::jsonb NOT NULL,
    organization_id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks (
    id bigint NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE ("timestamp");


--
-- Name: server_health_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.server_health_checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: server_health_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.server_health_checks_id_seq OWNED BY public.server_health_checks.id;


--
-- Name: server_health_checks_2026_01; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_01 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_02; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_02 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_03; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_03 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_04; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_04 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_05; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_05 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_06; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_06 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_07; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_07 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_08; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_08 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_09; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_09 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_10; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_10 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_11; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_11 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_health_checks_2026_12; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_health_checks_2026_12 (
    id bigint DEFAULT nextval('public.server_health_checks_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(50),
    response_time_ms integer,
    database_healthy boolean,
    redis_healthy boolean,
    services_healthy boolean,
    error_message text,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated (
    id bigint NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE ("timestamp");


--
-- Name: server_metrics_aggregated_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.server_metrics_aggregated_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: server_metrics_aggregated_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.server_metrics_aggregated_id_seq OWNED BY public.server_metrics_aggregated.id;


--
-- Name: server_metrics_aggregated_2026_01; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_01 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_02; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_02 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_03; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_03 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_04; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_04 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_05; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_05 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_06; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_06 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_07; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_07 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_08; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_08 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_09; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_09 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_10; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_10 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_11; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_11 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: server_metrics_aggregated_2026_12; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_metrics_aggregated_2026_12 (
    id bigint DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass) NOT NULL,
    server_id character varying(36) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    period character varying(20) NOT NULL,
    cpu_percent numeric(5,2),
    memory_percent numeric(5,2),
    disk_percent numeric(5,2),
    network_rx_bytes bigint,
    network_tx_bytes bigint,
    active_services integer,
    failed_services integer,
    total_services integer,
    llm_requests bigint,
    llm_cost_usd numeric(10,2),
    active_users integer,
    total_users integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: smart_alert_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_alert_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_id uuid,
    metric_name character varying(100) NOT NULL,
    model_type character varying(50) NOT NULL,
    model_data jsonb NOT NULL,
    baseline_stats jsonb,
    training_data_start timestamp with time zone,
    training_data_end timestamp with time zone,
    accuracy_score double precision,
    false_positive_rate double precision,
    last_trained_at timestamp with time zone DEFAULT now(),
    version integer DEFAULT 1 NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: subscription_tiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_tiers (
    id integer NOT NULL,
    tier_code text NOT NULL,
    tier_name text NOT NULL,
    description text,
    price_monthly numeric(10,2) DEFAULT 0,
    price_yearly numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    is_invite_only boolean DEFAULT false,
    sort_order integer DEFAULT 0,
    api_calls_limit integer DEFAULT 0,
    team_seats integer DEFAULT 1,
    byok_enabled boolean DEFAULT false,
    priority_support boolean DEFAULT false,
    lago_plan_code text,
    stripe_price_monthly text,
    stripe_price_yearly text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: subscription_tiers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_tiers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_tiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_tiers_id_seq OWNED BY public.subscription_tiers.id;


--
-- Name: terraform_drift_detections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terraform_drift_detections (
    drift_id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    resource_id uuid,
    detected_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    drift_type text,
    expected_state jsonb,
    actual_state jsonb,
    differences jsonb,
    resolved boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by text
);


--
-- Name: TABLE terraform_drift_detections; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.terraform_drift_detections IS 'Infrastructure drift detection results';


--
-- Name: terraform_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terraform_states (
    state_id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    version integer NOT NULL,
    serial integer NOT NULL,
    lineage text NOT NULL,
    state_data jsonb NOT NULL,
    resources_count integer DEFAULT 0,
    outputs jsonb,
    created_by text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    terraform_version text,
    is_current boolean DEFAULT true
);


--
-- Name: TABLE terraform_states; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.terraform_states IS 'Terraform state files with version history';


--
-- Name: terraform_variables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terraform_variables (
    variable_id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    key text NOT NULL,
    value text,
    description text,
    is_sensitive boolean DEFAULT false,
    is_hcl boolean DEFAULT false,
    category text DEFAULT 'terraform'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE terraform_variables; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.terraform_variables IS 'Workspace-specific Terraform variables';


--
-- Name: terraform_workspace_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.terraform_workspace_summary AS
SELECT
    NULL::uuid AS workspace_id,
    NULL::text AS name,
    NULL::text AS environment,
    NULL::text AS cloud_provider,
    NULL::boolean AS locked,
    NULL::timestamp without time zone AS last_apply_at,
    NULL::bigint AS resource_count,
    NULL::bigint AS active_resources,
    NULL::bigint AS drift_count,
    NULL::timestamp without time zone AS last_execution_at;


--
-- Name: tier_features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tier_features (
    id integer NOT NULL,
    tier_id integer NOT NULL,
    feature_key text NOT NULL,
    feature_value text,
    enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: tier_features_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tier_features_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tier_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tier_features_id_seq OWNED BY public.tier_features.id;


--
-- Name: usage_aggregates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_aggregates (
    id integer NOT NULL,
    subscription_id integer,
    email character varying(255) NOT NULL,
    api_key_id integer,
    period_type character varying(20) NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    total_requests bigint DEFAULT 0 NOT NULL,
    successful_requests bigint DEFAULT 0 NOT NULL,
    failed_requests bigint DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0,
    total_cost_usd numeric(10,2) DEFAULT 0,
    event_type_breakdown jsonb,
    model_breakdown jsonb,
    avg_response_time_ms integer,
    p95_response_time_ms integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE usage_aggregates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.usage_aggregates IS 'Pre-computed usage summaries for fast dashboard queries';


--
-- Name: usage_aggregates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usage_aggregates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usage_aggregates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usage_aggregates_id_seq OWNED BY public.usage_aggregates.id;


--
-- Name: usage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_events (
    id bigint NOT NULL,
    api_key_id integer,
    subscription_id integer,
    email character varying(255) NOT NULL,
    event_type character varying(50) NOT NULL,
    endpoint character varying(255),
    method character varying(10),
    tokens_used integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    status_code integer,
    response_time_ms integer,
    success boolean DEFAULT true NOT NULL,
    error_message text,
    model character varying(100),
    ip_address inet,
    user_agent text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (created_at);


--
-- Name: TABLE usage_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.usage_events IS 'Detailed event-level usage tracking (partitioned by month)';


--
-- Name: COLUMN usage_events.tokens_used; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.usage_events.tokens_used IS 'Number of tokens consumed (for LLM calls)';


--
-- Name: COLUMN usage_events.cost_usd; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.usage_events.cost_usd IS 'Estimated cost in USD for this request';


--
-- Name: usage_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usage_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usage_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usage_events_id_seq OWNED BY public.usage_events.id;


--
-- Name: usage_events_2026_01; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_events_2026_01 (
    id bigint DEFAULT nextval('public.usage_events_id_seq'::regclass) NOT NULL,
    api_key_id integer,
    subscription_id integer,
    email character varying(255) NOT NULL,
    event_type character varying(50) NOT NULL,
    endpoint character varying(255),
    method character varying(10),
    tokens_used integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    status_code integer,
    response_time_ms integer,
    success boolean DEFAULT true NOT NULL,
    error_message text,
    model character varying(100),
    ip_address inet,
    user_agent text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: usage_events_2026_02; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_events_2026_02 (
    id bigint DEFAULT nextval('public.usage_events_id_seq'::regclass) NOT NULL,
    api_key_id integer,
    subscription_id integer,
    email character varying(255) NOT NULL,
    event_type character varying(50) NOT NULL,
    endpoint character varying(255),
    method character varying(10),
    tokens_used integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    status_code integer,
    response_time_ms integer,
    success boolean DEFAULT true NOT NULL,
    error_message text,
    model character varying(100),
    ip_address inet,
    user_agent text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    key_name character varying(255) NOT NULL,
    key_hash text NOT NULL,
    key_prefix character varying(20) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    last_used timestamp without time zone,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: user_byok_credits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_byok_credits (
    id integer NOT NULL,
    user_id text NOT NULL,
    tier_code text NOT NULL,
    monthly_allowance numeric(12,2) DEFAULT 0,
    credits_used numeric(12,2) DEFAULT 0,
    credits_remaining numeric(12,2) DEFAULT 0,
    reset_date timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: user_byok_credits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_byok_credits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_byok_credits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_byok_credits_id_seq OWNED BY public.user_byok_credits.id;


--
-- Name: user_credit_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_credit_allocations (
    id character varying(255) DEFAULT (gen_random_uuid())::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    allocated_credits numeric(20,2) DEFAULT 0 NOT NULL,
    used_credits numeric(20,2) DEFAULT 0 NOT NULL,
    remaining_credits numeric(20,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true,
    allocated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_effective_permissions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_effective_permissions AS
 SELECT DISTINCT ur.user_email,
    ur.organization_id,
    p.name AS permission_name,
    p.resource,
    p.action,
    cr.name AS role_name
   FROM (((public.user_roles ur
     JOIN public.custom_roles cr ON ((ur.role_id = cr.id)))
     JOIN public.role_permissions rp ON ((cr.id = rp.role_id)))
     JOIN public.permissions p ON ((rp.permission_id = p.id)))
  WHERE ((ur.expires_at IS NULL) OR (ur.expires_at > CURRENT_TIMESTAMP));


--
-- Name: user_llm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_llm_settings (
    user_id character varying(100) NOT NULL,
    power_level character varying(20) DEFAULT 'balanced'::character varying,
    byok_providers jsonb DEFAULT '{}'::jsonb,
    credit_balance numeric(10,2) DEFAULT 0,
    preferences jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE user_llm_settings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_llm_settings IS 'Per-user LLM preferences and settings';


--
-- Name: COLUMN user_llm_settings.power_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_llm_settings.power_level IS 'User power level: eco, balanced, precision';


--
-- Name: COLUMN user_llm_settings.credit_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_llm_settings.credit_balance IS 'Remaining LLM credits';


--
-- Name: user_model_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_model_preferences (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    model_id character varying(255) NOT NULL,
    is_favorite boolean DEFAULT false,
    is_hidden boolean DEFAULT false,
    custom_label character varying(255),
    notes text,
    last_used_at timestamp with time zone,
    usage_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE user_model_preferences; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_model_preferences IS 'User-specific model preferences (favorites, hidden, custom labels)';


--
-- Name: user_model_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_model_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_model_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_model_preferences_id_seq OWNED BY public.user_model_preferences.id;


--
-- Name: user_provider_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_provider_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(100) NOT NULL,
    provider character varying(50) NOT NULL,
    api_key_encrypted text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    enabled boolean DEFAULT true,
    last_used timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE user_provider_keys; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_provider_keys IS 'User-provided API keys (BYOK)';


--
-- Name: COLUMN user_provider_keys.api_key_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_provider_keys.api_key_encrypted IS 'Fernet-encrypted API key';


--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: user_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_subscriptions (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    tier_id integer NOT NULL,
    stripe_subscription_id character varying(255),
    stripe_customer_id character varying(255),
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    billing_cycle character varying(20) DEFAULT 'monthly'::character varying NOT NULL,
    current_period_start timestamp without time zone,
    current_period_end timestamp without time zone,
    cancel_at timestamp without time zone,
    canceled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_subscriptions_id_seq OWNED BY public.user_subscriptions.id;


--
-- Name: v_active_budget_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_active_budget_status AS
 SELECT id AS budget_id,
    organization_id,
    name,
    total_limit,
    current_spend,
    warning_threshold,
    critical_threshold,
    alert_level,
    round(((current_spend / total_limit) * (100)::numeric), 2) AS utilization_percentage,
    (total_limit - current_spend) AS remaining_budget,
    (end_date - CURRENT_DATE) AS days_remaining,
        CASE
            WHEN (current_spend >= total_limit) THEN 'exceeded'::text
            WHEN (current_spend >= (total_limit * critical_threshold)) THEN 'critical'::text
            WHEN (current_spend >= (total_limit * warning_threshold)) THEN 'warning'::text
            ELSE 'healthy'::text
        END AS status
   FROM public.budgets b
  WHERE ((is_active = true) AND (end_date >= CURRENT_DATE));


--
-- Name: v_fleet_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_fleet_summary AS
 SELECT organization_id,
    count(*) AS total_servers,
    count(*) FILTER (WHERE ((status)::text = 'active'::text)) AS active_servers,
    count(*) FILTER (WHERE ((status)::text = 'inactive'::text)) AS inactive_servers,
    count(*) FILTER (WHERE ((status)::text = 'maintenance'::text)) AS maintenance_servers,
    count(*) FILTER (WHERE ((health_status)::text = 'healthy'::text)) AS healthy_servers,
    count(*) FILTER (WHERE ((health_status)::text = 'degraded'::text)) AS degraded_servers,
    count(*) FILTER (WHERE ((health_status)::text = 'critical'::text)) AS critical_servers,
    count(*) FILTER (WHERE (last_seen_at < (now() - '00:05:00'::interval))) AS unreachable_servers,
    count(DISTINCT region) AS regions_count,
    count(DISTINCT environment) AS environments_count
   FROM public.managed_servers
  GROUP BY organization_id;


--
-- Name: v_k8s_cluster_health; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_k8s_cluster_health AS
 SELECT c.id,
    c.organization_id,
    c.name,
    c.health_status,
    c.total_nodes,
    c.total_namespaces,
    c.total_pods,
    c.provider,
    c.environment,
    count(DISTINCT n.id) FILTER (WHERE ((n.status)::text = 'Ready'::text)) AS healthy_nodes,
    count(DISTINCT d.id) FILTER (WHERE ((d.health_status)::text = 'healthy'::text)) AS healthy_deployments,
    COALESCE(m.cpu_usage_cores, (0)::numeric) AS total_cpu_usage,
    COALESCE(m.memory_usage_bytes, (0)::bigint) AS total_memory_usage,
    c.estimated_monthly_cost,
    c.last_sync_at
   FROM (((public.k8s_clusters c
     LEFT JOIN public.k8s_nodes n ON (((c.id)::text = (n.cluster_id)::text)))
     LEFT JOIN public.k8s_deployments d ON (((c.id)::text = (d.cluster_id)::text)))
     LEFT JOIN LATERAL ( SELECT k8s_resource_metrics.cpu_usage_cores,
            k8s_resource_metrics.memory_usage_bytes
           FROM public.k8s_resource_metrics
          WHERE (((k8s_resource_metrics.cluster_id)::text = (c.id)::text) AND ((k8s_resource_metrics.resource_type)::text = 'cluster'::text))
          ORDER BY k8s_resource_metrics.collected_at DESC
         LIMIT 1) m ON (true))
  GROUP BY c.id, c.organization_id, c.name, c.health_status, c.total_nodes, c.total_namespaces, c.total_pods, c.provider, c.environment, m.cpu_usage_cores, m.memory_usage_bytes, c.estimated_monthly_cost, c.last_sync_at;


--
-- Name: v_k8s_namespace_costs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_k8s_namespace_costs AS
 SELECT n.id AS namespace_id,
    n.cluster_id,
    n.organization_id,
    n.name AS namespace_name,
    n.team_name,
    n.cost_center,
    COALESCE(sum(ca.total_cost), (0)::numeric) AS cost_last_30d,
    COALESCE(avg(ca.total_cost), (0)::numeric) AS avg_daily_cost,
    COALESCE(sum(ca.cpu_core_hours), (0)::numeric) AS cpu_hours_last_30d,
    COALESCE(sum(ca.memory_gb_hours), (0)::numeric) AS memory_gb_hours_last_30d,
    COALESCE(sum(ca.storage_gb_hours), (0)::numeric) AS storage_gb_hours_last_30d,
    COALESCE(sum(ca.network_gb), (0)::numeric) AS network_gb_last_30d
   FROM (public.k8s_namespaces n
     LEFT JOIN public.k8s_cost_attribution ca ON ((((n.id)::text = (ca.namespace_id)::text) AND (ca.date >= (CURRENT_DATE - '30 days'::interval)) AND (ca.hour IS NULL))))
  GROUP BY n.id, n.cluster_id, n.organization_id, n.name, n.team_name, n.cost_center;


--
-- Name: v_monthly_cost_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_monthly_cost_summary AS
 SELECT organization_id,
    date_trunc('month'::text, period_start) AS month,
    sum(total_cost) AS total_cost,
    sum(total_requests) AS total_requests,
    sum(total_tokens) AS total_tokens,
    count(DISTINCT model_name) AS models_used,
    count(DISTINCT user_id) AS active_users
   FROM public.cost_analysis
  WHERE ((period_type)::text = 'daily'::text)
  GROUP BY organization_id, (date_trunc('month'::text, period_start));


--
-- Name: v_server_health_overview; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_server_health_overview AS
 SELECT DISTINCT ON (server_id) server_id,
    "timestamp",
    status,
    response_time_ms,
    database_healthy,
    redis_healthy,
    services_healthy,
    error_message
   FROM public.server_health_checks
  ORDER BY server_id, "timestamp" DESC;


--
-- Name: v_top_recommendations; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_top_recommendations AS
 SELECT id,
    organization_id,
    recommendation_type,
    title,
    estimated_savings,
    savings_percentage,
    priority_score,
    confidence_score,
    implementation_difficulty,
    quality_impact,
    status,
    created_at,
    rank() OVER (PARTITION BY organization_id ORDER BY priority_score DESC, estimated_savings DESC) AS rank
   FROM public.cost_recommendations r
  WHERE (((status)::text = 'pending'::text) AND ((valid_until IS NULL) OR (valid_until > now())));


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    url text NOT NULL,
    events text[] NOT NULL,
    secret text NOT NULL,
    description text,
    enabled boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    last_triggered_at timestamp with time zone,
    success_count integer DEFAULT 0,
    failure_count integer DEFAULT 0
);


--
-- Name: workspace_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_credentials (
    workspace_id uuid NOT NULL,
    credential_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: k8s_pods_2026_01; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2026-02-01 00:00:00');


--
-- Name: k8s_pods_2026_02; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00') TO ('2026-03-01 00:00:00');


--
-- Name: k8s_pods_2026_03; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_03 FOR VALUES FROM ('2026-03-01 00:00:00') TO ('2026-04-01 00:00:00');


--
-- Name: k8s_pods_2026_04; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_04 FOR VALUES FROM ('2026-04-01 00:00:00') TO ('2026-05-01 00:00:00');


--
-- Name: k8s_pods_2026_05; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_05 FOR VALUES FROM ('2026-05-01 00:00:00') TO ('2026-06-01 00:00:00');


--
-- Name: k8s_pods_2026_06; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_06 FOR VALUES FROM ('2026-06-01 00:00:00') TO ('2026-07-01 00:00:00');


--
-- Name: k8s_pods_2026_07; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_07 FOR VALUES FROM ('2026-07-01 00:00:00') TO ('2026-08-01 00:00:00');


--
-- Name: k8s_pods_2026_08; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_08 FOR VALUES FROM ('2026-08-01 00:00:00') TO ('2026-09-01 00:00:00');


--
-- Name: k8s_pods_2026_09; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_09 FOR VALUES FROM ('2026-09-01 00:00:00') TO ('2026-10-01 00:00:00');


--
-- Name: k8s_pods_2026_10; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_10 FOR VALUES FROM ('2026-10-01 00:00:00') TO ('2026-11-01 00:00:00');


--
-- Name: k8s_pods_2026_11; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_11 FOR VALUES FROM ('2026-11-01 00:00:00') TO ('2026-12-01 00:00:00');


--
-- Name: k8s_pods_2026_12; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods ATTACH PARTITION public.k8s_pods_2026_12 FOR VALUES FROM ('2026-12-01 00:00:00') TO ('2027-01-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_01; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2026-02-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_02; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00') TO ('2026-03-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_03; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_03 FOR VALUES FROM ('2026-03-01 00:00:00') TO ('2026-04-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_04; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_04 FOR VALUES FROM ('2026-04-01 00:00:00') TO ('2026-05-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_05; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_05 FOR VALUES FROM ('2026-05-01 00:00:00') TO ('2026-06-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_06; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_06 FOR VALUES FROM ('2026-06-01 00:00:00') TO ('2026-07-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_07; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_07 FOR VALUES FROM ('2026-07-01 00:00:00') TO ('2026-08-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_08; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_08 FOR VALUES FROM ('2026-08-01 00:00:00') TO ('2026-09-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_09; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_09 FOR VALUES FROM ('2026-09-01 00:00:00') TO ('2026-10-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_10; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_10 FOR VALUES FROM ('2026-10-01 00:00:00') TO ('2026-11-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_11; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_11 FOR VALUES FROM ('2026-11-01 00:00:00') TO ('2026-12-01 00:00:00');


--
-- Name: k8s_resource_metrics_2026_12; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ATTACH PARTITION public.k8s_resource_metrics_2026_12 FOR VALUES FROM ('2026-12-01 00:00:00') TO ('2027-01-01 00:00:00');


--
-- Name: server_health_checks_2026_01; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2026-02-01 00:00:00+00');


--
-- Name: server_health_checks_2026_02; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00+00') TO ('2026-03-01 00:00:00+00');


--
-- Name: server_health_checks_2026_03; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_03 FOR VALUES FROM ('2026-03-01 00:00:00+00') TO ('2026-04-01 00:00:00+00');


--
-- Name: server_health_checks_2026_04; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_04 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-05-01 00:00:00+00');


--
-- Name: server_health_checks_2026_05; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_05 FOR VALUES FROM ('2026-05-01 00:00:00+00') TO ('2026-06-01 00:00:00+00');


--
-- Name: server_health_checks_2026_06; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_06 FOR VALUES FROM ('2026-06-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');


--
-- Name: server_health_checks_2026_07; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_07 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-08-01 00:00:00+00');


--
-- Name: server_health_checks_2026_08; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_08 FOR VALUES FROM ('2026-08-01 00:00:00+00') TO ('2026-09-01 00:00:00+00');


--
-- Name: server_health_checks_2026_09; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_09 FOR VALUES FROM ('2026-09-01 00:00:00+00') TO ('2026-10-01 00:00:00+00');


--
-- Name: server_health_checks_2026_10; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_10 FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2026-11-01 00:00:00+00');


--
-- Name: server_health_checks_2026_11; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_11 FOR VALUES FROM ('2026-11-01 00:00:00+00') TO ('2026-12-01 00:00:00+00');


--
-- Name: server_health_checks_2026_12; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ATTACH PARTITION public.server_health_checks_2026_12 FOR VALUES FROM ('2026-12-01 00:00:00+00') TO ('2027-01-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_01; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2026-02-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_02; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00+00') TO ('2026-03-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_03; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_03 FOR VALUES FROM ('2026-03-01 00:00:00+00') TO ('2026-04-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_04; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_04 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-05-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_05; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_05 FOR VALUES FROM ('2026-05-01 00:00:00+00') TO ('2026-06-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_06; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_06 FOR VALUES FROM ('2026-06-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_07; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_07 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-08-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_08; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_08 FOR VALUES FROM ('2026-08-01 00:00:00+00') TO ('2026-09-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_09; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_09 FOR VALUES FROM ('2026-09-01 00:00:00+00') TO ('2026-10-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_10; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_10 FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2026-11-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_11; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_11 FOR VALUES FROM ('2026-11-01 00:00:00+00') TO ('2026-12-01 00:00:00+00');


--
-- Name: server_metrics_aggregated_2026_12; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ATTACH PARTITION public.server_metrics_aggregated_2026_12 FOR VALUES FROM ('2026-12-01 00:00:00+00') TO ('2027-01-01 00:00:00+00');


--
-- Name: usage_events_2026_01; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_events ATTACH PARTITION public.usage_events_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2026-02-01 00:00:00');


--
-- Name: usage_events_2026_02; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_events ATTACH PARTITION public.usage_events_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00') TO ('2026-03-01 00:00:00');


--
-- Name: add_on_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_categories ALTER COLUMN id SET DEFAULT nextval('public.add_on_categories_id_seq'::regclass);


--
-- Name: add_on_purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_purchases ALTER COLUMN id SET DEFAULT nextval('public.add_on_purchases_id_seq'::regclass);


--
-- Name: add_on_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_reviews ALTER COLUMN id SET DEFAULT nextval('public.add_on_reviews_id_seq'::regclass);


--
-- Name: add_ons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_ons ALTER COLUMN id SET DEFAULT nextval('public.add_ons_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: app_definitions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_definitions ALTER COLUMN id SET DEFAULT nextval('public.app_definitions_id_seq'::regclass);


--
-- Name: app_model_list_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_list_items ALTER COLUMN id SET DEFAULT nextval('public.app_model_list_items_id_seq'::regclass);


--
-- Name: app_model_lists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_lists ALTER COLUMN id SET DEFAULT nextval('public.app_model_lists_id_seq'::regclass);


--
-- Name: branding_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_assets ALTER COLUMN id SET DEFAULT nextval('public.branding_assets_id_seq'::regclass);


--
-- Name: branding_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_audit_log ALTER COLUMN id SET DEFAULT nextval('public.branding_audit_log_id_seq'::regclass);


--
-- Name: branding_tier_limits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_tier_limits ALTER COLUMN id SET DEFAULT nextval('public.branding_tier_limits_id_seq'::regclass);


--
-- Name: byok_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_keys ALTER COLUMN id SET DEFAULT nextval('public.byok_keys_id_seq'::regclass);


--
-- Name: byok_pricing_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_pricing_rules ALTER COLUMN id SET DEFAULT nextval('public.byok_pricing_rules_id_seq'::regclass);


--
-- Name: cart_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items ALTER COLUMN id SET DEFAULT nextval('public.cart_items_id_seq'::regclass);


--
-- Name: compliance_controls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_controls ALTER COLUMN id SET DEFAULT nextval('public.compliance_controls_id_seq'::regclass);


--
-- Name: compliance_evidence id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_evidence ALTER COLUMN id SET DEFAULT nextval('public.compliance_evidence_id_seq'::regclass);


--
-- Name: compliance_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_metrics ALTER COLUMN id SET DEFAULT nextval('public.compliance_metrics_id_seq'::regclass);


--
-- Name: compliance_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_reports ALTER COLUMN id SET DEFAULT nextval('public.compliance_reports_id_seq'::regclass);


--
-- Name: compliance_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_schedules ALTER COLUMN id SET DEFAULT nextval('public.compliance_schedules_id_seq'::regclass);


--
-- Name: credit_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_packages ALTER COLUMN id SET DEFAULT nextval('public.credit_packages_id_seq'::regclass);


--
-- Name: credit_purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases ALTER COLUMN id SET DEFAULT nextval('public.credit_purchases_id_seq'::regclass);


--
-- Name: custom_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_roles_id_seq'::regclass);


--
-- Name: data_retention_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_retention_policies ALTER COLUMN id SET DEFAULT nextval('public.data_retention_policies_id_seq'::regclass);


--
-- Name: email_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_history ALTER COLUMN id SET DEFAULT nextval('public.email_history_id_seq'::regclass);


--
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- Name: email_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_providers ALTER COLUMN id SET DEFAULT nextval('public.email_providers_id_seq'::regclass);


--
-- Name: invite_code_redemptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_code_redemptions ALTER COLUMN id SET DEFAULT nextval('public.invite_code_redemptions_id_seq'::regclass);


--
-- Name: invite_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes ALTER COLUMN id SET DEFAULT nextval('public.invite_codes_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: k8s_cost_attribution id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_cost_attribution ALTER COLUMN id SET DEFAULT nextval('public.k8s_cost_attribution_id_seq'::regclass);


--
-- Name: k8s_resource_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics ALTER COLUMN id SET DEFAULT nextval('public.k8s_resource_metrics_id_seq'::regclass);


--
-- Name: model_access_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_access_audit ALTER COLUMN id SET DEFAULT nextval('public.model_access_audit_id_seq'::regclass);


--
-- Name: org_billing_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_billing_history ALTER COLUMN id SET DEFAULT nextval('public.org_billing_history_id_seq'::regclass);


--
-- Name: organization_branding id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_branding ALTER COLUMN id SET DEFAULT nextval('public.organization_branding_id_seq'::regclass);


--
-- Name: organization_credit_pools id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_credit_pools ALTER COLUMN id SET DEFAULT nextval('public.organization_credit_pools_id_seq'::regclass);


--
-- Name: payment_dunning id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_dunning ALTER COLUMN id SET DEFAULT nextval('public.payment_dunning_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: platform_pricing_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_pricing_rules ALTER COLUMN id SET DEFAULT nextval('public.platform_pricing_rules_id_seq'::regclass);


--
-- Name: platform_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings ALTER COLUMN id SET DEFAULT nextval('public.platform_settings_id_seq'::regclass);


--
-- Name: policy_acknowledgments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_acknowledgments ALTER COLUMN id SET DEFAULT nextval('public.policy_acknowledgments_id_seq'::regclass);


--
-- Name: pricing_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rules ALTER COLUMN id SET DEFAULT nextval('public.pricing_rules_id_seq'::regclass);


--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: rbac_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rbac_audit_log ALTER COLUMN id SET DEFAULT nextval('public.rbac_audit_log_id_seq'::regclass);


--
-- Name: resource_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policies ALTER COLUMN id SET DEFAULT nextval('public.resource_policies_id_seq'::regclass);


--
-- Name: role_inheritance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_inheritance ALTER COLUMN id SET DEFAULT nextval('public.role_inheritance_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: security_incidents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_incidents ALTER COLUMN id SET DEFAULT nextval('public.security_incidents_id_seq'::regclass);


--
-- Name: server_health_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks ALTER COLUMN id SET DEFAULT nextval('public.server_health_checks_id_seq'::regclass);


--
-- Name: server_metrics_aggregated id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated ALTER COLUMN id SET DEFAULT nextval('public.server_metrics_aggregated_id_seq'::regclass);


--
-- Name: subscription_tiers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_tiers ALTER COLUMN id SET DEFAULT nextval('public.subscription_tiers_id_seq'::regclass);


--
-- Name: tier_features id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tier_features ALTER COLUMN id SET DEFAULT nextval('public.tier_features_id_seq'::regclass);


--
-- Name: usage_aggregates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_aggregates ALTER COLUMN id SET DEFAULT nextval('public.usage_aggregates_id_seq'::regclass);


--
-- Name: usage_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_events ALTER COLUMN id SET DEFAULT nextval('public.usage_events_id_seq'::regclass);


--
-- Name: user_byok_credits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_byok_credits ALTER COLUMN id SET DEFAULT nextval('public.user_byok_credits_id_seq'::regclass);


--
-- Name: user_model_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_model_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_model_preferences_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: user_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.user_subscriptions_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4762b20e-b964-496d-898e-7b62282853f3	db0c5c95618aeba4852c3090275557a27dc5f477cf721338df5b01faacd0dcab	2026-01-31 21:31:20.610509+00	0_init		\N	2026-01-31 21:31:20.610509+00	0
1540ad4a-b78e-425f-be7c-086c742c8699	f707e9e572c9d59c919abade1a788b1a429f1a5987500e63eb1bc370e29056e8	2026-01-31 21:31:35.809002+00	20251210205007_add_daily_agent_spend_table		\N	2026-01-31 21:31:35.809002+00	0
3f0658db-e8db-4fd9-b743-c9e29160acb4	5f859523d432963da531c9db07045d5f4ffa359dcfa12f29d0d790c2cc010104	2026-01-31 21:31:40.256587+00	20251114180624_Add_org_usage_table		\N	2026-01-31 21:31:40.256587+00	0
5ac3f48f-ca67-421a-b367-03fe79ebd385	7b33f32b9c9df910f38812ede97f8112859898d60752e6e5835f4ea1b1aeb84b	2026-01-31 21:31:44.674725+00	20250416151339_drop_tag_uniqueness_requirement		\N	2026-01-31 21:31:44.674725+00	0
826c0e43-a0d4-4f17-87db-9dcc9b6468f3	4e4dc410b0cc4169d536dbd71892777edbe13d7573f15f0ab24db003eb65ae6c	2026-01-31 21:31:48.977052+00	20260116142756_update_deleted_keys_teams_table_routing_settings		\N	2026-01-31 21:31:48.977052+00	0
b7952173-e69e-45eb-8c80-63eac672887a	01bcbdb6f974edfbd682ac06a64061fe6d076c0c2b0803d638f2048cd0fa8868	2026-01-31 21:31:53.446432+00	20251031181430_add_cache_config_table		\N	2026-01-31 21:31:53.446432+00	0
56ae6a3a-8211-415a-89eb-63329d40cbd9	99e5dca0bcd923cfa1b9419f789c41f5b70e14b4c2f379a59e93792ef61b77b2	2026-01-31 21:31:58.149295+00	20250416115320_add_tag_table_to_db		\N	2026-01-31 21:31:58.149295+00	0
36ca4548-7092-48ca-b194-ef9976f1dbaa	758f9d3422e8b169973658b607dc2a5f8859a69decd032f723010fb534c2d77e	2026-01-31 21:32:03.315613+00	20250326171002_add_daily_user_table		\N	2026-01-31 21:32:03.315613+00	0
d9cca1c0-8cbd-432f-af83-b41bac0a39d0	b7278b63abbc285cb0ef5a2c08133eb1d8e1220bc7a0508af3c708c7c744c4d6	2026-01-31 21:32:07.4028+00	20250331215456_track_success_and_failed_requests_daily_agg_table		\N	2026-01-31 21:32:07.4028+00	0
970d501c-4878-4d89-9725-c04b29b73c9b	50f6805ecaf21af5594ff4a739ffb5c87bb96ca3d356bda03f7cd8eb814a47ba	2026-01-31 21:32:11.767577+00	20250509141545_use_big_int_for_daily_spend_tables		\N	2026-01-31 21:32:11.767577+00	0
de929a83-1ad7-42cc-b0d0-9d7344d5b861	0fca25c5f2006c4440cd82c8ea5753e3429407fdedf42791825e27d834f8e655	2026-01-31 21:32:16.160271+00	20251003165142_add_allowed_tools_to_mcp		\N	2026-01-31 21:32:16.160271+00	0
9f647088-1c32-46ae-9223-7a9ecdc74a1a	4a65de74a5985b060066383ebacc3ef74e675f1c94f523b0b3db5e1404decd40	2026-01-31 21:32:20.7505+00	20250430193429_add_managed_vector_stores		\N	2026-01-31 21:32:20.7505+00	0
088c2cd0-8555-4435-898d-5f746de8fc0b	c8d295ae3ee15e36a2e2bc4cc2a6b89b81918cdd4710619d627c529a947fe3fb	2026-01-31 21:32:25.086278+00	20260106155622_add_endpoint_to_daily_activity_tables		\N	2026-01-31 21:32:25.086278+00	0
86921881-b054-4290-8d24-a265987e2728	3bd0b7fd731a1d2e43aaefc346dca6f3d6e1b29022792422429c4ad4c4d06604	2026-01-31 21:32:29.435305+00	20250526154401_allow_null_entity_id		\N	2026-01-31 21:32:29.435305+00	0
2d65c1e8-39c1-4fae-9e1b-45ab5156e5c8	9b10615e879dc6469bae49fb60f88a9fe3959a85e1e91b1211763d6b4f859109	2026-01-31 21:32:34.76785+00	20250514142245_add_guardrails_table		\N	2026-01-31 21:32:34.76785+00	0
1c1e4ab0-7439-40eb-b262-6fd86787be18	87a406711150b5a2b2a5293e39a9bd8c21fd2c63c8415f04eea12033df579dc3	2026-01-31 21:32:39.116342+00	20251114182247_agents_table		\N	2026-01-31 21:32:39.116342+00	0
30919030-82ca-4b7f-8b45-611f23afa450	128f7db3e9694e9e149e80a5d8d786466b2dc448308ffbbeb36255c066123047	2026-01-31 21:32:43.312244+00	20251101131415_add_managed_vector_store_index_table		\N	2026-01-31 21:32:43.312244+00	0
bb8dde18-9763-438a-9fe8-353441a82d57	b77b5e9411a7c73a3c9174189f247af6f83170f61ff72b285add724911e72601	2026-01-31 21:32:47.41494+00	20250711220620_add_stdio_mcp		\N	2026-01-31 21:32:47.41494+00	0
9d815269-3e02-4e78-8962-aae17ec940e2	4aa798c108fd20525b09003bdffe8ed3fcfee46c31973eb758c24d4f296e4d2b	2026-01-31 21:32:51.764137+00	20260123131407_add_policy_tables_and_policies_field		\N	2026-01-31 21:32:51.764137+00	0
303fc026-24dc-451d-937b-cca41d0d7e55	b47d4cb1476ddf13b44cd414f6251fa93e139da9c3aa68a293ed883fca38203e	2026-01-31 21:32:56.060094+00	20251209112246_add_ui_settings_table		\N	2026-01-31 21:32:56.060094+00	0
4e202651-a37e-4d88-a347-a798561acf10	86038393c8ebaf7bb60df05dfa7024a17fe8c03aa7fac858beaaf8f07ec753bc	2026-01-31 21:33:00.581285+00	20251204142718_add_agent_permissions		\N	2026-01-31 21:33:00.581285+00	0
0fb21fd7-6d01-4f93-8a76-4549af18f518	023459be5e9d94ca7d611a2c4f2d0869ae99a8c5c0c9d158ec59733a9f93d3d2	2026-01-31 21:33:04.758867+00	20250625145206_cascade_budget_and_loosen_managed_file_json		\N	2026-01-31 21:33:04.758867+00	0
52cea3cb-f536-4b65-a5cd-d6f2ff1615e0	2cc5021a72bacfa061fe62a2929e7fd17b3f127b283cc6fe75363eb090675d58	2026-01-31 21:33:09.155534+00	20250603210143_cascade_budget_changes		\N	2026-01-31 21:33:09.155534+00	0
2a264b5a-7a33-460a-92ab-2a3d3d764d7b	7528d4e506af1cc33ad2c8b2e9fffaf436691420389547d60cbd005043c4b768	2026-01-31 21:33:13.957554+00	20250425182129_add_session_id		\N	2026-01-31 21:33:13.957554+00	0
ae81f2f2-19a0-4955-bcae-1a43aeccfd46	49b72106c11225af0ce4ee11d62aaf7e0b2c5f94ad4ab2fce5499dd83ae7b3f6	2026-01-31 21:33:18.377754+00	20250522223020_managed_object_table		\N	2026-01-31 21:33:18.377754+00	0
6fb0f26e-5e91-453a-93b9-de47721d9d0a	aecb29feb0b3c18e6f78550978648ea063af724dc867db0bf3a46e1f3409facd	2026-01-31 21:33:22.71087+00	20250802162330_prompt_table		\N	2026-01-31 21:33:22.71087+00	0
fb38ab5a-dd38-4197-9891-808bf443a81a	2b23aa2aee91f35133eb0e38e413c5979df9ff9949d57ac70550a5a17ad1a53f	2026-01-31 21:33:27.107044+00	20251210125210_add_storage_backend_to_managed_files		\N	2026-01-31 21:33:27.107044+00	0
238c24c5-4a0f-40a6-a5d6-50834c917192	1692ef827c472a9dc96fe512c7e1163867950970e94b39c6065a2a956026f5b8	2026-01-31 21:33:31.379804+00	20250618225828_add_health_check_table		\N	2026-01-31 21:33:31.379804+00	0
a2943d0d-17f0-45d7-b3dd-9579fc929389	5789888688b79fcb14cd5f3f618f4003fc2482f93ae66e59380537fc3b68528f	2026-01-31 21:33:35.668333+00	20250508072103_add_status_to_spendlogs		\N	2026-01-31 21:33:35.668333+00	0
fd456360-b9b1-4769-ab05-7bdf07fade42	5dc1434869d320eb9ed6568bcc92f4eb632fea62366eed392823a0af3bd640af	2026-01-31 21:33:39.749783+00	20250625213625_add_status_to_managed_object_table		\N	2026-01-31 21:33:39.749783+00	0
78854dd0-ffc9-4287-b408-614193e91ab4	375bcf8045e6cacdaeeca5e120516aa9bd57743e926f48cad66dbaeb09f6ad57	2026-01-31 21:33:44.825796+00	20251211100212_schema_sync		\N	2026-01-31 21:33:44.825796+00	0
b1f1e468-c3a8-44ca-a447-f93ad9129c78	2995debff237d65c97594d36025bb78a3ab246559222a6dab7f518d7ad0e7ee5	2026-01-31 21:33:49.072219+00	20260102131258_add_metadata_urls_to_mcp_servers		\N	2026-01-31 21:33:49.072219+00	0
66af5101-2a71-41d4-9955-0486fd855a25	43163c1cd8e8d780d058546d96906d8316949c8e017910fa3cd88059b4fa31ff	2026-01-31 21:33:53.418961+00	20251023141814_add_search_tool_table		\N	2026-01-31 21:33:53.418961+00	0
1abf0d56-7aff-45fd-a6a4-feb0860ec0e0	bf7bc3c7995be922c2cd709efc0d8d663ef3ce6b9c457334f1a42e9ff1bf3241	2026-01-31 21:33:57.698416+00	20250412081753_team_member_permissions		\N	2026-01-31 21:33:57.698416+00	0
7179a090-9ccd-47d2-8fba-816de2c0b73a	4c48b4f15d59400a2774ec5d4883fa3005363f99ee792a55be1b66768486a7e7	2026-01-31 21:34:02.738975+00	20251003190954_extra_headers_to_mcp_table		\N	2026-01-31 21:34:02.738975+00	0
65fe8c0f-d885-432f-850c-99a5beead94d	cf57e250e0ce30d07279233320182cdc47b40ee0c157024124465057c78d5d59	2026-01-31 21:34:06.992069+00	20251011084309_add_tag_table		\N	2026-01-31 21:34:06.992069+00	0
64c5057d-8238-4692-bf54-3e5cded706ce	a575214cba725cb8466839d3f9ea5bc96f9849d98ed73e7f7713ac1130f9dceb	2026-01-31 21:34:11.601866+00	20250415151647_add_cache_read_write_tokens_daily_spend_transactions		\N	2026-01-31 21:34:11.601866+00	0
e911dd1b-ac57-46a3-a4af-092546c5a7c0	1b634e352f5700c0dd907fb4b6968f8a62b87b3b3de21930b5e44ad66ee80356	2026-01-31 21:34:15.885473+00	20250507184818_add_mcp_key_team_permission_mgmt		\N	2026-01-31 21:34:15.885473+00	0
e2b87865-bdf0-4643-92d4-378939eab043	fb62f058ade2dab8ae181aab985b2e9e331b2d2fd34aeddac07d9a85545e4171	2026-01-31 21:34:20.171861+00	20260105151539_add_allow_all_keys_to_mcp_servers		\N	2026-01-31 21:34:20.171861+00	0
3b2e9226-dd6b-403a-96b7-3599d6f8219b	c997decf8f8729b65e450b3813a421acc03bc2ecab050ad8cd3ad6f52d47c1c6	2026-01-31 21:34:24.431542+00	20250718125714_add_litellm_params_to_vector_stores		\N	2026-01-31 21:34:24.431542+00	0
3b96b61d-6972-4f49-a566-e01602a24249	6027523e7df23ec7ba1e86465bd94512acb8f7139fe32b891ffaab7fc96b2481	2026-01-31 21:34:28.780189+00	20250926194702_unnamed_migration		\N	2026-01-31 21:34:28.780189+00	0
66575772-701c-48da-938c-25ff1c9b886a	86602dd2ebcf5eaf4dbed7fdd87a9186b193701c44156c313a3b06db34c2b60e	2026-01-31 21:34:33.018045+00	20250918083359_drop_spec_version_column_from_mcp_table		\N	2026-01-31 21:34:33.018045+00	0
dc9d5691-f846-42dd-8ea6-b924f03cb203	08ca2e7a2188cb6fbfec893b92dcc60913df8411f8dd8ee726402f7f17189c8d	2026-01-31 21:34:37.776272+00	20250528185438_add_vector_stores_to_object_permissions		\N	2026-01-31 21:34:37.776272+00	0
eaf794b4-841c-4048-98c7-db25ad3b39d7	33fcb8c4b9e5180a62508a2f2efd3103b94be60241656adc15eedbe4c4943a29	2026-01-31 21:34:42.285531+00	20250510142544_add_session_id_index_spend_logs		\N	2026-01-31 21:34:42.285531+00	0
76f26fe0-1c2a-4b47-95df-b2267c9494df	2335ef3fdd16e11d6f92bb0fdd66c04497462c415ab96d5ed9ccd399968360e3	2026-01-31 21:34:46.72258+00	20250507161527_add_health_check_fields_to_mcp_servers		\N	2026-01-31 21:34:46.72258+00	0
1190c083-95fc-4409-9bb6-5c590bbcac68	7319b878c87a1f6f1ad56c626dae19fd398624bb3e3a2c4e0899dc5cbbe00c0f	2026-01-31 21:34:51.138204+00	20251220144550_schema_update		\N	2026-01-31 21:34:51.138204+00	0
87bcacb9-3f06-4b62-8721-54ce89e15bce	f5a4569816cb7fb1166c231789f0e5e732fd6c0c34b8f5c9badd405cd2ab4931	2026-01-31 21:34:55.440901+00	20250326162113_baseline		\N	2026-01-31 21:34:55.440901+00	0
aef23c49-1ba5-44ac-8b3e-53872f0e95ef	6f77e1c9e11d0b02f2a89c894770b691314085239903f2cdcbf02476c37270ac	2026-01-31 21:34:59.860959+00	20251119131227_add_prompt_versioning		\N	2026-01-31 21:34:59.860959+00	0
249bc3fd-e19f-477c-8844-fcba250b35aa	2fdef74393d5e6915ca6e673c8ece8e9a14d2b4d8464af8a0077dcca3b4f0085	2026-01-31 21:35:04.39214+00	20250707230009_add_mcp_namespaced_tool_name		\N	2026-01-31 21:35:04.39214+00	0
a64b9dc5-266c-4f12-bb46-13182b76e983	0607b76d63bdea31615737631d7e6c0fb4b308b9ebad832affa8a5cc914043ac	2026-01-31 21:35:08.686909+00	20250806095134_rename_alias_to_server_name_mcp_table		\N	2026-01-31 21:35:08.686909+00	0
408b4ee1-c741-4a75-9fe4-12f53591b93b	dabeddae5a09b840f2fb1f7f7ec41707ad77609ee083ac88b0be4c84512ff8d9	2026-01-31 21:35:13.429996+00	20250707212517_add_mcp_info_column_mcp_servers		\N	2026-01-31 21:35:13.429996+00	0
c55849cf-e3fa-413e-bbb7-0b448941765a	3aadd5bc07b860d5a2f680d84ebde51ef9f4b1fb194bd3a04045117aceaa07cb	2026-01-31 21:35:17.590029+00	20251122125322_Add organization_id to spend logs		\N	2026-01-31 21:35:17.590029+00	0
fcd82618-e129-48ae-8797-67313ea21fad	0bfd2253a17e5d4493d017a4452ac518c5baf7fa7004b492ecfbb91ef18d27b7	2026-01-31 21:35:21.972928+00	20250507161526_add_mcp_table_to_db		\N	2026-01-31 21:35:21.972928+00	0
8317c61c-c724-407b-bc6c-cede01cb42a0	62ed8adfb43dd0b0e1c6c168ffae2c1f43d7752437b07b38e4bab3c6fdadff6d	2026-01-31 21:35:26.253029+00	20250411215431_add_managed_file_table		\N	2026-01-31 21:35:26.253029+00	0
4ca5dc9d-8f6b-4551-8b81-4ec25be77ec1	a7836f530f5ac8f20c3c3d714b979c4b7e078362fab46409c0521852e0353437	2026-01-31 21:35:30.667067+00	20251204124859_add_end_user_spend_table		\N	2026-01-31 21:35:30.667067+00	0
33a8d52d-6964-46e5-9f6d-ce4b0cbb7521	dc31f1e21264261b52f7bb4428245951d15913e53f759e57b28c02fee06e1e42	2026-01-31 21:35:35.59609+00	20260107111013_add_router_settings_to_keys_teams		\N	2026-01-31 21:35:35.59609+00	0
9995f958-78c1-485f-afad-a341c3883081	abfe3f18665811c1c7faab794a5dd88d11178f6c003d8bfd3528bf4c2d2ee46b	2026-01-31 21:35:40.66072+00	20251219110931_add_deleted_keys_and_deleted_teams_tables		\N	2026-01-31 21:35:40.66072+00	0
fbf55169-db2e-4c1d-bda9-ad241c013563	799343c2bccab56157913a8e29bf494b8873ba6d5d23e5535ef32ace1af27f17	2026-01-31 21:35:44.869667+00	20250329084805_new_cron_job_table		\N	2026-01-31 21:35:44.869667+00	0
d94b38b7-2022-4a05-917f-6daf2b700af9	de9867787bd0e1a9d957fc37ae917f845d005b75c9e7e8911eb00dbe36a00fa6	2026-01-31 21:35:48.960429+00	20251103072422_add_static_headers		\N	2026-01-31 21:35:48.960429+00	0
0b86261a-43fb-48a1-8201-5dbd5ba7faa2	a2be53684807e1c1f0479903bd58d9bdc023d4ec334f18eac0efa5c577b71579	2026-01-31 21:35:53.109574+00	20250327180120_add_api_requests_to_daily_user_table		\N	2026-01-31 21:35:53.109574+00	0
7af3f7f1-52be-406c-a26f-10c09d81ec8c	445212a424806fd61ac3040705d91aa7d4419fe36b05c9a17e5393c9426e9639	2026-01-31 21:35:57.354584+00	20251006143948_add_mcp_tool_permissions		\N	2026-01-31 21:35:57.354584+00	0
e09533d6-ab5f-48a3-a4b6-913eb38ea3ff	5c6c832c66a4a81b77d31b864be453e6d5a193f2a2eed79e9f1a6f283908a361	2026-01-31 21:36:01.653473+00	20250416185146_add_allowed_routes_litellm_verification_token		\N	2026-01-31 21:36:01.653473+00	0
eb7d08d0-288d-4f00-b074-2b9daee25fde	970381e45003962293d53a5dae4293ccd1c8db6b9713d49bc4e2e1e1f0dc7f9e	2026-01-31 21:36:06.027187+00	20260108_add_user_email_lower_idx		\N	2026-01-31 21:36:06.027187+00	0
b7aa97bf-714d-49bc-868c-6cd885f13f5e	6123b41b90fc467e82a739b6ab02c40170a47a80c636025f80a1c9a5245cbb21	2026-01-31 21:36:10.221853+00	20251104220043_add_credentials_to_mcp_servers		\N	2026-01-31 21:36:10.221853+00	0
6b3e0bd6-9794-47c9-99d5-1adcd39aa891	aba669fc21ae7c7b72380392509596df5a28769f9219edfafa4bd1713acfd361	2026-01-31 21:36:14.512676+00	20251114173537_add_request_id_to_daily_tag_spend		\N	2026-01-31 21:36:14.512676+00	0
c73910d2-6f36-483e-a685-2ca5f1489591	33c0c540ec483e319c25722cc1f1d0b362c14c5749c9006945ba4e4f94481e6c	2026-01-31 21:36:19.092024+00	20250415191926_add_daily_team_table		\N	2026-01-31 21:36:19.092024+00	0
46ca1453-9f0d-49d7-bce4-105c02c74e15	bf00cc5ee7db6e659bc2b18aae908253b5824ffc15a4dd204cd183605daed5e2	2026-01-31 21:36:23.777495+00	20260131213121_baseline_diff		\N	2026-01-31 21:36:23.777495+00	0
\.


--
-- Data for Name: add_on_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.add_on_categories (id, name, slug, description, icon, display_order, created_at, updated_at) FROM stdin;
1	AI Models	ai-models	Additional AI models and fine-tunes	\N	1	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
2	Integrations	integrations	Third-party service integrations	\N	2	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
3	Development Tools	dev-tools	Developer tools and utilities	\N	3	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
4	Monitoring	monitoring	System monitoring and analytics	\N	4	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
5	Security	security	Security and compliance tools	\N	5	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
6	Workflow Automation	automation	Workflow automation and orchestration	\N	6	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
7	Storage & Backup	storage	Storage solutions and backup tools	\N	7	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
8	Communication	communication	Communication and collaboration tools	\N	8	2026-01-25 00:54:28.890474	2026-01-25 00:54:28.890474
\.


--
-- Data for Name: add_on_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.add_on_purchases (id, user_id, add_on_id, stripe_session_id, stripe_payment_intent_id, amount_paid, currency, status, promo_code, discount_amount, features_granted, activated_at, expires_at, refunded_at, refund_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: add_on_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.add_on_reviews (id, add_on_id, user_id, rating, review_text, is_verified_purchase, helpful_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: add_ons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.add_ons (id, name, slug, description, long_description, category_id, base_price, currency, stripe_product_id, stripe_price_id, version, author, icon_url, screenshot_urls, features, requirements, compatibility, download_url, documentation_url, is_active, is_featured, install_count, rating, review_count, created_at, updated_at, category, launch_url, feature_key, billing_type, metadata, banner_url, support_url, trial_days, is_public, sort_order) FROM stdin;
1	Chat	chat	Chat UI	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/magic_unicorn_logo.png	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	ai	https://apps.example.com/chat	chat	monthly	{}	\N	\N	0	t	1
2	Search	search	Semantic search	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/open-webui.png	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	ai	https://apps.example.com/search	search	monthly	{}	\N	\N	0	t	2
3	LiteLLM Router	litellm	LLM routing	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/litellm-icon.jpg	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	ai	https://apps.example.com/litellm	litellm	monthly	{}	\N	\N	0	t	3
4	Priority Support	priority_support	Priority support desk	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/The_General_Logo.png	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	support	https://apps.example.com/support	priority_support	monthly	{}	\N	\N	0	t	4
5	Brigade	brigade	Task orchestration	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/forgejo-logo.svg	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	automation	https://apps.example.com/brigade	brigade	monthly	{}	\N	\N	0	t	5
6	Text to Speech	tts	TTS service	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/magicode-logo.svg	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	ai	https://apps.example.com/tts	tts	monthly	{}	\N	\N	0	t	6
7	Speech to Text	stt	STT service	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/magicode-logo.svg	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	ai	https://apps.example.com/stt	stt	monthly	{}	\N	\N	0	t	7
8	Bolt	bolt	Managed inference	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/bolt-diy-logo.png	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	ai	https://apps.example.com/bolt	bolt	monthly	{}	\N	\N	0	t	8
9	Billing	billing	Billing portal	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/lago-icon.png	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	billing	https://apps.example.com/billing	billing	monthly	{}	\N	\N	0	t	9
10	Dedicated Support	dedicated_support	Dedicated TAM	\N	\N	0.00	\N	\N	\N	\N	\N	https://kubeworkz.io/logos/The_Colonel.png	\N	{}	\N	\N	\N	\N	t	f	\N	\N	\N	2026-01-25 00:55:18.381234	2026-01-25 00:55:18.381234	support	https://apps.example.com/dedicated-support	dedicated_support	monthly	{}	\N	\N	0	t	10
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
20251101_extensions
\.


--
-- Data for Name: alert_correlations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_correlations (id, correlation_group_id, alert_id, is_root_cause, correlation_score, correlation_type, detected_at, metadata) FROM stdin;
\.


--
-- Data for Name: alert_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_feedback (id, alert_id, user_id, feedback_type, rating, comment, action_taken, time_to_acknowledge_seconds, created_at) FROM stdin;
\.


--
-- Data for Name: alert_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_predictions (id, device_id, metric_name, prediction_type, predicted_at, will_occur_at, confidence, current_value, predicted_value, threshold_value, time_to_critical_minutes, recommendation, alert_id, actually_occurred, accuracy_score, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: alert_suppression_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_suppression_rules (id, name, description, rule_type, conditions, action, priority, active, organization_id, created_by, alerts_suppressed, last_matched_at, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: anomaly_detections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.anomaly_detections (id, device_id, metric_name, detected_at, metric_value, expected_value, expected_range_min, expected_range_max, anomaly_score, model_id, model_type, confidence, severity, alert_id, false_positive, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, key_hash, key_prefix, email, subscription_id, name, description, is_active, is_revoked, revoked_at, revoked_reason, rate_limit_per_minute, rate_limit_per_hour, rate_limit_per_day, monthly_quota, scopes, last_used_at, created_at, expires_at, total_requests, metadata) FROM stdin;
\.


--
-- Data for Name: app_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_definitions (id, app_key, app_name, category, description, is_active, sort_order, created_at, updated_at) FROM stdin;
1	dashboard	Dashboard	services	Main system dashboard with overview and monitoring	t	1	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
2	monitoring	System Monitoring	services	Real-time system resource monitoring	t	2	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
3	alerts	Smart Alerts	services	Intelligent alerting and notification system	t	3	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
4	llm_hub	LLM Hub	services	AI/LLM model management and integration	t	4	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
5	analytics	Analytics	services	Advanced analytics and reporting	t	5	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
6	backup	Backup & Recovery	support	System backup and recovery tools	t	6	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
7	api_access	API Access	support	RESTful API access for integrations	t	7	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
8	kubernetes	Kubernetes	enterprise	Kubernetes cluster management	t	8	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
9	fleet_management	Fleet Management	enterprise	Multi-server fleet management	t	9	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
10	cost_optimization	Cost Optimization	enterprise	Resource cost optimization tools	t	10	2026-01-31 19:12:15.949343	2026-01-31 19:12:15.949343
\.


--
-- Data for Name: app_model_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_model_list_items (id, list_id, model_id, display_name, description, category, sort_order, is_free, context_length, tier_trial, tier_starter, tier_professional, tier_enterprise, tier_vip_founder, tier_byok, created_at, updated_at, is_featured, is_active, metadata) FROM stdin;
1	1	qwen/qwen3-coder:free	Qwen3 Coder (Free)	Best FREE coding model - excellent for code generation and debugging	coding	1	t	262144	t	t	t	t	t	t	2026-02-01 20:28:29.453707+00	2026-02-01 20:28:29.453707+00	f	t	\N
2	1	deepseek/deepseek-r1:free	DeepSeek R1 (Free)	Excellent for complex reasoning and problem solving	reasoning	2	t	163840	t	t	t	t	t	t	2026-02-01 20:28:29.455264+00	2026-02-01 20:28:29.455264+00	f	t	\N
3	1	google/gemini-2.0-flash-exp:free	Gemini 2.0 Flash (Free)	Fast, versatile model for general tasks with large context	general	3	t	1048576	t	t	t	t	t	t	2026-02-01 20:28:29.455913+00	2026-02-01 20:28:29.455913+00	f	t	\N
4	1	google/gemini-2.5-flash-preview-05-20:free	Gemini 2.5 Flash Preview (Free)	Latest Gemini preview with improved capabilities	fast	4	t	1048576	t	t	t	t	t	t	2026-02-01 20:28:29.457161+00	2026-02-01 20:28:29.457161+00	f	t	\N
5	1	mistralai/mistral-small-3.1-24b-instruct:free	Mistral Small 3.1 (Free)	Efficient small model for quick responses	general	5	t	32768	t	t	t	t	t	t	2026-02-01 20:28:29.457984+00	2026-02-01 20:28:29.457984+00	f	t	\N
6	1	meta-llama/llama-3.3-70b-instruct:free	Llama 3.3 70B (Free)	Large open-source model with great general performance	general	6	t	131072	t	t	t	t	t	t	2026-02-01 20:28:29.458661+00	2026-02-01 20:28:29.458661+00	f	t	\N
7	2	qwen/qwen3-coder:free	Qwen3 Coder (Free)	Best FREE coding model - ideal for code generation, debugging, and refactoring	coding	1	t	262144	t	t	t	t	t	t	2026-02-01 20:28:29.460466+00	2026-02-01 20:28:29.460466+00	f	t	\N
8	2	deepseek/deepseek-r1:free	DeepSeek R1 (Free)	Great for complex problems requiring step-by-step reasoning	reasoning	2	t	163840	t	t	t	t	t	t	2026-02-01 20:28:29.461106+00	2026-02-01 20:28:29.461106+00	f	t	\N
9	2	google/gemini-2.0-flash-exp:free	Gemini 2.0 Flash (Free)	Fast iterations with massive 1M context window	fast	3	t	1048576	t	t	t	t	t	t	2026-02-01 20:28:29.461656+00	2026-02-01 20:28:29.461656+00	f	t	\N
10	2	meta-llama/llama-3.3-70b-instruct:free	Llama 3.3 70B (Free)	Strong general performance for various coding tasks	general	4	t	131072	t	t	t	t	t	t	2026-02-01 20:28:29.462219+00	2026-02-01 20:28:29.462219+00	f	t	\N
11	2	mistralai/mistral-small-3.1-24b-instruct:free	Mistral Small 3.1 (Free)	Efficient model for quick code completions	general	5	t	32768	t	t	t	t	t	t	2026-02-01 20:28:29.462771+00	2026-02-01 20:28:29.462771+00	f	t	\N
12	2	deepseek/deepseek-chat-v3-0324:free	DeepSeek Chat V3 (Free)	Good all-around model for code discussion	general	6	t	65536	t	t	t	t	t	t	2026-02-01 20:28:29.463363+00	2026-02-01 20:28:29.463363+00	f	t	\N
13	3	google/gemini-2.0-flash-exp:free	Gemini 2.0 Flash (Free)	Excellent for presentations - fast, creative, and handles long content well	general	1	t	1048576	t	t	t	t	t	t	2026-02-01 20:28:29.46467+00	2026-02-01 20:28:29.46467+00	f	t	\N
14	3	deepseek/deepseek-chat-v3-0324:free	DeepSeek Chat V3 (Free)	Good for generating well-structured presentation content	general	2	t	65536	t	t	t	t	t	t	2026-02-01 20:28:29.465274+00	2026-02-01 20:28:29.465274+00	f	t	\N
15	3	mistralai/mistral-small-3.1-24b-instruct:free	Mistral Small 3.1 (Free)	Creative writing and engaging slide narratives	creative	3	t	32768	t	t	t	t	t	t	2026-02-01 20:28:29.465906+00	2026-02-01 20:28:29.465906+00	f	t	\N
16	3	meta-llama/llama-3.3-70b-instruct:free	Llama 3.3 70B (Free)	Strong general performance for diverse presentation topics	general	4	t	131072	t	t	t	t	t	t	2026-02-01 20:28:29.466498+00	2026-02-01 20:28:29.466498+00	f	t	\N
17	3	google/gemini-2.5-flash-preview-05-20:free	Gemini 2.5 Flash Preview (Free)	Latest preview with improved content generation	fast	5	t	1048576	t	t	t	t	t	t	2026-02-01 20:28:29.467107+00	2026-02-01 20:28:29.467107+00	f	t	\N
18	4	google/gemini-2.0-flash-exp:free	Gemini 2.0 Flash (Free)	Best all-around model - fast, capable, and free	general	1	t	1048576	t	t	t	t	t	t	2026-02-01 20:28:29.468686+00	2026-02-01 20:28:29.468686+00	f	t	\N
19	4	meta-llama/llama-3.3-70b-instruct:free	Llama 3.3 70B (Free)	Large open-source model for comprehensive responses	general	2	t	131072	t	t	t	t	t	t	2026-02-01 20:28:29.469308+00	2026-02-01 20:28:29.469308+00	f	t	\N
20	4	deepseek/deepseek-r1:free	DeepSeek R1 (Free)	Advanced reasoning for complex questions	reasoning	3	t	163840	t	t	t	t	t	t	2026-02-01 20:28:29.469957+00	2026-02-01 20:28:29.469957+00	f	t	\N
21	4	mistralai/mistral-small-3.1-24b-instruct:free	Mistral Small 3.1 (Free)	Quick and efficient for everyday queries	general	4	t	32768	t	t	t	t	t	t	2026-02-01 20:28:29.470653+00	2026-02-01 20:28:29.470653+00	f	t	\N
22	4	qwen/qwen3-coder:free	Qwen3 Coder (Free)	Specialized for coding-related questions	coding	5	t	262144	t	t	t	t	t	t	2026-02-01 20:28:29.471255+00	2026-02-01 20:28:29.471255+00	f	t	\N
\.


--
-- Data for Name: app_model_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_model_lists (id, name, slug, description, app_identifier, is_default, is_active, created_at, updated_at, created_by) FROM stdin;
2	Bolt.diy Coding	bolt-diy	Coding-focused models optimized for AI development environment	bolt-diy	t	t	2026-02-01 20:28:29.459561+00	2026-02-01 20:28:29.459561+00	system
3	Presenton Content	presenton	Content generation models optimized for AI presentation creation	presenton	t	t	2026-02-01 20:28:29.464149+00	2026-02-01 20:28:29.464149+00	system
4	Open-WebUI General	open-webui	General purpose models for the main chat interface	open-webui	t	t	2026-02-01 20:28:29.468083+00	2026-02-01 20:28:29.468083+00	system
1	Global Default	global	Best FREE models for all apps - used as fallback when no app-specific list exists	global	t	t	2026-02-01 20:27:46.340092+00	2026-02-01 21:32:23.052717+00	system
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "timestamp", user_id, organization_id, action, resource_type, resource_id, details, ip_address, user_agent, status, metadata_json) FROM stdin;
\.


--
-- Data for Name: branding_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branding_assets (id, org_id, asset_type, file_name, file_path, file_size, mime_type, width, height, is_active, uploaded_at, uploaded_by) FROM stdin;
\.


--
-- Data for Name: branding_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branding_audit_log (id, org_id, action, changes, performed_by, ip_address, user_agent, created_at) FROM stdin;
1	test-org-002	create	{"message": "Organization branding created"}	1	\N	\N	2026-01-25 21:10:37.522151+00
2	epic45-test-1769375477	create	{"message": "Organization branding created"}	1	\N	\N	2026-01-25 21:11:17.879693+00
3	epic45-test-1769375477	update	{"tagline": "Building the Future", "primary_color": "#8B5CF6"}	1	\N	\N	2026-01-25 21:11:18.051475+00
4	epic45-test-1769375486	create	{"message": "Organization branding created"}	1	\N	\N	2026-01-25 21:11:26.351378+00
5	epic45-test-1769375486	update	{"tagline": "Building the Future", "primary_color": "#8B5CF6"}	1	\N	\N	2026-01-25 21:11:26.534989+00
6	epic45-test-999	create	{"message": "Organization branding created"}	1	\N	\N	2026-01-25 21:11:35.482943+00
7	epic45-test-abc123	create	{"message": "Organization branding created"}	1	\N	\N	2026-01-25 21:17:21.453854+00
8	epic45-test-1769375856	create	{"message": "Organization branding created"}	1	\N	\N	2026-01-25 21:17:37.085495+00
9	epic45-test-1769375856	update	{"tagline": "Building the Future", "primary_color": "#8B5CF6"}	1	\N	\N	2026-01-25 21:17:37.299363+00
\.


--
-- Data for Name: branding_tier_limits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branding_tier_limits (id, tier_code, max_logo_size_mb, max_assets, custom_colors, custom_fonts, custom_domain, custom_email_branding, remove_powered_by, custom_login_page, custom_css, api_white_label, created_at, updated_at) FROM stdin;
1	trial	1.00	2	f	f	f	f	f	f	f	f	2026-01-25 20:46:16.942898+00	2026-01-25 20:46:16.942898+00
2	starter	2.00	5	t	f	f	f	f	f	f	f	2026-01-25 20:46:16.942898+00	2026-01-25 20:46:16.942898+00
3	professional	5.00	10	t	t	t	t	f	t	f	f	2026-01-25 20:46:16.942898+00	2026-01-25 20:46:16.942898+00
4	enterprise	10.00	20	t	t	t	t	t	t	t	t	2026-01-25 20:46:16.942898+00	2026-01-25 20:46:16.942898+00
5	vip_founder	10.00	50	t	t	t	t	t	t	t	t	2026-01-25 20:46:16.942898+00	2026-01-25 20:46:16.942898+00
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, organization_id, name, description, budget_type, total_limit, warning_threshold, critical_threshold, start_date, end_date, current_spend, last_calculated_at, alert_enabled, alert_contacts, last_alert_sent, alert_level, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: byok_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.byok_keys (id, user_id, key_name, provider, encrypted_key, created_at, updated_at, last_tested_at, is_valid) FROM stdin;
\.


--
-- Data for Name: byok_pricing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.byok_pricing_rules (id, model_pattern, markup_percentage, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_items (id, user_id, add_on_id, quantity, added_at) FROM stdin;
\.


--
-- Data for Name: cloud_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloud_credentials (credential_id, name, provider, credentials, region, description, created_by, created_at, updated_at, last_used_at, is_default) FROM stdin;
\.


--
-- Data for Name: cloudflare_dns_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloudflare_dns_records (id, zone_id, record_id, record_type, name, content, proxied, ttl, priority, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cloudflare_domains; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloudflare_domains (id, domain_name, domain_id, user_id, zone_id, registration_date, expiration_date, auto_renew, is_locked, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cloudflare_firewall_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloudflare_firewall_rules (id, zone_id, rule_id, rule_name, expression, action, enabled, priority, description, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cloudflare_zones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloudflare_zones (id, zone_id, zone_name, account_id, status, name_servers, created_on, modified_on, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_controls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_controls (id, control_id, category, title, description, implementation_status, automated, check_frequency, last_check_at, last_check_status, last_check_result, evidence_required, assigned_to, target_completion_date, created_at, updated_at) FROM stdin;
1	CC6.1	Security	Logical and Physical Access Controls	The entity implements logical access security software, infrastructure, and architectures over protected information assets to protect them from security events to meet the entity objectives.	not_implemented	t	daily	\N	\N	\N	{access_logs,authentication_logs,rbac_configuration}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
2	CC6.2	Security	Prior to Issuing System Credentials	Prior to issuing system credentials and granting system access, the entity registers and authorizes new internal and external users whose access is administered by the entity.	not_implemented	t	daily	\N	\N	\N	{user_registration_logs,approval_workflows}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
3	CC6.3	Security	User Access Removal	The entity removes access to the system when access is no longer required or when there is a change in job responsibilities.	not_implemented	t	daily	\N	\N	\N	{deprovisioning_logs,access_review_reports}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
4	CC6.6	Security	Logical Access Restrictions	The entity implements logical access security measures to protect against threats from sources outside its system boundaries.	not_implemented	t	hourly	\N	\N	\N	{firewall_logs,intrusion_detection_logs}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
5	CC6.7	Security	Encryption in Transit	The entity restricts the transmission, movement, and removal of information to authorized internal and external users and processes.	not_implemented	t	daily	\N	\N	\N	{ssl_configuration,encryption_status}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
6	CC6.8	Security	Encryption at Rest	The entity implements controls to prevent or detect and act upon the introduction of unauthorized or malicious software.	not_implemented	t	daily	\N	\N	\N	{encryption_configuration,key_management_logs}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
7	A1.1	Availability	System Availability Monitoring	The entity maintains, monitors, and evaluates current processing capacity and use of system components.	not_implemented	t	hourly	\N	\N	\N	{uptime_reports,monitoring_dashboards}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
9	A1.3	Availability	Incident Response	The entity provides for the identification, reporting, and remediation of system availability issues in a timely manner.	not_implemented	t	hourly	\N	\N	\N	{incident_logs,response_times}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
8	A1.2	Availability	System Recovery Procedures	The entity authorizes, designs, develops or acquires, implements, operates, approves, maintains, and monitors environmental protections, software, data backup processes, and recovery infrastructure.	not_implemented	t	daily	\N	\N	\N	{backup_logs,recovery_test_results}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
10	PI1.1	Processing Integrity	Data Validation	The entity implements policies and procedures over system inputs, including those for data or other inputs from vendors and business partners.	not_implemented	t	daily	\N	\N	\N	{validation_logs,input_schemas}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
11	PI1.2	Processing Integrity	Error Detection	The entity implements policies and procedures to manage system processing.	not_implemented	t	hourly	\N	\N	\N	{error_logs,exception_reports}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
12	PI1.4	Processing Integrity	Data Output Accuracy	The entity implements policies and procedures to make available or deliver output completely, accurately, and timely.	not_implemented	t	daily	\N	\N	\N	{output_validation_logs,accuracy_reports}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
13	C1.1	Confidentiality	Confidential Data Identification	The entity identifies and maintains confidential information to meet the entity objectives related to confidentiality.	not_implemented	f	quarterly	\N	\N	\N	{data_classification,inventory_reports}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
14	C1.2	Confidentiality	Confidential Data Access	The entity disposes of confidential information to meet the entity objectives related to confidentiality.	not_implemented	t	daily	\N	\N	\N	{access_logs,authorization_logs}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
15	P1.1	Privacy	Data Collection Notice	The entity provides notice to data subjects about its privacy practices.	not_implemented	f	quarterly	\N	\N	\N	{privacy_policy,user_notifications}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
16	P1.2	Privacy	Data Subject Rights	The entity provides data subjects with the ability to exercise rights related to their personal information.	not_implemented	f	monthly	\N	\N	\N	{data_access_requests,deletion_requests}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
17	P3.1	Privacy	Data Retention and Disposal	The entity retains personal information consistent with its objectives related to privacy.	not_implemented	t	weekly	\N	\N	\N	{retention_policies,disposal_logs}	\N	\N	2026-01-27 00:53:22.060686	2026-01-27 00:53:22.063758
\.


--
-- Data for Name: compliance_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_evidence (id, evidence_id, control_id, evidence_type, title, description, collected_at, collected_by, collection_method, data, file_path, file_hash, retention_period_days, expires_at, tags, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_metrics (id, metric_id, metric_name, metric_category, metric_value, metric_unit, threshold_warning, threshold_critical, status, dimensions, collected_at) FROM stdin;
\.


--
-- Data for Name: compliance_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_reports (id, report_id, report_type, title, description, period_start, period_end, generated_at, generated_by, format, status, file_path, file_size_bytes, findings_summary, controls_passed, controls_failed, controls_warning, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_schedules (id, schedule_id, control_id, schedule_type, frequency, next_run_at, last_run_at, last_run_status, enabled, notification_emails, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_analysis (id, organization_id, user_id, period_start, period_end, period_type, model_name, provider, total_requests, total_tokens, input_tokens, output_tokens, total_cost, input_cost, output_cost, avg_latency_ms, error_count, error_rate, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_forecasts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_forecasts (id, organization_id, budget_id, forecast_date, forecast_horizon_days, predicted_cost, confidence_lower, confidence_upper, confidence_level, forecast_model, model_accuracy, historical_days_used, seasonality_detected, trend_direction, trend_strength, budget_exhaustion_date, days_until_exhaustion, created_at) FROM stdin;
\.


--
-- Data for Name: cost_recommendations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_recommendations (id, organization_id, recommendation_type, title, description, current_monthly_cost, projected_monthly_cost, estimated_savings, savings_percentage, priority_score, confidence_score, implementation_difficulty, quality_impact, quality_score_change, recommended_action, analysis_data, status, implemented_at, implemented_by, actual_savings, results_verified_at, valid_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credit_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_packages (id, package_code, package_name, credits, price_usd, discount_percentage, badge_text, description, is_featured, is_active, created_at, updated_at, display_order, stripe_price_id, stripe_product_id) FROM stdin;
1	starter	Starter Pack	100	10.00	0	\N	Perfect for trying out our AI services	f	t	2026-02-02 22:28:54.514533+00	2026-02-02 22:28:54.514533+00	1	price_1SwVqmHbRbwEK4CvcL5hAc3F	prod_TuKVovC88ksGFZ
2	basic	Basic Pack	500	45.00	10	SAVE 10%	Great value for regular users	f	t	2026-02-02 22:28:54.514533+00	2026-02-02 22:28:54.514533+00	2	price_1SwVqnHbRbwEK4CvTsMKkc67	prod_TuKVHPRi2YxyWv
3	pro	Pro Pack	1000	85.00	15	SAVE 15%	Best for professionals	t	t	2026-02-02 22:28:54.514533+00	2026-02-02 22:28:54.514533+00	3	price_1SwVqnHbRbwEK4CvThpwFUNb	prod_TuKVaUtGyma10r
4	premium	Premium Pack	2500	200.00	20	SAVE 20%	Maximum value for power users	t	t	2026-02-02 22:28:54.514533+00	2026-02-02 22:28:54.514533+00	4	price_1SwVqoHbRbwEK4CvbYf8qLR7	prod_TuKVgYgGJ2w0yO
5	enterprise	Enterprise Pack	10000	750.00	25	BEST VALUE	For teams and organizations	t	t	2026-02-02 22:28:54.514533+00	2026-02-02 22:28:54.514533+00	5	price_1SwVqoHbRbwEK4CvkQtoxY6W	prod_TuKVKfXrXyD4Bt
\.


--
-- Data for Name: credit_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_purchases (id, user_id, package_name, amount_credits, amount_paid, stripe_checkout_session_id, stripe_payment_id, status, metadata, created_at, completed_at, stripe_payment_intent_id, updated_at) FROM stdin;
1	68a6a9cc-8d91-45bf-80f0-8d125b297876	Premium Pack	2500.00	200.00	cs_test_a1CqnJlHSVDr5m8Ly718nkvPtiEL1CuwkfsNu4mrk14TTDCYTl1MXKBxxP	\N	pending	{"package_code": "premium", "discount_percentage": 20}	2026-02-02 23:01:12.307135	\N	\N	2026-02-02 23:01:12.307135
2	68a6a9cc-8d91-45bf-80f0-8d125b297876	Premium Pack	2500.00	200.00	cs_test_a15jQoobGezCfrdGzsVAkwUwinZKwQ51qXbwNOAlVu6KohPN7UiyBFWGsC	\N	pending	{"package_code": "premium", "discount_percentage": 20}	2026-02-02 23:05:16.697643	\N	\N	2026-02-02 23:05:16.697643
3	68a6a9cc-8d91-45bf-80f0-8d125b297876	Pro Pack	1000.00	85.00	cs_test_a1VxgFRaCusCgUkDyxTqhmA1dPS5DGBgGe8TIjmyciguMlUM7bstGpHlOB	\N	pending	{"package_code": "pro", "discount_percentage": 15}	2026-02-02 23:06:38.647805	\N	\N	2026-02-02 23:06:38.647805
4	68a6a9cc-8d91-45bf-80f0-8d125b297876	Premium Pack	2500.00	200.00	cs_test_a1adLiGVcG086Ezq1cTxautrBZrnTduywd2148E2vVqgGr4QWe8cgLI2gx	\N	pending	{"package_code": "premium", "discount_percentage": 20}	2026-02-02 23:09:55.980778	\N	\N	2026-02-02 23:09:55.980778
5	68a6a9cc-8d91-45bf-80f0-8d125b297876	Pro Pack	1000.00	85.00	cs_test_a1aqYBh7rhqWgYqkWtn0MvnaM4JBVgwFhKFBo9qx34R33n23GEo9e4Z6A2	\N	pending	{"package_code": "pro", "discount_percentage": 15}	2026-02-02 23:12:59.94867	\N	\N	2026-02-02 23:12:59.94867
\.


--
-- Data for Name: credit_usage_attribution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_usage_attribution (id, user_id, org_id, credits_used, model_name, request_id, created_at, service_type) FROM stdin;
\.


--
-- Data for Name: custom_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_roles (id, name, organization_id, description, is_system_role, created_by, created_at, updated_at) FROM stdin;
1	super_admin	\N	Full system access with all permissions	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
2	org_admin	\N	Organization administrator with full org access	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
3	org_manager	\N	Organization manager with limited admin capabilities	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
4	org_member	\N	Standard organization member	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
5	billing_admin	\N	Billing and payment management only	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
6	developer	\N	API access and development tools	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
7	analyst	\N	Read-only access to analytics and reports	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
8	support	\N	Support team with read access and limited actions	t	\N	2026-01-27 00:24:52.186761	2026-01-27 00:24:52.186761
\.


--
-- Data for Name: data_retention_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_retention_policies (id, policy_id, data_type, retention_period_days, deletion_method, legal_hold, legal_hold_reason, compliance_basis, last_purge_at, next_purge_at, auto_purge_enabled, notification_before_days, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_history (id, provider_id, recipient, subject, status, message_id, error_message, sent_at) FROM stdin;
1	2	dave@gridworkz.com	Test Email from Ops Center	sent	83e80f76-4364-4b6a-8034-71f4af6fcee9	\N	2026-01-30 01:23:36.421734
2	2	dave@gridworkz.com	Test Email from Ops Center	sent	0bda026f-c830-4254-90df-b7fdc91bea2c	\N	2026-01-30 02:42:37.043016
3	2	dave@gridworkz.com	Test Email from Ops Center	sent	0e1f985c-568f-487b-b1db-ec1dcca9a38c	\N	2026-01-30 03:00:03.37243
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, to_email, subject, html_body, text_body, success, error_message, metadata, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: email_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_providers (id, provider_type, auth_method, enabled, smtp_host, smtp_port, smtp_user, smtp_from, smtp_password, api_key, oauth2_client_id, oauth2_client_secret, oauth2_tenant_id, oauth2_refresh_token, provider_config, created_at, updated_at, created_by, name) FROM stdin;
2	postmark	api_key	t	\N	\N	\N	support@kubeworkz.io	\N	c1f051b7-6f60-4273-a173-3ad19d4a95e8	\N	\N	\N	\N	{"aws_region": "us-east-1"}	2026-01-29 21:15:23.919904	2026-01-30 23:23:30.321792	\N	Postmark
\.


--
-- Data for Name: iac_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iac_templates (template_id, name, description, category, cloud_provider, template_type, source_code, variables, outputs, version, created_by, created_at, updated_at, is_public, downloads_count, tags) FROM stdin;
7356a61f-7fe8-4cd6-8832-bb4721a7e68d	AWS EC2 Instance	Basic AWS EC2 instance with security group	compute	aws	terraform	terraform {\n  required_providers {\n    aws = {\n      source  = "hashicorp/aws"\n      version = "~> 5.0"\n    }\n  }\n}\n\nvariable "instance_type" {\n  description = "EC2 instance type"\n  type        = string\n  default     = "t3.micro"\n}\n\nvariable "ami_id" {\n  description = "AMI ID"\n  type        = string\n}\n\nresource "aws_instance" "main" {\n  ami           = var.ami_id\n  instance_type = var.instance_type\n\n  tags = {\n    Name = "terraform-instance"\n  }\n}\n\noutput "instance_id" {\n  value = aws_instance.main.id\n}\n\noutput "public_ip" {\n  value = aws_instance.main.public_ip\n}	{"ami_id": {"type": "string", "required": true}, "instance_type": {"type": "string", "default": "t3.micro"}}	{"public_ip": "string", "instance_id": "string"}	1.0.0	\N	2026-01-27 01:21:52.226086	2026-01-27 01:21:52.22874	f	0	{aws,compute,ec2}
bfab64b5-baca-4ead-9362-df275ce6f799	Kubernetes Namespace	Create Kubernetes namespace with resource quotas	kubernetes	kubernetes	terraform	terraform {\n  required_providers {\n    kubernetes = {\n      source  = "hashicorp/kubernetes"\n      version = "~> 2.0"\n    }\n  }\n}\n\nvariable "namespace_name" {\n  description = "Namespace name"\n  type        = string\n}\n\nvariable "cpu_limit" {\n  description = "CPU limit"\n  type        = string\n  default     = "2"\n}\n\nvariable "memory_limit" {\n  description = "Memory limit"\n  type        = string\n  default     = "4Gi"\n}\n\nresource "kubernetes_namespace" "main" {\n  metadata {\n    name = var.namespace_name\n  }\n}\n\nresource "kubernetes_resource_quota" "main" {\n  metadata {\n    name      = "${var.namespace_name}-quota"\n    namespace = kubernetes_namespace.main.metadata[0].name\n  }\n\n  spec {\n    hard = {\n      "requests.cpu"    = var.cpu_limit\n      "requests.memory" = var.memory_limit\n      "limits.cpu"      = var.cpu_limit\n      "limits.memory"   = var.memory_limit\n    }\n  }\n}\n\noutput "namespace" {\n  value = kubernetes_namespace.main.metadata[0].name\n}	{"cpu_limit": {"type": "string", "default": "2"}, "memory_limit": {"type": "string", "default": "4Gi"}, "namespace_name": {"type": "string", "required": true}}	{"namespace": "string"}	1.0.0	\N	2026-01-27 01:21:52.226086	2026-01-27 01:21:52.22874	f	0	{kubernetes,namespace,quota}
9e9d8d3b-ebc4-4e7b-a3fa-b3cac9f1110d	Azure VM	Azure Virtual Machine with managed disk	compute	azure	terraform	terraform {\n  required_providers {\n    azurerm = {\n      source  = "hashicorp/azurerm"\n      version = "~> 3.0"\n    }\n  }\n}\n\nvariable "location" {\n  description = "Azure region"\n  type        = string\n  default     = "eastus"\n}\n\nvariable "vm_size" {\n  description = "VM size"\n  type        = string\n  default     = "Standard_B2s"\n}\n\nresource "azurerm_resource_group" "main" {\n  name     = "rg-terraform"\n  location = var.location\n}\n\nresource "azurerm_virtual_network" "main" {\n  name                = "vnet-main"\n  address_space       = ["10.0.0.0/16"]\n  location            = azurerm_resource_group.main.location\n  resource_group_name = azurerm_resource_group.main.name\n}\n\nresource "azurerm_subnet" "main" {\n  name                 = "subnet-main"\n  resource_group_name  = azurerm_resource_group.main.name\n  virtual_network_name = azurerm_virtual_network.main.name\n  address_prefixes     = ["10.0.1.0/24"]\n}\n\noutput "resource_group_id" {\n  value = azurerm_resource_group.main.id\n}	{"vm_size": {"type": "string", "default": "Standard_B2s"}, "location": {"type": "string", "default": "eastus"}}	{"resource_group_id": "string"}	1.0.0	\N	2026-01-27 01:21:52.226086	2026-01-27 01:21:52.22874	f	0	{azure,compute,vm}
2cc7b657-033c-4807-82ce-aa3cb732112e	GCP Compute Instance	Google Cloud Compute Engine instance	compute	gcp	terraform	terraform {\n  required_providers {\n    google = {\n      source  = "hashicorp/google"\n      version = "~> 5.0"\n    }\n  }\n}\n\nvariable "project_id" {\n  description = "GCP project ID"\n  type        = string\n}\n\nvariable "zone" {\n  description = "GCP zone"\n  type        = string\n  default     = "us-central1-a"\n}\n\nvariable "machine_type" {\n  description = "Machine type"\n  type        = string\n  default     = "e2-micro"\n}\n\nresource "google_compute_instance" "main" {\n  name         = "terraform-instance"\n  machine_type = var.machine_type\n  zone         = var.zone\n  project      = var.project_id\n\n  boot_disk {\n    initialize_params {\n      image = "debian-cloud/debian-11"\n    }\n  }\n\n  network_interface {\n    network = "default"\n  }\n}\n\noutput "instance_id" {\n  value = google_compute_instance.main.instance_id\n}	{"zone": {"type": "string", "default": "us-central1-a"}, "project_id": {"type": "string", "required": true}, "machine_type": {"type": "string", "default": "e2-micro"}}	{"instance_id": "string"}	1.0.0	\N	2026-01-27 01:21:52.226086	2026-01-27 01:21:52.22874	f	0	{gcp,compute,instance}
3e8a687c-d792-493a-9678-5aebfee8e6af	S3 Bucket with Versioning	AWS S3 bucket with versioning and encryption	storage	aws	terraform	terraform {\n  required_providers {\n    aws = {\n      source  = "hashicorp/aws"\n      version = "~> 5.0"\n    }\n  }\n}\n\nvariable "bucket_name" {\n  description = "S3 bucket name"\n  type        = string\n}\n\nvariable "enable_versioning" {\n  description = "Enable versioning"\n  type        = bool\n  default     = true\n}\n\nresource "aws_s3_bucket" "main" {\n  bucket = var.bucket_name\n}\n\nresource "aws_s3_bucket_versioning" "main" {\n  bucket = aws_s3_bucket.main.id\n\n  versioning_configuration {\n    status = var.enable_versioning ? "Enabled" : "Suspended"\n  }\n}\n\nresource "aws_s3_bucket_server_side_encryption_configuration" "main" {\n  bucket = aws_s3_bucket.main.id\n\n  rule {\n    apply_server_side_encryption_by_default {\n      sse_algorithm = "AES256"\n    }\n  }\n}\n\noutput "bucket_id" {\n  value = aws_s3_bucket.main.id\n}\n\noutput "bucket_arn" {\n  value = aws_s3_bucket.main.arn\n}	{"bucket_name": {"type": "string", "required": true}, "enable_versioning": {"type": "bool", "default": true}}	{"bucket_id": "string", "bucket_arn": "string"}	1.0.0	\N	2026-01-27 01:21:52.226086	2026-01-27 01:21:52.22874	f	0	{aws,storage,s3,security}
\.


--
-- Data for Name: invite_code_redemptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invite_code_redemptions (id, invite_code_id, user_id, user_email, redeemed_at) FROM stdin;
\.


--
-- Data for Name: invite_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invite_codes (id, code, tier_code, max_uses, current_uses, expires_at, is_active, created_by, created_at, updated_at, notes) FROM stdin;
3	VIP-FOUNDER-TQG67R	starter	\N	0	\N	t	dave@gridworkz.com	2026-02-02 22:21:33.701978	2026-02-02 22:21:33.701978	
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, subscription_id, stripe_invoice_id, amount, currency, status, invoice_url, invoice_pdf, issued_at, due_date, paid_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_clusters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_clusters (id, organization_id, name, description, kubeconfig_encrypted, context_name, api_server_url, cluster_version, provider, region, environment, status, health_status, last_sync_at, last_error, total_nodes, total_namespaces, total_pods, total_deployments, estimated_monthly_cost, cost_currency, tags, metadata, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: k8s_cost_attribution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_cost_attribution (id, cluster_id, namespace_id, organization_id, date, hour, cpu_cost, memory_cost, storage_cost, network_cost, total_cost, cpu_core_hours, memory_gb_hours, storage_gb_hours, network_gb, team_name, cost_center, created_at) FROM stdin;
\.


--
-- Data for Name: k8s_deployments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_deployments (id, cluster_id, namespace_id, organization_id, name, deployment_uid, replicas_desired, replicas_current, replicas_ready, replicas_available, replicas_unavailable, containers, status, health_status, strategy, labels, annotations, created_at, updated_at, last_sync_at) FROM stdin;
\.


--
-- Data for Name: k8s_helm_releases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_helm_releases (id, cluster_id, namespace_id, name, chart_name, chart_version, status, revision, values_yaml, first_deployed_at, last_deployed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_namespaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_namespaces (id, cluster_id, organization_id, name, namespace_uid, status, cpu_limit, memory_limit, pod_limit, cpu_usage_cores, memory_usage_bytes, pod_count, team_name, cost_center, estimated_daily_cost, labels, annotations, created_at, updated_at, last_sync_at) FROM stdin;
\.


--
-- Data for Name: k8s_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_nodes (id, cluster_id, name, node_uid, node_type, instance_type, cpu_capacity, memory_capacity, pod_capacity, cpu_allocatable, memory_allocatable, cpu_usage_cores, memory_usage_bytes, pod_count, status, conditions, labels, taints, created_at, updated_at, last_sync_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_01; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_01 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_02; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_02 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_03; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_03 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_04; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_04 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_05; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_05 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_06; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_06 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_07; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_07 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_08; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_08 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_09; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_09 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_10; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_10 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_11; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_11 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_pods_2026_12; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_pods_2026_12 (id, cluster_id, namespace_id, deployment_id, name, pod_uid, node_name, phase, status, reason, containers, init_containers, cpu_request, memory_request, cpu_limit, memory_limit, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_01; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_01 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_02; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_02 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_03; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_03 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_04; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_04 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_05; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_05 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_06; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_06 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_07; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_07 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_08; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_08 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_09; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_09 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_10; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_10 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_11; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_11 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: k8s_resource_metrics_2026_12; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.k8s_resource_metrics_2026_12 (id, cluster_id, namespace_id, deployment_id, pod_id, node_id, resource_type, cpu_usage_cores, memory_usage_bytes, network_rx_bytes, network_tx_bytes, storage_usage_bytes, restarts, oom_kills, collected_at) FROM stdin;
\.


--
-- Data for Name: llm_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_models (id, provider_id, name, display_name, cost_per_1m_input_tokens, cost_per_1m_output_tokens, context_length, enabled, metadata, avg_latency_ms, created_at, updated_at, quality_score, power_level) FROM stdin;
7e9842b5-db22-4da0-bf8a-35377d741bec	2a8f08ca-ecfe-4d03-b63f-063fc5d2dd83	qwen-32b-awq	Qwen 2.5 32B (Local)	0.0000	0.0000	32768	t	{}	500	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.85	eco
40d7e687-032b-4700-92f3-d7c00e7b437e	2a8f08ca-ecfe-4d03-b63f-063fc5d2dd83	llama-3.1-8b-instruct	Llama 3.1 8B (Local)	0.0000	0.0000	131072	t	{}	300	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.80	eco
dff3ed08-8911-4250-8027-265b9f740647	2637c442-24a4-4d04-aa2a-63322b740f74	llama-3.1-70b-versatile	Llama 3.1 70B (Groq)	0.0000	0.0000	131072	t	{}	200	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.88	balanced
ea1499b1-7bcb-492d-a518-7bdcd588b515	2637c442-24a4-4d04-aa2a-63322b740f74	mixtral-8x7b-32768	Mixtral 8x7B (Groq)	0.0000	0.0000	32768	t	{}	150	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.82	eco
eeb6f6c4-2d2b-4ea7-a690-38b000520ef6	2637c442-24a4-4d04-aa2a-63322b740f74	gemma2-9b-it	Gemma 2 9B (Groq)	0.0000	0.0000	8192	t	{}	100	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.78	eco
93dd16e3-ce4d-4bd9-a941-702a367c1bcd	2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	openai/gpt-4o-mini	GPT-4o Mini (OpenRouter)	0.1500	0.6000	128000	t	{}	800	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.85	balanced
708c23bc-312b-4bcd-b174-dbbdb9863b30	2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	anthropic/claude-3.5-sonnet	Claude 3.5 Sonnet (OpenRouter)	3.0000	15.0000	200000	t	{}	1500	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.98	precision
8d0b9d11-12cf-4ad5-839b-07eb04ff900b	2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	google/gemini-pro-1.5	Gemini 1.5 Pro (OpenRouter)	1.2500	5.0000	2000000	t	{}	1200	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.92	precision
c429a7bb-b1c0-4eca-b258-d7abf57758e1	2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	meta-llama/llama-3.1-405b-instruct	Llama 3.1 405B (OpenRouter)	2.7000	2.7000	131072	t	{}	2000	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.95	precision
44680274-24bb-40cc-8829-d43f79965214	2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	mistralai/mixtral-8x22b-instruct	Mixtral 8x22B (OpenRouter)	0.6500	0.6500	65536	t	{}	1000	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.87	balanced
0c39c917-d4ee-42e6-abaf-adb6ed74f7cd	2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	qwen/qwen-2.5-72b-instruct	Qwen 2.5 72B (OpenRouter)	0.3500	0.3500	131072	t	{}	900	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.86	balanced
a29b41d7-e375-4134-b415-76d126e1a318	a42f1563-644f-4b4f-942f-d2a8843061d4	gpt-4o	GPT-4o	5.0000	15.0000	128000	t	{}	1800	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.95	precision
5ffd3e71-d5fb-428b-94c9-552489580df5	a42f1563-644f-4b4f-942f-d2a8843061d4	gpt-4o-mini	GPT-4o Mini	0.1500	0.6000	128000	t	{}	800	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.85	balanced
08b51e9e-86d2-4d92-b032-0f25d8043aef	a42f1563-644f-4b4f-942f-d2a8843061d4	gpt-4-turbo	GPT-4 Turbo	10.0000	30.0000	128000	t	{}	2200	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.93	precision
decff88a-baf1-47e2-9ade-844b68317feb	a42f1563-644f-4b4f-942f-d2a8843061d4	o1-preview	O1 Preview (Reasoning)	15.0000	60.0000	128000	t	{}	5000	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.97	precision
6ca034df-308f-490b-9c77-da0b530109fd	9198f8c6-8d95-4fb9-b19e-5ab463e63bfe	claude-3-5-sonnet-20241022	Claude 3.5 Sonnet	3.0000	15.0000	200000	t	{}	1800	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.98	precision
e5eec512-3856-4fb9-8cec-61c3c5a2dc59	9198f8c6-8d95-4fb9-b19e-5ab463e63bfe	claude-3-opus-20240229	Claude 3 Opus	15.0000	75.0000	200000	t	{}	3000	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.99	precision
d7eaebf3-ee76-4eed-ad21-1b3e9bb7b3d6	9198f8c6-8d95-4fb9-b19e-5ab463e63bfe	claude-3-haiku-20240307	Claude 3 Haiku	0.2500	1.2500	200000	t	{}	600	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.83	balanced
17a84908-ed17-42f5-a69a-4e7f1fd0f128	275a88fd-87e8-43df-92ee-ec0d338b0c71	meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo	Llama 3.1 405B Turbo	3.5000	3.5000	131072	t	{}	1600	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.94	precision
579161d8-1595-4824-af97-b4e8c2accc30	275a88fd-87e8-43df-92ee-ec0d338b0c71	meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo	Llama 3.1 70B Turbo	0.8800	0.8800	131072	t	{}	800	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.88	balanced
f005b0f3-eef7-4f7f-9fe8-edd136e0fa82	275a88fd-87e8-43df-92ee-ec0d338b0c71	mistralai/Mixtral-8x22B-Instruct-v0.1	Mixtral 8x22B	1.2000	1.2000	65536	t	{}	1200	2026-01-25 19:11:14.296784	2026-01-25 19:11:14.296784	0.87	balanced
\.


--
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_providers (id, name, type, api_key_encrypted, api_base_url, enabled, priority, config, health_status, last_health_check, created_at, updated_at, api_key_source, api_key_last_tested, api_key_test_status, api_key_updated_at) FROM stdin;
2a8f08ca-ecfe-4d03-b63f-063fc5d2dd83	Local vLLM	local	\N	http://unicorn-vllm:8000	t	100	{"timeout": 60000}	unknown	\N	2026-01-25 19:11:14.289879	2026-01-25 19:11:14.289879	not_set	\N	\N	\N
2637c442-24a4-4d04-aa2a-63322b740f74	Groq	groq	\N	https://api.groq.com	t	95	{"timeout": 30000}	unknown	\N	2026-01-25 19:11:14.289879	2026-01-25 19:11:14.289879	not_set	\N	\N	\N
a42f1563-644f-4b4f-942f-d2a8843061d4	Platform OpenAI	openai	\N	https://api.openai.com	t	80	{"timeout": 30000}	unknown	\N	2026-01-25 19:11:14.289879	2026-01-25 19:11:14.289879	not_set	\N	\N	\N
9198f8c6-8d95-4fb9-b19e-5ab463e63bfe	Platform Anthropic	anthropic	\N	https://api.anthropic.com	t	80	{"timeout": 30000}	unknown	\N	2026-01-25 19:11:14.289879	2026-01-25 19:11:14.289879	not_set	\N	\N	\N
275a88fd-87e8-43df-92ee-ec0d338b0c71	Together AI	together	\N	https://api.together.xyz	t	70	{"timeout": 30000}	unknown	\N	2026-01-25 19:11:14.289879	2026-01-25 19:11:14.289879	not_set	\N	\N	\N
2a2a5a7b-9ecd-4eef-b26b-450fa7b9534e	OpenRouter	openrouter	gAAAAABpeDLIyaiySaBttwccbPKLloqc_1z6MvY_ciUaunyv0DLfdg0EYxOOvnsnhVWbt9tQZbhjzBGaqaUQr-hMcBxO4VfhIktPqlM-ojmnylRUQvY-pN9lOgESFpx6quinq8-k0l7PQl8af5Kzk5Nf1a5CXaf17MP3yQyT8zRes6yK-DbGrF8=	https://openrouter.ai/api	t	90	{"timeout": 30000, "app_name": "Ops-Center", "site_url": "https://kubeworkz.io"}	unknown	\N	2026-01-25 19:11:14.289879	2026-01-25 19:11:14.289879	database	\N	\N	2026-01-31 20:29:11.353276
\.


--
-- Data for Name: llm_routing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_routing_rules (id, strategy, fallback_providers, model_aliases, config, created_at, updated_at) FROM stdin;
862238a4-1edc-44d9-b0e0-2021bf633aa6	balanced	{}	{}	{"cost_weight": 0.4, "max_retries": 3, "latency_weight": 0.4, "quality_weight": 0.2, "retry_delay_ms": 500}	2026-01-22 23:51:35.646658	2026-01-22 23:51:35.646658
7cfd8948-af26-43fd-beef-1a3778524466	balanced	{}	{}	{"timeout_ms": 30000, "cost_weight": 0.4, "max_retries": 3, "latency_weight": 0.4, "quality_weight": 0.2, "retry_delay_ms": 500}	2026-01-25 19:10:56.222074	2026-01-25 19:10:56.222074
\.


--
-- Data for Name: llm_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_usage_logs (id, user_id, provider_id, model_name, input_tokens, output_tokens, cost, latency_ms, power_level, created_at, status) FROM stdin;
\.


--
-- Data for Name: managed_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.managed_servers (id, name, description, hostname, api_url, api_token_hash, version, region, environment, status, health_status, last_seen_at, last_health_check_at, tags, metadata, organization_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migration_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_jobs (id, domain_name, source_registrar, target_registrar, status, auth_code, initiated_by, started_at, completed_at, error_message, steps, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: model_access_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_access_audit (id, list_id, model_id, action, actor_id, actor_email, old_value, new_value, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: model_pricing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_pricing (id, provider, model_name, model_tier, input_price_per_million, output_price_per_million, context_window, max_output_tokens, supports_streaming, supports_function_calling, avg_latency_ms, quality_score, is_active, deprecated_at, replacement_model, effective_date, notes, created_at, updated_at) FROM stdin;
be82e119-26ee-427c-890d-b427fd3043ba	openai	gpt-4-turbo	premium	10.000000	30.000000	128000	4096	t	t	\N	0.9500	t	\N	\N	2026-01-26	Latest GPT-4 Turbo with vision	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
c55098c3-fc97-4ea0-8943-835b53d68c54	openai	gpt-4	premium	30.000000	60.000000	8192	4096	t	t	\N	0.9400	t	\N	\N	2026-01-26	Original GPT-4	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
89f2eea9-9aea-489a-9452-35af4b9f40d1	openai	gpt-3.5-turbo	base	0.500000	1.500000	16385	4096	t	t	\N	0.7800	t	\N	\N	2026-01-26	Fast and cost-effective	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
4ce2ab03-b496-47e6-ac75-7b85c561e8f9	openai	gpt-3.5-turbo-16k	base	3.000000	4.000000	16385	4096	t	t	\N	0.7800	t	\N	\N	2026-01-26	Extended context	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
28b457bf-c48b-4571-8df9-38f6c55bc19d	anthropic	claude-3-opus	premium	15.000000	75.000000	200000	4096	t	t	\N	0.9600	t	\N	\N	2026-01-26	Most capable Claude model	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
7904af9d-9c7a-43d6-bc24-efe73e0f9ac5	anthropic	claude-3-sonnet	advanced	3.000000	15.000000	200000	4096	t	t	\N	0.8800	t	\N	\N	2026-01-26	Balanced performance	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
9ab77f55-3aa4-468a-8a76-a2c6c20a44c4	anthropic	claude-3-haiku	base	0.250000	1.250000	200000	4096	t	t	\N	0.7500	t	\N	\N	2026-01-26	Fastest Claude model	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
312cac7a-f0fc-4347-b78f-e71fd44150c2	google	gemini-pro	base	0.500000	1.500000	32768	2048	t	t	\N	0.8200	t	\N	\N	2026-01-26	Multimodal capabilities	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
eec830ee-71da-4cf1-bb69-79d08ef1e2da	google	gemini-ultra	premium	10.000000	30.000000	32768	2048	t	t	\N	0.9300	t	\N	\N	2026-01-26	Most capable Gemini	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
2650d528-25d3-44bc-bad7-abf9bc5a83b8	meta	llama-2-70b	base	0.700000	0.900000	4096	2048	t	f	\N	0.7200	t	\N	\N	2026-01-26	Open-source alternative	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
cd914e35-39bf-4960-a071-5a28265e5c9d	meta	llama-2-13b	base	0.200000	0.300000	4096	2048	t	f	\N	0.6500	t	\N	\N	2026-01-26	Smaller open-source model	2026-01-26 21:06:26.72025	2026-01-26 21:06:26.72025
\.


--
-- Data for Name: namecheap_domains; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.namecheap_domains (id, domain_name, domain_id, user_id, registration_date, expiration_date, auto_renew, is_locked, whois_guard, nameservers, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: org_billing_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.org_billing_history (id, org_id, subscription_id, event_type, amount, currency, description, created_at) FROM stdin;
1	org_OVnNIrLq6nOP62wASDlywQ	\N	subscription_upgraded	99.0000	USD	Upgraded from hybrid to hybrid	2026-02-02 20:40:34.598331
\.


--
-- Data for Name: organization_branding; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_branding (id, org_id, org_name, logo_url, logo_dark_url, favicon_url, background_image_url, primary_color, secondary_color, accent_color, text_color, background_color, font_family, heading_font, company_name, tagline, description, support_email, support_phone, website_url, twitter_url, linkedin_url, github_url, discord_url, custom_domain, custom_domain_verified, custom_domain_ssl_enabled, terms_of_service_url, privacy_policy_url, custom_terms_text, custom_privacy_text, email_from_name, email_from_address, email_logo_url, email_footer_text, custom_logo_enabled, custom_colors_enabled, custom_domain_enabled, custom_email_enabled, white_label_enabled, tier_code, created_at, updated_at, created_by, updated_by) FROM stdin;
1	test-org-002	Test Organization 2	\N	\N	\N	\N	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	professional	2026-01-25 21:10:37.517875+00	2026-01-25 21:10:37.517875+00	\N	\N
2	epic45-test-1769375477	Epic 4.5 Test Organization	\N	\N	\N	\N	#8B5CF6	#10B981	#F59E0B	\N	\N	\N	\N	Acme Corp	Building the Future	\N	support@acmecorp.com	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	t	t	f	f	f	professional	2026-01-25 21:11:17.876572+00	2026-01-25 21:11:18.048514+00	\N	\N
3	epic45-test-1769375486	Epic 4.5 Test Organization	\N	\N	\N	\N	#8B5CF6	#10B981	#F59E0B	\N	\N	\N	\N	Acme Corp	Building the Future	\N	support@acmecorp.com	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	t	t	f	f	f	professional	2026-01-25 21:11:26.348538+00	2026-01-25 21:11:26.532214+00	\N	\N
4	epic45-test-999	Test Org	\N	\N	\N	\N	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	professional	2026-01-25 21:11:35.479538+00	2026-01-25 21:11:35.479538+00	\N	\N
5	epic45-test-abc123	Test Organization	\N	\N	\N	\N	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	professional	2026-01-25 21:17:21.450883+00	2026-01-25 21:17:21.450883+00	\N	\N
6	epic45-test-1769375856	Epic 4.5 Test Organization	\N	\N	\N	\N	#8B5CF6	#10B981	#F59E0B	\N	\N	\N	\N	Acme Corp	Building the Future	\N	support@acmecorp.com	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	t	t	f	f	f	professional	2026-01-25 21:17:37.081994+00	2026-01-25 21:17:37.295506+00	\N	\N
\.


--
-- Data for Name: organization_credit_pools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_credit_pools (id, org_id, total_credits, allocated_credits, used_credits, monthly_refresh_amount, last_refresh_date, created_at, updated_at) FROM stdin;
1	org_OVnNIrLq6nOP62wASDlywQ	100.0000	0.0000	0.0000	0.0000	2026-02-02 20:21:17.094841	2026-02-02 20:21:17.094841	2026-02-02 20:21:17.094841
\.


--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_invitations (id, organization_id, email, role, invited_by, status, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_members (id, organization_id, user_id, role, is_active, joined_at, updated_at) FROM stdin;
f1d15949-2fd6-4e11-a761-b174a4c68114	org_b4efd667-5d9f-4bb5-8739-f01e39295ce4	4c64916f-1c30-4685-bc48-6ba2c9f56e9e	OWNER	t	2026-01-25 01:34:31	2026-01-27 17:41:32.851033
30950efd-36cf-43ec-bdbf-bb918c11d9ad	org_ff576b49-c7ba-4d29-96b8-b151fbb69f55	4c64916f-1c30-4685-bc48-6ba2c9f56e9e	OWNER	t	2026-01-25 01:51:20	2026-01-27 17:41:32.851033
mem_snuVyhV_2ZwsgEhfR_rATQ	org_9qRpBNzYKNe5u6V8Z_bYJA	dave@gridworkz.com	OWNER	t	2026-01-28 00:03:38.048463	2026-01-28 00:03:38.048464
mem_dAocpLfxbzwmsXPkE_d-rg	org_OVnNIrLq6nOP62wASDlywQ	saashqdev@startmail.com	OWNER	t	2026-01-28 00:12:44.027363	2026-01-28 00:12:44.027364
\.


--
-- Data for Name: organization_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_subscriptions (id, org_id, subscription_plan, status, monthly_price, start_date, end_date, created_at, updated_at) FROM stdin;
e566d775-8822-4162-9247-ee9a009d2033	org_OVnNIrLq6nOP62wASDlywQ	hybrid	active	99.00	2026-02-02 20:34:51.638961	2026-03-02 20:34:51.638961	2026-02-02 20:34:51.638961	2026-02-02 20:40:34.579859
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organizations (id, name, slug, description, website, logo_url, max_users, is_active, settings, metadata_json, created_at, updated_at, stripe_customer_id) FROM stdin;
org_b4efd667-5d9f-4bb5-8739-f01e39295ce4	Acme Corp	acme-corp	\N	\N	\N	\N	t	\N	{"plan_tier": "professional"}	2026-01-25 01:34:31	2026-01-27 17:26:58.959191	\N
org_9qRpBNzYKNe5u6V8Z_bYJA	Test Corp1	test	\N	test.company.com	\N	\N	t	\N	{"plan_tier": "trial"}	2026-01-28 00:03:38.047677	2026-01-28 00:03:38.047679	\N
org_OVnNIrLq6nOP62wASDlywQ	HextaUI retirement	hexta	\N	hexta.company.com	\N	\N	t	\N	{"plan_tier": "trial"}	2026-01-28 00:12:44.026122	2026-01-28 00:12:44.026125	\N
org_ff576b49-c7ba-4d29-96b8-b151fbb69f55	Delightful	delightful	\N	\N	\N	\N	t	\N	{"plan_tier": "starter"}	2026-01-25 01:51:20	2026-01-28 00:17:42.654774	\N
\.


--
-- Data for Name: payment_dunning; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_dunning (id, subscription_id, stripe_invoice_id, status, retry_count, max_retries, first_failure_at, last_retry_at, next_retry_at, grace_period_ends_at, resolved_at, amount_due, currency, failure_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, resource, action, description, created_at) FROM stdin;
1	users:create	users	create	Create new users	2026-01-27 00:24:52.178903
2	users:read	users	read	View user information	2026-01-27 00:24:52.178903
3	users:update	users	update	Update user details	2026-01-27 00:24:52.178903
4	users:delete	users	delete	Delete users	2026-01-27 00:24:52.178903
5	users:list	users	list	List all users	2026-01-27 00:24:52.178903
6	organizations:create	organizations	create	Create organizations	2026-01-27 00:24:52.18079
7	organizations:read	organizations	read	View organization details	2026-01-27 00:24:52.18079
8	organizations:update	organizations	update	Update organization settings	2026-01-27 00:24:52.18079
9	organizations:delete	organizations	delete	Delete organizations	2026-01-27 00:24:52.18079
10	organizations:list	organizations	list	List organizations	2026-01-27 00:24:52.18079
11	organizations:members	organizations	members	Manage organization members	2026-01-27 00:24:52.18079
12	billing:read	billing	read	View billing information	2026-01-27 00:24:52.181741
13	billing:update	billing	update	Update billing settings	2026-01-27 00:24:52.181741
14	billing:invoices	billing	invoices	Access invoices	2026-01-27 00:24:52.181741
15	billing:payments	billing	payments	Manage payment methods	2026-01-27 00:24:52.181741
16	servers:create	servers	create	Register new servers	2026-01-27 00:24:52.182602
17	servers:read	servers	read	View server details	2026-01-27 00:24:52.182602
18	servers:update	servers	update	Update server configuration	2026-01-27 00:24:52.182602
19	servers:delete	servers	delete	Delete servers	2026-01-27 00:24:52.182602
20	servers:restart	servers	restart	Restart servers	2026-01-27 00:24:52.182602
21	servers:logs	servers	logs	View server logs	2026-01-27 00:24:52.182602
22	api_keys:create	api_keys	create	Create API keys	2026-01-27 00:24:52.183494
23	api_keys:read	api_keys	read	View API keys	2026-01-27 00:24:52.183494
24	api_keys:revoke	api_keys	revoke	Revoke API keys	2026-01-27 00:24:52.183494
25	api_keys:delete	api_keys	delete	Delete API keys	2026-01-27 00:24:52.183494
26	analytics:read	analytics	read	View analytics data	2026-01-27 00:24:52.184323
27	analytics:export	analytics	export	Export analytics reports	2026-01-27 00:24:52.184323
28	settings:read	settings	read	View system settings	2026-01-27 00:24:52.185093
29	settings:update	settings	update	Update system settings	2026-01-27 00:24:52.185093
30	webhooks:create	webhooks	create	Create webhooks	2026-01-27 00:24:52.185861
31	webhooks:read	webhooks	read	View webhooks	2026-01-27 00:24:52.185861
32	webhooks:update	webhooks	update	Update webhooks	2026-01-27 00:24:52.185861
33	webhooks:delete	webhooks	delete	Delete webhooks	2026-01-27 00:24:52.185861
\.


--
-- Data for Name: platform_pricing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_pricing_rules (id, tier_code, model_pattern, price_per_1k_tokens, price_per_image, price_per_request, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_settings (id, category, key, value, is_encrypted, created_at, updated_at, is_secret) FROM stdin;
1	infrastructure	CLOUDFLARE_API_TOKEN	rOV7t-0OKzlnZrhQkn98JYEEp3rBf1Pt_hpvFjnT	f	2026-02-03 20:32:57.434285+00	2026-02-03 20:48:37.678012+00	t
\.


--
-- Data for Name: policy_acknowledgments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_acknowledgments (id, acknowledgment_id, user_email, policy_name, policy_version, policy_content_hash, acknowledged_at, ip_address, user_agent, acknowledgment_method, expires_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: pricing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pricing_rules (id, rule_type, provider, model_pattern, pricing_formula, base_cost, markup_percentage, priority, is_active, tier_restrictions, metadata, created_at, updated_at, tier_code, markup_type, markup_value, min_charge, free_credits_monthly, applies_to_tiers, rule_name, description, provider_overrides, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_limits (id, api_key_id, window_type, window_start, request_count, expires_at) FROM stdin;
\.


--
-- Data for Name: rbac_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rbac_audit_log (id, event_type, actor_email, target_user_email, role_id, permission_id, resource_type, resource_id, changes, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: resource_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_policies (id, resource_type, resource_id, policy_document, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_inheritance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_inheritance (id, parent_role_id, child_role_id, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_id, granted_at, granted_by) FROM stdin;
1	1	1	2026-01-27 00:24:52.189088	\N
2	1	2	2026-01-27 00:24:52.189088	\N
3	1	3	2026-01-27 00:24:52.189088	\N
4	1	4	2026-01-27 00:24:52.189088	\N
5	1	5	2026-01-27 00:24:52.189088	\N
6	1	6	2026-01-27 00:24:52.189088	\N
7	1	7	2026-01-27 00:24:52.189088	\N
8	1	8	2026-01-27 00:24:52.189088	\N
9	1	9	2026-01-27 00:24:52.189088	\N
10	1	10	2026-01-27 00:24:52.189088	\N
11	1	11	2026-01-27 00:24:52.189088	\N
12	1	12	2026-01-27 00:24:52.189088	\N
13	1	13	2026-01-27 00:24:52.189088	\N
14	1	14	2026-01-27 00:24:52.189088	\N
15	1	15	2026-01-27 00:24:52.189088	\N
16	1	16	2026-01-27 00:24:52.189088	\N
17	1	17	2026-01-27 00:24:52.189088	\N
18	1	18	2026-01-27 00:24:52.189088	\N
19	1	19	2026-01-27 00:24:52.189088	\N
20	1	20	2026-01-27 00:24:52.189088	\N
21	1	21	2026-01-27 00:24:52.189088	\N
22	1	22	2026-01-27 00:24:52.189088	\N
23	1	23	2026-01-27 00:24:52.189088	\N
24	1	24	2026-01-27 00:24:52.189088	\N
25	1	25	2026-01-27 00:24:52.189088	\N
26	1	26	2026-01-27 00:24:52.189088	\N
27	1	27	2026-01-27 00:24:52.189088	\N
28	1	28	2026-01-27 00:24:52.189088	\N
29	1	29	2026-01-27 00:24:52.189088	\N
30	1	30	2026-01-27 00:24:52.189088	\N
31	1	31	2026-01-27 00:24:52.189088	\N
32	1	32	2026-01-27 00:24:52.189088	\N
33	1	33	2026-01-27 00:24:52.189088	\N
34	2	1	2026-01-27 00:24:52.195654	\N
35	2	2	2026-01-27 00:24:52.195654	\N
36	2	3	2026-01-27 00:24:52.195654	\N
37	2	4	2026-01-27 00:24:52.195654	\N
38	2	5	2026-01-27 00:24:52.195654	\N
39	2	6	2026-01-27 00:24:52.195654	\N
40	2	7	2026-01-27 00:24:52.195654	\N
41	2	8	2026-01-27 00:24:52.195654	\N
42	2	9	2026-01-27 00:24:52.195654	\N
43	2	10	2026-01-27 00:24:52.195654	\N
44	2	11	2026-01-27 00:24:52.195654	\N
45	2	12	2026-01-27 00:24:52.195654	\N
46	2	13	2026-01-27 00:24:52.195654	\N
47	2	14	2026-01-27 00:24:52.195654	\N
48	2	15	2026-01-27 00:24:52.195654	\N
49	2	22	2026-01-27 00:24:52.195654	\N
50	2	23	2026-01-27 00:24:52.195654	\N
51	2	24	2026-01-27 00:24:52.195654	\N
52	2	25	2026-01-27 00:24:52.195654	\N
53	2	26	2026-01-27 00:24:52.195654	\N
54	2	27	2026-01-27 00:24:52.195654	\N
55	2	30	2026-01-27 00:24:52.195654	\N
56	2	31	2026-01-27 00:24:52.195654	\N
57	2	32	2026-01-27 00:24:52.195654	\N
58	2	33	2026-01-27 00:24:52.195654	\N
59	3	2	2026-01-27 00:24:52.199755	\N
60	3	3	2026-01-27 00:24:52.199755	\N
61	3	5	2026-01-27 00:24:52.199755	\N
62	3	7	2026-01-27 00:24:52.199755	\N
63	3	11	2026-01-27 00:24:52.199755	\N
64	3	12	2026-01-27 00:24:52.199755	\N
65	3	26	2026-01-27 00:24:52.199755	\N
66	6	7	2026-01-27 00:24:52.202353	\N
67	6	16	2026-01-27 00:24:52.202353	\N
68	6	17	2026-01-27 00:24:52.202353	\N
69	6	18	2026-01-27 00:24:52.202353	\N
70	6	19	2026-01-27 00:24:52.202353	\N
71	6	20	2026-01-27 00:24:52.202353	\N
72	6	21	2026-01-27 00:24:52.202353	\N
73	6	22	2026-01-27 00:24:52.202353	\N
74	6	23	2026-01-27 00:24:52.202353	\N
75	6	24	2026-01-27 00:24:52.202353	\N
76	6	25	2026-01-27 00:24:52.202353	\N
77	6	26	2026-01-27 00:24:52.202353	\N
78	6	30	2026-01-27 00:24:52.202353	\N
79	6	31	2026-01-27 00:24:52.202353	\N
80	6	32	2026-01-27 00:24:52.202353	\N
81	6	33	2026-01-27 00:24:52.202353	\N
82	7	2	2026-01-27 00:24:52.205473	\N
83	7	5	2026-01-27 00:24:52.205473	\N
84	7	7	2026-01-27 00:24:52.205473	\N
85	7	10	2026-01-27 00:24:52.205473	\N
86	7	12	2026-01-27 00:24:52.205473	\N
87	7	17	2026-01-27 00:24:52.205473	\N
88	7	23	2026-01-27 00:24:52.205473	\N
89	7	26	2026-01-27 00:24:52.205473	\N
90	7	28	2026-01-27 00:24:52.205473	\N
91	7	31	2026-01-27 00:24:52.205473	\N
\.


--
-- Data for Name: saml_assertions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_assertions (assertion_id, provider_id, session_id, assertion_xml, assertion_hash, is_valid, validation_errors, signature_verified, certificate_thumbprint, issue_instant, not_before, not_on_or_after, name_id, name_id_format, attributes, in_response_to, relay_state, ip_address, received_at) FROM stdin;
\.


--
-- Data for Name: saml_attribute_mappings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_attribute_mappings (mapping_id, provider_id, saml_attribute, user_field, is_required, default_value, transform_type, transform_config, validation_regex, created_at) FROM stdin;
35d9d577-707b-4ae8-a73f-8262f4d26e97	5e58ea09-30cc-49a6-aba0-6b4ce56b6775	email	email	t	\N	\N	\N	\N	2026-01-27 01:39:58.040132
72bbe0a1-f5be-4cfd-9c32-8325eb95331a	5e58ea09-30cc-49a6-aba0-6b4ce56b6775	firstName	first_name	f	\N	\N	\N	\N	2026-01-27 01:39:58.041651
55db2591-aa36-4e8a-84e6-2121c23275df	5e58ea09-30cc-49a6-aba0-6b4ce56b6775	lastName	last_name	f	\N	\N	\N	\N	2026-01-27 01:39:58.042525
8fdb11fe-433b-4b48-b641-3cb5b9cf85f0	5e58ea09-30cc-49a6-aba0-6b4ce56b6775	role	role	f	\N	\N	\N	\N	2026-01-27 01:39:58.043309
a3341d26-def9-46fe-a9a9-336e6e1a65d2	a9a36444-16bc-4678-8202-b210c15cc3c1	http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress	email	t	\N	\N	\N	\N	2026-01-27 01:39:58.044779
c86dbe53-4517-41bd-bf38-66f60ec25537	a9a36444-16bc-4678-8202-b210c15cc3c1	http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname	first_name	f	\N	\N	\N	\N	2026-01-27 01:39:58.045721
029de150-7944-44e3-ac62-bae54729fb8e	a9a36444-16bc-4678-8202-b210c15cc3c1	http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname	last_name	f	\N	\N	\N	\N	2026-01-27 01:39:58.046527
\.


--
-- Data for Name: saml_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_audit_log (log_id, provider_id, session_id, event_type, event_status, user_id, email, ip_address, user_agent, event_data, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_providers (provider_id, organization_id, name, entity_id, display_name, description, idp_entity_id, idp_sso_url, idp_slo_url, idp_certificate, sp_entity_id, sp_acs_url, sp_slo_url, sp_private_key, sp_certificate, name_id_format, authn_context, want_assertions_signed, want_assertions_encrypted, sign_requests, binding_type, enable_jit_provisioning, default_role, auto_create_organizations, is_active, is_default, metadata, last_metadata_refresh, created_at, created_by, updated_at, updated_by) FROM stdin;
5e58ea09-30cc-49a6-aba0-6b4ce56b6775	\N	okta_template	https://your-ops-center.com/saml/metadata/okta	Okta SSO (Template)	Template configuration for Okta SAML integration. Configure with your Okta tenant details.	http://www.okta.com/exk_TEMPLATE_ID	https://your-okta-tenant.okta.com/app/your-app/exk_TEMPLATE_ID/sso/saml	\N	-----BEGIN CERTIFICATE-----\nMIIDpDCCAoygAwIBAgIGAXXXXXXXXMA0GCSqGSIb3DQEBCwUAMIGSMQswCQYDVQQG\n-- REPLACE WITH YOUR OKTA CERTIFICATE --\n-----END CERTIFICATE-----	https://your-ops-center.com/saml/sp	https://your-ops-center.com/api/v1/saml/acs	\N	\N	\N	urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress	urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport	t	f	f	HTTP-POST	t	user	f	f	f	\N	\N	2026-01-27 01:39:58.038626	\N	2026-01-27 01:39:58.038626	\N
a9a36444-16bc-4678-8202-b210c15cc3c1	\N	azure_ad_template	https://your-ops-center.com/saml/metadata/azure	Azure AD / Entra ID (Template)	Template configuration for Microsoft Azure AD / Entra ID SAML integration.	https://sts.windows.net/TENANT_ID/	https://login.microsoftonline.com/TENANT_ID/saml2	\N	-----BEGIN CERTIFICATE-----\nMIIDPjCCAiqgAwIBAgIQVWmXY/+9RqFA/OG9kFulHDAJBgUrDgMCHQUAMC0xKzAp\n-- REPLACE WITH YOUR AZURE AD CERTIFICATE --\n-----END CERTIFICATE-----	https://your-ops-center.com/saml/sp	https://your-ops-center.com/api/v1/saml/acs	\N	\N	\N	urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress	urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport	t	f	f	HTTP-POST	t	user	f	f	f	\N	\N	2026-01-27 01:39:58.044073	\N	2026-01-27 01:39:58.044073	\N
\.


--
-- Data for Name: saml_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_sessions (session_id, provider_id, saml_session_id, name_id, name_id_format, user_id, email, session_start, session_expiry, not_on_or_after, authn_context, authn_instant, attributes, is_active, logout_requested, logout_at, relay_state, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: savings_opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.savings_opportunities (id, organization_id, opportunity_type, title, description, affected_models, affected_users, affected_period, current_monthly_cost, potential_savings, savings_percentage, detection_confidence, detection_method, supporting_data, recommended_actions, estimated_implementation_hours, status, assigned_to, resolved_at, resolution_notes, verified, actual_savings, verified_at, verified_by, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_incidents (id, incident_id, title, description, severity, incident_type, status, detected_at, reported_at, reported_by, assigned_to, resolved_at, resolution_notes, affected_systems, affected_users, affected_data_types, estimated_impact, root_cause, remediation_steps, lessons_learned, evidence_ids, related_controls, notification_required, notification_sent, notification_sent_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: server_group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_group_members (server_id, group_id, added_at) FROM stdin;
\.


--
-- Data for Name: server_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_groups (id, name, description, color, tags, regions, environments, organization_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_01; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_01 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_02; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_02 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_03; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_03 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_04; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_04 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_05; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_05 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_06; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_06 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_07; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_07 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_08; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_08 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_09; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_09 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_10; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_10 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_11; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_11 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_health_checks_2026_12; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_health_checks_2026_12 (id, server_id, "timestamp", status, response_time_ms, database_healthy, redis_healthy, services_healthy, error_message, error_details, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_01; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_01 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_02; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_02 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_03; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_03 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_04; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_04 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_05; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_05 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_06; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_06 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_07; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_07 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_08; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_08 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_09; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_09 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_10; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_10 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_11; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_11 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: server_metrics_aggregated_2026_12; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_metrics_aggregated_2026_12 (id, server_id, "timestamp", period, cpu_percent, memory_percent, disk_percent, network_rx_bytes, network_tx_bytes, active_services, failed_services, total_services, llm_requests, llm_cost_usd, active_users, total_users, created_at) FROM stdin;
\.


--
-- Data for Name: smart_alert_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_alert_models (id, device_id, metric_name, model_type, model_data, baseline_stats, training_data_start, training_data_end, accuracy_score, false_positive_rate, last_trained_at, version, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_tiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_tiers (id, tier_code, tier_name, description, price_monthly, price_yearly, is_active, is_invite_only, sort_order, api_calls_limit, team_seats, byok_enabled, priority_support, lago_plan_code, stripe_price_monthly, stripe_price_yearly, created_at, updated_at) FROM stdin;
1	trial	Trial	Free trial tier	0.00	0.00	t	f	1	1000	1	f	f	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
2	starter	Starter	Entry tier	29.00	0.00	t	f	2	10000	3	f	f	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
3	professional	Professional	Pro tier	99.00	0.00	t	f	3	100000	10	t	t	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
4	enterprise	Enterprise	Enterprise tier	299.00	0.00	t	f	4	-1	50	t	t	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
5	vip_founder	VIP Founder	Legacy founder tier	0.00	0.00	t	f	5	-1	25	t	t	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
6	byok	BYOK	Bring Your Own Key	0.00	0.00	t	f	6	-1	25	t	t	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
7	managed	Managed	Managed tier	0.00	0.00	t	f	7	-1	25	t	t	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
8	founder-friend	Founder Friend	Friend of founder tier	0.00	0.00	t	f	8	-1	25	t	t	\N	\N	\N	2026-01-25 00:55:18.381234+00	2026-01-25 00:55:18.381234+00
\.


--
-- Data for Name: terraform_drift_detections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terraform_drift_detections (drift_id, workspace_id, resource_id, detected_at, drift_type, expected_state, actual_state, differences, resolved, resolved_at, resolved_by) FROM stdin;
\.


--
-- Data for Name: terraform_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terraform_executions (execution_id, workspace_id, execution_type, status, triggered_by, triggered_at, completed_at, duration_seconds, plan_output, resources_to_add, resources_to_change, resources_to_destroy, error_message, exit_code, log_file, auto_applied) FROM stdin;
\.


--
-- Data for Name: terraform_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terraform_resources (resource_id, workspace_id, state_id, resource_type, resource_name, provider, address, attributes, dependencies, status, created_at, updated_at, destroyed_at) FROM stdin;
\.


--
-- Data for Name: terraform_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terraform_states (state_id, workspace_id, version, serial, lineage, state_data, resources_count, outputs, created_by, created_at, terraform_version, is_current) FROM stdin;
\.


--
-- Data for Name: terraform_variables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terraform_variables (variable_id, workspace_id, key, value, description, is_sensitive, is_hcl, category, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: terraform_workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terraform_workspaces (workspace_id, name, description, cloud_provider, environment, created_by, created_at, updated_at, last_apply_at, state_version, locked, locked_by, locked_at, auto_apply, terraform_version) FROM stdin;
\.


--
-- Data for Name: tier_features; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tier_features (id, tier_id, feature_key, feature_value, enabled, created_at, updated_at) FROM stdin;
44	1	chat_access	true	t	2026-01-25 20:29:43.152521+00	2026-01-25 20:29:43.152521+00
45	1	search_enabled	false	f	2026-01-25 20:29:43.155593+00	2026-01-25 20:29:43.155593+00
46	1	llama_enabled	true	t	2026-01-25 20:29:43.156664+00	2026-01-25 20:29:43.156664+00
47	1	api_access	false	f	2026-01-25 20:29:43.157525+00	2026-01-25 20:29:43.157525+00
48	1	max_file_upload_mb	5	t	2026-01-25 20:29:43.158413+00	2026-01-25 20:29:43.158413+00
49	1	rate_limit_per_minute	10	t	2026-01-25 20:29:43.159284+00	2026-01-25 20:29:43.159284+00
50	1	support_level	community	t	2026-01-25 20:29:43.160179+00	2026-01-25 20:29:43.160179+00
51	2	chat_access	true	t	2026-01-25 20:29:43.161173+00	2026-01-25 20:29:43.161173+00
52	2	search_enabled	true	t	2026-01-25 20:29:43.161997+00	2026-01-25 20:29:43.161997+00
53	2	tts_enabled	true	t	2026-01-25 20:29:43.162874+00	2026-01-25 20:29:43.162874+00
54	2	litellm_access	true	t	2026-01-25 20:29:43.163649+00	2026-01-25 20:29:43.163649+00
55	2	gpt4_enabled	false	f	2026-01-25 20:29:43.164374+00	2026-01-25 20:29:43.164374+00
56	2	claude_enabled	true	t	2026-01-25 20:29:43.165433+00	2026-01-25 20:29:43.165433+00
57	2	llama_enabled	true	t	2026-01-25 20:29:43.167003+00	2026-01-25 20:29:43.167003+00
58	2	api_access	true	t	2026-01-25 20:29:43.16828+00	2026-01-25 20:29:43.16828+00
59	2	webhooks_enabled	false	f	2026-01-25 20:29:43.169382+00	2026-01-25 20:29:43.169382+00
60	2	max_file_upload_mb	25	t	2026-01-25 20:29:43.170434+00	2026-01-25 20:29:43.170434+00
61	2	rate_limit_per_minute	60	t	2026-01-25 20:29:43.171455+00	2026-01-25 20:29:43.171455+00
62	2	support_level	standard	t	2026-01-25 20:29:43.172558+00	2026-01-25 20:29:43.172558+00
63	3	chat_access	true	t	2026-01-25 20:29:43.17391+00	2026-01-25 20:29:43.17391+00
64	3	search_enabled	true	t	2026-01-25 20:29:43.174986+00	2026-01-25 20:29:43.174986+00
65	3	tts_enabled	true	t	2026-01-25 20:29:43.176064+00	2026-01-25 20:29:43.176064+00
66	3	stt_enabled	true	t	2026-01-25 20:29:43.177119+00	2026-01-25 20:29:43.177119+00
67	3	brigade_access	true	t	2026-01-25 20:29:43.178181+00	2026-01-25 20:29:43.178181+00
68	3	litellm_access	true	t	2026-01-25 20:29:43.179356+00	2026-01-25 20:29:43.179356+00
69	3	vllm_access	true	t	2026-01-25 20:29:43.180526+00	2026-01-25 20:29:43.180526+00
70	3	embeddings_access	true	t	2026-01-25 20:29:43.181742+00	2026-01-25 20:29:43.181742+00
71	3	gpt4_enabled	true	t	2026-01-25 20:29:43.183152+00	2026-01-25 20:29:43.183152+00
72	3	claude_enabled	true	t	2026-01-25 20:29:43.18436+00	2026-01-25 20:29:43.18436+00
73	3	gemini_enabled	true	t	2026-01-25 20:29:43.185534+00	2026-01-25 20:29:43.185534+00
74	3	llama_enabled	true	t	2026-01-25 20:29:43.186763+00	2026-01-25 20:29:43.186763+00
75	3	mistral_enabled	true	t	2026-01-25 20:29:43.187879+00	2026-01-25 20:29:43.187879+00
76	3	api_access	true	t	2026-01-25 20:29:43.189111+00	2026-01-25 20:29:43.189111+00
77	3	webhooks_enabled	true	t	2026-01-25 20:29:43.190321+00	2026-01-25 20:29:43.190321+00
78	3	advanced_analytics	true	t	2026-01-25 20:29:43.191491+00	2026-01-25 20:29:43.191491+00
79	3	max_file_upload_mb	100	t	2026-01-25 20:29:43.192809+00	2026-01-25 20:29:43.192809+00
80	3	max_concurrent_requests	10	t	2026-01-25 20:29:43.194215+00	2026-01-25 20:29:43.194215+00
81	3	rate_limit_per_minute	300	t	2026-01-25 20:29:43.195267+00	2026-01-25 20:29:43.195267+00
82	3	support_level	priority	t	2026-01-25 20:29:43.196276+00	2026-01-25 20:29:43.196276+00
83	4	chat_access	true	t	2026-01-25 20:29:43.197309+00	2026-01-25 20:29:43.197309+00
84	4	search_enabled	true	t	2026-01-25 20:29:43.198356+00	2026-01-25 20:29:43.198356+00
85	4	tts_enabled	true	t	2026-01-25 20:29:43.199425+00	2026-01-25 20:29:43.199425+00
86	4	stt_enabled	true	t	2026-01-25 20:29:43.20042+00	2026-01-25 20:29:43.20042+00
87	4	brigade_access	true	t	2026-01-25 20:29:43.20127+00	2026-01-25 20:29:43.20127+00
88	4	litellm_access	true	t	2026-01-25 20:29:43.202113+00	2026-01-25 20:29:43.202113+00
89	4	vllm_access	true	t	2026-01-25 20:29:43.202938+00	2026-01-25 20:29:43.202938+00
90	4	embeddings_access	true	t	2026-01-25 20:29:43.203648+00	2026-01-25 20:29:43.203648+00
91	4	forgejo_access	true	t	2026-01-25 20:29:43.204435+00	2026-01-25 20:29:43.204435+00
92	4	magicdeck_access	true	t	2026-01-25 20:29:43.205225+00	2026-01-25 20:29:43.205225+00
93	4	gpt4_enabled	true	t	2026-01-25 20:29:43.206237+00	2026-01-25 20:29:43.206237+00
94	4	claude_enabled	true	t	2026-01-25 20:29:43.206967+00	2026-01-25 20:29:43.206967+00
95	4	gemini_enabled	true	t	2026-01-25 20:29:43.20768+00	2026-01-25 20:29:43.20768+00
96	4	llama_enabled	true	t	2026-01-25 20:29:43.208488+00	2026-01-25 20:29:43.208488+00
97	4	mistral_enabled	true	t	2026-01-25 20:29:43.209342+00	2026-01-25 20:29:43.209342+00
98	4	api_access	true	t	2026-01-25 20:29:43.20999+00	2026-01-25 20:29:43.20999+00
99	4	webhooks_enabled	true	t	2026-01-25 20:29:43.210573+00	2026-01-25 20:29:43.210573+00
100	4	custom_branding	true	t	2026-01-25 20:29:43.211434+00	2026-01-25 20:29:43.211434+00
101	4	sso_enabled	true	t	2026-01-25 20:29:43.212175+00	2026-01-25 20:29:43.212175+00
102	4	audit_logs	true	t	2026-01-25 20:29:43.212954+00	2026-01-25 20:29:43.212954+00
103	4	advanced_analytics	true	t	2026-01-25 20:29:43.213763+00	2026-01-25 20:29:43.213763+00
104	4	team_management	true	t	2026-01-25 20:29:43.214701+00	2026-01-25 20:29:43.214701+00
105	4	max_file_upload_mb	500	t	2026-01-25 20:29:43.215515+00	2026-01-25 20:29:43.215515+00
106	4	max_concurrent_requests	50	t	2026-01-25 20:29:43.216284+00	2026-01-25 20:29:43.216284+00
107	4	rate_limit_per_minute	1000	t	2026-01-25 20:29:43.217056+00	2026-01-25 20:29:43.217056+00
108	4	support_level	dedicated	t	2026-01-25 20:29:43.217871+00	2026-01-25 20:29:43.217871+00
109	4	sla_guarantee	true	t	2026-01-25 20:29:43.218695+00	2026-01-25 20:29:43.218695+00
110	4	dedicated_support	true	t	2026-01-25 20:29:43.219437+00	2026-01-25 20:29:43.219437+00
111	5	chat_access	true	t	2026-01-25 20:29:43.22015+00	2026-01-25 20:29:43.22015+00
112	5	search_enabled	true	t	2026-01-25 20:29:43.220793+00	2026-01-25 20:29:43.220793+00
113	5	tts_enabled	true	t	2026-01-25 20:29:43.221529+00	2026-01-25 20:29:43.221529+00
114	5	stt_enabled	true	t	2026-01-25 20:29:43.222252+00	2026-01-25 20:29:43.222252+00
115	5	brigade_access	true	t	2026-01-25 20:29:43.222901+00	2026-01-25 20:29:43.222901+00
116	5	litellm_access	true	t	2026-01-25 20:29:43.223555+00	2026-01-25 20:29:43.223555+00
117	5	vllm_access	true	t	2026-01-25 20:29:43.224218+00	2026-01-25 20:29:43.224218+00
118	5	embeddings_access	true	t	2026-01-25 20:29:43.224933+00	2026-01-25 20:29:43.224933+00
119	5	forgejo_access	true	t	2026-01-25 20:29:43.22555+00	2026-01-25 20:29:43.22555+00
120	5	magicdeck_access	true	t	2026-01-25 20:29:43.226161+00	2026-01-25 20:29:43.226161+00
121	5	gpt4_enabled	true	t	2026-01-25 20:29:43.226769+00	2026-01-25 20:29:43.226769+00
122	5	claude_enabled	true	t	2026-01-25 20:29:43.227395+00	2026-01-25 20:29:43.227395+00
123	5	gemini_enabled	true	t	2026-01-25 20:29:43.228088+00	2026-01-25 20:29:43.228088+00
124	5	llama_enabled	true	t	2026-01-25 20:29:43.229037+00	2026-01-25 20:29:43.229037+00
125	5	mistral_enabled	true	t	2026-01-25 20:29:43.22998+00	2026-01-25 20:29:43.22998+00
126	5	api_access	true	t	2026-01-25 20:29:43.230775+00	2026-01-25 20:29:43.230775+00
127	5	webhooks_enabled	true	t	2026-01-25 20:29:43.231449+00	2026-01-25 20:29:43.231449+00
128	5	custom_branding	true	t	2026-01-25 20:29:43.232217+00	2026-01-25 20:29:43.232217+00
129	5	sso_enabled	true	t	2026-01-25 20:29:43.232985+00	2026-01-25 20:29:43.232985+00
130	5	audit_logs	true	t	2026-01-25 20:29:43.233715+00	2026-01-25 20:29:43.233715+00
131	5	advanced_analytics	true	t	2026-01-25 20:29:43.234518+00	2026-01-25 20:29:43.234518+00
132	5	team_management	true	t	2026-01-25 20:29:43.235247+00	2026-01-25 20:29:43.235247+00
133	5	support_level	dedicated	t	2026-01-25 20:29:43.235999+00	2026-01-25 20:29:43.235999+00
134	5	sla_guarantee	true	t	2026-01-25 20:29:43.236691+00	2026-01-25 20:29:43.236691+00
135	5	dedicated_support	true	t	2026-01-25 20:29:43.237395+00	2026-01-25 20:29:43.237395+00
\.


--
-- Data for Name: usage_aggregates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_aggregates (id, subscription_id, email, api_key_id, period_type, period_start, period_end, total_requests, successful_requests, failed_requests, total_tokens, total_cost_usd, event_type_breakdown, model_breakdown, avg_response_time_ms, p95_response_time_ms, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: usage_events_2026_01; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_events_2026_01 (id, api_key_id, subscription_id, email, event_type, endpoint, method, tokens_used, cost_usd, status_code, response_time_ms, success, error_message, model, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: usage_events_2026_02; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_events_2026_02 (id, api_key_id, subscription_id, email, event_type, endpoint, method, tokens_used, cost_usd, status_code, response_time_ms, success, error_message, model, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_api_keys (id, user_id, key_name, key_hash, key_prefix, permissions, created_at, last_used, expires_at, is_active, metadata) FROM stdin;
\.


--
-- Data for Name: user_byok_credits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_byok_credits (id, user_id, tier_code, monthly_allowance, credits_used, credits_remaining, reset_date, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_credit_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_credit_allocations (id, user_id, org_id, allocated_credits, used_credits, remaining_credits, is_active, allocated_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_llm_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_llm_settings (user_id, power_level, byok_providers, credit_balance, preferences, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_model_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_model_preferences (id, user_id, model_id, is_favorite, is_hidden, custom_label, notes, last_used_at, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_provider_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_provider_keys (id, user_id, provider, api_key_encrypted, metadata, enabled, last_used, created_at, updated_at) FROM stdin;
b5247bc3-8b51-4ae1-ab37-0d2ce4f5fe49	dave@gridworkz.com	openrouter	gAAAAABpeDLIyaiySaBttwccbPKLloqc_1z6MvY_ciUaunyv0DLfdg0EYxOOvnsnhVWbt9tQZbhjzBGaqaUQr-hMcBxO4VfhIktPqlM-ojmnylRUQvY-pN9lOgESFpx6quinq8-k0l7PQl8af5Kzk5Nf1a5CXaf17MP3yQyT8zRes6yK-DbGrF8=	{"name": "Delightful", "added_date": "2026-01-27T03:36:40.543371", "last_tested": "2026-01-28T00:22:28.520793", "test_status": "valid"}	t	\N	2026-01-27 03:36:40.543649	2026-01-28 00:22:28.521137
3dea2d2d-9141-4571-a8e8-f4f46788a94e	81ea800e-7370-4885-a450-0c7839cf9358	openrouter	gAAAAABpe63duYEUVSnI89rTR1aJxzSO1lI7qpOaKqgAdL8KDxzBeiWafM9lqH0C-4zfzbES66kKDaNTQbKUIOl_sN2CbgQ01kHXVvo5vFxo0VRxf4VLEUCIciUC1q-3kqIq_vBdqwRk9LWvR0vYDVQyMp5W1zMLT5-4OwgaK-RRNPmmZ82agFA=	{"name": "Kubeworkz", "added_date": "2026-01-29T18:58:37.076113"}	t	\N	2026-01-29 18:58:37.076449	2026-01-29 18:58:37.076449
36624204-9162-48b6-a003-390678a013df	68a6a9cc-8d91-45bf-80f0-8d125b297876	openrouter	gAAAAABpfm7hobQ6AWrN-Ht_UelAC1eZnIlyINetquOv9bHkitHhydCqT70a7Hkv7ufyKJccOKLnxEXDeHX-P6t71he8j5KSTrMksL6X37LEkBV3DarhCy9-zQsZqre3fAJIz7uU91W2CkGb0Kbas-Ynjidu1iK3wDzIt_dqf0NjKO3hIG2ANcI=	{"name": "OpenRouter Key", "added_date": "2026-01-31T21:06:41.521141", "last_tested": "2026-01-31T21:06:47.793339", "test_status": "valid"}	t	\N	2026-01-31 21:06:41.521393	2026-01-31 21:06:47.793488
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_email, role_id, organization_id, assigned_at, assigned_by, expires_at) FROM stdin;
\.


--
-- Data for Name: user_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_subscriptions (id, email, tier_id, stripe_subscription_id, stripe_customer_id, status, billing_cycle, current_period_start, current_period_end, cancel_at, canceled_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, organization_id, url, events, secret, description, enabled, created_by, created_at, updated_at, last_triggered_at, success_count, failure_count) FROM stdin;
\.


--
-- Data for Name: workspace_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_credentials (workspace_id, credential_id, created_at) FROM stdin;
\.


--
-- Name: add_on_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.add_on_categories_id_seq', 8, true);


--
-- Name: add_on_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.add_on_purchases_id_seq', 1, false);


--
-- Name: add_on_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.add_on_reviews_id_seq', 1, false);


--
-- Name: add_ons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.add_ons_id_seq', 10, true);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: app_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_definitions_id_seq', 10, true);


--
-- Name: app_model_list_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_model_list_items_id_seq', 22, true);


--
-- Name: app_model_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_model_lists_id_seq', 4, true);


--
-- Name: branding_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branding_assets_id_seq', 1, false);


--
-- Name: branding_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branding_audit_log_id_seq', 9, true);


--
-- Name: branding_tier_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branding_tier_limits_id_seq', 5, true);


--
-- Name: byok_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.byok_keys_id_seq', 1, false);


--
-- Name: byok_pricing_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.byok_pricing_rules_id_seq', 1, false);


--
-- Name: cart_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cart_items_id_seq', 1, false);


--
-- Name: compliance_controls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_controls_id_seq', 17, true);


--
-- Name: compliance_evidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_evidence_id_seq', 1, false);


--
-- Name: compliance_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_metrics_id_seq', 1, false);


--
-- Name: compliance_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_reports_id_seq', 1, false);


--
-- Name: compliance_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_schedules_id_seq', 1, false);


--
-- Name: credit_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_packages_id_seq', 5, true);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_purchases_id_seq', 5, true);


--
-- Name: custom_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_roles_id_seq', 8, true);


--
-- Name: data_retention_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.data_retention_policies_id_seq', 1, false);


--
-- Name: email_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_history_id_seq', 3, true);


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 1, false);


--
-- Name: email_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_providers_id_seq', 6, true);


--
-- Name: invite_code_redemptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invite_code_redemptions_id_seq', 1, false);


--
-- Name: invite_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invite_codes_id_seq', 3, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: k8s_cost_attribution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.k8s_cost_attribution_id_seq', 1, false);


--
-- Name: k8s_resource_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.k8s_resource_metrics_id_seq', 1, false);


--
-- Name: model_access_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_access_audit_id_seq', 1, false);


--
-- Name: org_billing_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.org_billing_history_id_seq', 1, true);


--
-- Name: organization_branding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_branding_id_seq', 6, true);


--
-- Name: organization_credit_pools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_credit_pools_id_seq', 1, true);


--
-- Name: payment_dunning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_dunning_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 33, true);


--
-- Name: platform_pricing_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_pricing_rules_id_seq', 1, false);


--
-- Name: platform_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_settings_id_seq', 2, true);


--
-- Name: policy_acknowledgments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.policy_acknowledgments_id_seq', 1, false);


--
-- Name: pricing_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pricing_rules_id_seq', 1, false);


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 1, false);


--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rbac_audit_log_id_seq', 1, false);


--
-- Name: resource_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resource_policies_id_seq', 1, false);


--
-- Name: role_inheritance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_inheritance_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 91, true);


--
-- Name: security_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.security_incidents_id_seq', 1, false);


--
-- Name: server_health_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.server_health_checks_id_seq', 1, false);


--
-- Name: server_metrics_aggregated_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.server_metrics_aggregated_id_seq', 1, false);


--
-- Name: subscription_tiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_tiers_id_seq', 8, true);


--
-- Name: tier_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tier_features_id_seq', 135, true);


--
-- Name: usage_aggregates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usage_aggregates_id_seq', 1, false);


--
-- Name: usage_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usage_events_id_seq', 1, false);


--
-- Name: user_byok_credits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_byok_credits_id_seq', 1, false);


--
-- Name: user_model_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_model_preferences_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 1, false);


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_subscriptions_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: add_on_categories add_on_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_categories
    ADD CONSTRAINT add_on_categories_pkey PRIMARY KEY (id);


--
-- Name: add_on_categories add_on_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_categories
    ADD CONSTRAINT add_on_categories_slug_key UNIQUE (slug);


--
-- Name: add_on_purchases add_on_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_purchases
    ADD CONSTRAINT add_on_purchases_pkey PRIMARY KEY (id);


--
-- Name: add_on_reviews add_on_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_reviews
    ADD CONSTRAINT add_on_reviews_pkey PRIMARY KEY (id);


--
-- Name: add_ons add_ons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_ons
    ADD CONSTRAINT add_ons_pkey PRIMARY KEY (id);


--
-- Name: add_ons add_ons_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_ons
    ADD CONSTRAINT add_ons_slug_key UNIQUE (slug);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alert_correlations alert_correlations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_correlations
    ADD CONSTRAINT alert_correlations_pkey PRIMARY KEY (id);


--
-- Name: alert_feedback alert_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_feedback
    ADD CONSTRAINT alert_feedback_pkey PRIMARY KEY (id);


--
-- Name: alert_predictions alert_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_predictions
    ADD CONSTRAINT alert_predictions_pkey PRIMARY KEY (id);


--
-- Name: alert_suppression_rules alert_suppression_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_suppression_rules
    ADD CONSTRAINT alert_suppression_rules_pkey PRIMARY KEY (id);


--
-- Name: anomaly_detections anomaly_detections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anomaly_detections
    ADD CONSTRAINT anomaly_detections_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: app_definitions app_definitions_app_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_definitions
    ADD CONSTRAINT app_definitions_app_key_key UNIQUE (app_key);


--
-- Name: app_definitions app_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_definitions
    ADD CONSTRAINT app_definitions_pkey PRIMARY KEY (id);


--
-- Name: app_model_list_items app_model_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_list_items
    ADD CONSTRAINT app_model_list_items_pkey PRIMARY KEY (id);


--
-- Name: app_model_lists app_model_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_lists
    ADD CONSTRAINT app_model_lists_pkey PRIMARY KEY (id);


--
-- Name: app_model_lists app_model_lists_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_lists
    ADD CONSTRAINT app_model_lists_slug_key UNIQUE (slug);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: branding_assets branding_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_assets
    ADD CONSTRAINT branding_assets_pkey PRIMARY KEY (id);


--
-- Name: branding_audit_log branding_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_audit_log
    ADD CONSTRAINT branding_audit_log_pkey PRIMARY KEY (id);


--
-- Name: branding_tier_limits branding_tier_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_tier_limits
    ADD CONSTRAINT branding_tier_limits_pkey PRIMARY KEY (id);


--
-- Name: branding_tier_limits branding_tier_limits_tier_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_tier_limits
    ADD CONSTRAINT branding_tier_limits_tier_code_key UNIQUE (tier_code);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: byok_keys byok_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_keys
    ADD CONSTRAINT byok_keys_pkey PRIMARY KEY (id);


--
-- Name: byok_keys byok_keys_user_id_key_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_keys
    ADD CONSTRAINT byok_keys_user_id_key_name_key UNIQUE (user_id, key_name);


--
-- Name: byok_pricing_rules byok_pricing_rules_model_pattern_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_pricing_rules
    ADD CONSTRAINT byok_pricing_rules_model_pattern_key UNIQUE (model_pattern);


--
-- Name: byok_pricing_rules byok_pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_pricing_rules
    ADD CONSTRAINT byok_pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: cloud_credentials cloud_credentials_name_provider_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_credentials
    ADD CONSTRAINT cloud_credentials_name_provider_key UNIQUE (name, provider);


--
-- Name: cloud_credentials cloud_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_credentials
    ADD CONSTRAINT cloud_credentials_pkey PRIMARY KEY (credential_id);


--
-- Name: cloudflare_dns_records cloudflare_dns_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloudflare_dns_records
    ADD CONSTRAINT cloudflare_dns_records_pkey PRIMARY KEY (id);


--
-- Name: cloudflare_domains cloudflare_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloudflare_domains
    ADD CONSTRAINT cloudflare_domains_pkey PRIMARY KEY (id);


--
-- Name: cloudflare_firewall_rules cloudflare_firewall_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloudflare_firewall_rules
    ADD CONSTRAINT cloudflare_firewall_rules_pkey PRIMARY KEY (id);


--
-- Name: cloudflare_zones cloudflare_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloudflare_zones
    ADD CONSTRAINT cloudflare_zones_pkey PRIMARY KEY (id);


--
-- Name: compliance_controls compliance_controls_control_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_control_id_key UNIQUE (control_id);


--
-- Name: compliance_controls compliance_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_pkey PRIMARY KEY (id);


--
-- Name: compliance_evidence compliance_evidence_evidence_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_evidence
    ADD CONSTRAINT compliance_evidence_evidence_id_key UNIQUE (evidence_id);


--
-- Name: compliance_evidence compliance_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_evidence
    ADD CONSTRAINT compliance_evidence_pkey PRIMARY KEY (id);


--
-- Name: compliance_metrics compliance_metrics_metric_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_metrics
    ADD CONSTRAINT compliance_metrics_metric_id_key UNIQUE (metric_id);


--
-- Name: compliance_metrics compliance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_metrics
    ADD CONSTRAINT compliance_metrics_pkey PRIMARY KEY (id);


--
-- Name: compliance_reports compliance_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_reports
    ADD CONSTRAINT compliance_reports_pkey PRIMARY KEY (id);


--
-- Name: compliance_reports compliance_reports_report_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_reports
    ADD CONSTRAINT compliance_reports_report_id_key UNIQUE (report_id);


--
-- Name: compliance_schedules compliance_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_schedules
    ADD CONSTRAINT compliance_schedules_pkey PRIMARY KEY (id);


--
-- Name: compliance_schedules compliance_schedules_schedule_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_schedules
    ADD CONSTRAINT compliance_schedules_schedule_id_key UNIQUE (schedule_id);


--
-- Name: cost_analysis cost_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_analysis
    ADD CONSTRAINT cost_analysis_pkey PRIMARY KEY (id);


--
-- Name: cost_analysis cost_analysis_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_analysis
    ADD CONSTRAINT cost_analysis_unique UNIQUE (organization_id, user_id, period_start, period_type, model_name);


--
-- Name: cost_forecasts cost_forecasts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_forecasts
    ADD CONSTRAINT cost_forecasts_pkey PRIMARY KEY (id);


--
-- Name: cost_forecasts cost_forecasts_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_forecasts
    ADD CONSTRAINT cost_forecasts_unique UNIQUE (organization_id, budget_id, forecast_date, forecast_horizon_days);


--
-- Name: cost_recommendations cost_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_recommendations
    ADD CONSTRAINT cost_recommendations_pkey PRIMARY KEY (id);


--
-- Name: credit_packages credit_packages_package_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_packages
    ADD CONSTRAINT credit_packages_package_code_key UNIQUE (package_code);


--
-- Name: credit_packages credit_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_packages
    ADD CONSTRAINT credit_packages_pkey PRIMARY KEY (id);


--
-- Name: credit_purchases credit_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_pkey PRIMARY KEY (id);


--
-- Name: credit_usage_attribution credit_usage_attribution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_usage_attribution
    ADD CONSTRAINT credit_usage_attribution_pkey PRIMARY KEY (id);


--
-- Name: custom_roles custom_roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_roles
    ADD CONSTRAINT custom_roles_name_key UNIQUE (name);


--
-- Name: custom_roles custom_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_roles
    ADD CONSTRAINT custom_roles_pkey PRIMARY KEY (id);


--
-- Name: data_retention_policies data_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_retention_policies
    ADD CONSTRAINT data_retention_policies_pkey PRIMARY KEY (id);


--
-- Name: data_retention_policies data_retention_policies_policy_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_retention_policies
    ADD CONSTRAINT data_retention_policies_policy_id_key UNIQUE (policy_id);


--
-- Name: email_history email_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_history
    ADD CONSTRAINT email_history_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: email_providers email_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_providers
    ADD CONSTRAINT email_providers_pkey PRIMARY KEY (id);


--
-- Name: iac_templates iac_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iac_templates
    ADD CONSTRAINT iac_templates_pkey PRIMARY KEY (template_id);


--
-- Name: invite_code_redemptions invite_code_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_code_redemptions
    ADD CONSTRAINT invite_code_redemptions_pkey PRIMARY KEY (id);


--
-- Name: invite_codes invite_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_code_key UNIQUE (code);


--
-- Name: invite_codes invite_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_stripe_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_stripe_invoice_id_key UNIQUE (stripe_invoice_id);


--
-- Name: k8s_clusters k8s_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_clusters
    ADD CONSTRAINT k8s_clusters_pkey PRIMARY KEY (id);


--
-- Name: k8s_cost_attribution k8s_cost_attribution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_cost_attribution
    ADD CONSTRAINT k8s_cost_attribution_pkey PRIMARY KEY (id);


--
-- Name: k8s_deployments k8s_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_deployments
    ADD CONSTRAINT k8s_deployments_pkey PRIMARY KEY (id);


--
-- Name: k8s_helm_releases k8s_helm_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_helm_releases
    ADD CONSTRAINT k8s_helm_releases_pkey PRIMARY KEY (id);


--
-- Name: k8s_namespaces k8s_namespaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_namespaces
    ADD CONSTRAINT k8s_namespaces_pkey PRIMARY KEY (id);


--
-- Name: k8s_nodes k8s_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_nodes
    ADD CONSTRAINT k8s_nodes_pkey PRIMARY KEY (id);


--
-- Name: k8s_pods k8s_pods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods
    ADD CONSTRAINT k8s_pods_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_01 k8s_pods_2026_01_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_01
    ADD CONSTRAINT k8s_pods_2026_01_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_02 k8s_pods_2026_02_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_02
    ADD CONSTRAINT k8s_pods_2026_02_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_03 k8s_pods_2026_03_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_03
    ADD CONSTRAINT k8s_pods_2026_03_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_04 k8s_pods_2026_04_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_04
    ADD CONSTRAINT k8s_pods_2026_04_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_05 k8s_pods_2026_05_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_05
    ADD CONSTRAINT k8s_pods_2026_05_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_06 k8s_pods_2026_06_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_06
    ADD CONSTRAINT k8s_pods_2026_06_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_07 k8s_pods_2026_07_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_07
    ADD CONSTRAINT k8s_pods_2026_07_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_08 k8s_pods_2026_08_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_08
    ADD CONSTRAINT k8s_pods_2026_08_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_09 k8s_pods_2026_09_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_09
    ADD CONSTRAINT k8s_pods_2026_09_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_10 k8s_pods_2026_10_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_10
    ADD CONSTRAINT k8s_pods_2026_10_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_11 k8s_pods_2026_11_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_11
    ADD CONSTRAINT k8s_pods_2026_11_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_pods_2026_12 k8s_pods_2026_12_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_pods_2026_12
    ADD CONSTRAINT k8s_pods_2026_12_pkey PRIMARY KEY (id, created_at);


--
-- Name: k8s_resource_metrics k8s_resource_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics
    ADD CONSTRAINT k8s_resource_metrics_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_01 k8s_resource_metrics_2026_01_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_01
    ADD CONSTRAINT k8s_resource_metrics_2026_01_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_02 k8s_resource_metrics_2026_02_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_02
    ADD CONSTRAINT k8s_resource_metrics_2026_02_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_03 k8s_resource_metrics_2026_03_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_03
    ADD CONSTRAINT k8s_resource_metrics_2026_03_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_04 k8s_resource_metrics_2026_04_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_04
    ADD CONSTRAINT k8s_resource_metrics_2026_04_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_05 k8s_resource_metrics_2026_05_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_05
    ADD CONSTRAINT k8s_resource_metrics_2026_05_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_06 k8s_resource_metrics_2026_06_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_06
    ADD CONSTRAINT k8s_resource_metrics_2026_06_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_07 k8s_resource_metrics_2026_07_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_07
    ADD CONSTRAINT k8s_resource_metrics_2026_07_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_08 k8s_resource_metrics_2026_08_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_08
    ADD CONSTRAINT k8s_resource_metrics_2026_08_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_09 k8s_resource_metrics_2026_09_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_09
    ADD CONSTRAINT k8s_resource_metrics_2026_09_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_10 k8s_resource_metrics_2026_10_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_10
    ADD CONSTRAINT k8s_resource_metrics_2026_10_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_11 k8s_resource_metrics_2026_11_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_11
    ADD CONSTRAINT k8s_resource_metrics_2026_11_pkey PRIMARY KEY (id, collected_at);


--
-- Name: k8s_resource_metrics_2026_12 k8s_resource_metrics_2026_12_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_resource_metrics_2026_12
    ADD CONSTRAINT k8s_resource_metrics_2026_12_pkey PRIMARY KEY (id, collected_at);


--
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_provider_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_id_name_key UNIQUE (provider_id, name);


--
-- Name: llm_providers llm_providers_name_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_name_type_key UNIQUE (name, type);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (id);


--
-- Name: llm_routing_rules llm_routing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_routing_rules
    ADD CONSTRAINT llm_routing_rules_pkey PRIMARY KEY (id);


--
-- Name: llm_usage_logs llm_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_usage_logs
    ADD CONSTRAINT llm_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: managed_servers managed_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_servers
    ADD CONSTRAINT managed_servers_pkey PRIMARY KEY (id);


--
-- Name: migration_jobs migration_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_jobs
    ADD CONSTRAINT migration_jobs_pkey PRIMARY KEY (id);


--
-- Name: model_access_audit model_access_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_access_audit
    ADD CONSTRAINT model_access_audit_pkey PRIMARY KEY (id);


--
-- Name: model_pricing model_pricing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_pricing
    ADD CONSTRAINT model_pricing_pkey PRIMARY KEY (id);


--
-- Name: model_pricing model_pricing_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_pricing
    ADD CONSTRAINT model_pricing_unique UNIQUE (provider, model_name, effective_date);


--
-- Name: namecheap_domains namecheap_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.namecheap_domains
    ADD CONSTRAINT namecheap_domains_pkey PRIMARY KEY (id);


--
-- Name: org_billing_history org_billing_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_billing_history
    ADD CONSTRAINT org_billing_history_pkey PRIMARY KEY (id);


--
-- Name: organization_branding organization_branding_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT organization_branding_org_id_key UNIQUE (org_id);


--
-- Name: organization_branding organization_branding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT organization_branding_pkey PRIMARY KEY (id);


--
-- Name: organization_credit_pools organization_credit_pools_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_credit_pools
    ADD CONSTRAINT organization_credit_pools_org_id_key UNIQUE (org_id);


--
-- Name: organization_credit_pools organization_credit_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_credit_pools
    ADD CONSTRAINT organization_credit_pools_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organization_members organization_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_pkey PRIMARY KEY (id);


--
-- Name: organization_subscriptions organization_subscriptions_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_subscriptions
    ADD CONSTRAINT organization_subscriptions_org_id_key UNIQUE (org_id);


--
-- Name: organization_subscriptions organization_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_subscriptions
    ADD CONSTRAINT organization_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: payment_dunning payment_dunning_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_dunning
    ADD CONSTRAINT payment_dunning_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: platform_pricing_rules platform_pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_pricing_rules
    ADD CONSTRAINT platform_pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: platform_pricing_rules platform_pricing_rules_tier_code_model_pattern_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_pricing_rules
    ADD CONSTRAINT platform_pricing_rules_tier_code_model_pattern_key UNIQUE (tier_code, model_pattern);


--
-- Name: platform_settings platform_settings_category_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_category_key_key UNIQUE (category, key);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: policy_acknowledgments policy_acknowledgments_acknowledgment_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_acknowledgments
    ADD CONSTRAINT policy_acknowledgments_acknowledgment_id_key UNIQUE (acknowledgment_id);


--
-- Name: policy_acknowledgments policy_acknowledgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_acknowledgments
    ADD CONSTRAINT policy_acknowledgments_pkey PRIMARY KEY (id);


--
-- Name: pricing_rules pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_api_key_id_window_type_window_start_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_api_key_id_window_type_window_start_key UNIQUE (api_key_id, window_type, window_start);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: rbac_audit_log rbac_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rbac_audit_log
    ADD CONSTRAINT rbac_audit_log_pkey PRIMARY KEY (id);


--
-- Name: resource_policies resource_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policies
    ADD CONSTRAINT resource_policies_pkey PRIMARY KEY (id);


--
-- Name: role_inheritance role_inheritance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_inheritance
    ADD CONSTRAINT role_inheritance_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: saml_assertions saml_assertions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_assertions
    ADD CONSTRAINT saml_assertions_pkey PRIMARY KEY (assertion_id);


--
-- Name: saml_attribute_mappings saml_attribute_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_attribute_mappings
    ADD CONSTRAINT saml_attribute_mappings_pkey PRIMARY KEY (mapping_id);


--
-- Name: saml_audit_log saml_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_audit_log
    ADD CONSTRAINT saml_audit_log_pkey PRIMARY KEY (log_id);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (provider_id);


--
-- Name: saml_sessions saml_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_sessions
    ADD CONSTRAINT saml_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: saml_sessions saml_sessions_saml_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_sessions
    ADD CONSTRAINT saml_sessions_saml_session_id_key UNIQUE (saml_session_id);


--
-- Name: savings_opportunities savings_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.savings_opportunities
    ADD CONSTRAINT savings_opportunities_pkey PRIMARY KEY (id);


--
-- Name: security_incidents security_incidents_incident_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_incident_id_key UNIQUE (incident_id);


--
-- Name: security_incidents security_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);


--
-- Name: server_group_members server_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_group_members
    ADD CONSTRAINT server_group_members_pkey PRIMARY KEY (server_id, group_id);


--
-- Name: server_groups server_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_groups
    ADD CONSTRAINT server_groups_pkey PRIMARY KEY (id);


--
-- Name: server_health_checks server_health_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks
    ADD CONSTRAINT server_health_checks_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_01 server_health_checks_2026_01_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_01
    ADD CONSTRAINT server_health_checks_2026_01_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_02 server_health_checks_2026_02_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_02
    ADD CONSTRAINT server_health_checks_2026_02_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_03 server_health_checks_2026_03_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_03
    ADD CONSTRAINT server_health_checks_2026_03_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_04 server_health_checks_2026_04_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_04
    ADD CONSTRAINT server_health_checks_2026_04_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_05 server_health_checks_2026_05_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_05
    ADD CONSTRAINT server_health_checks_2026_05_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_06 server_health_checks_2026_06_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_06
    ADD CONSTRAINT server_health_checks_2026_06_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_07 server_health_checks_2026_07_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_07
    ADD CONSTRAINT server_health_checks_2026_07_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_08 server_health_checks_2026_08_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_08
    ADD CONSTRAINT server_health_checks_2026_08_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_09 server_health_checks_2026_09_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_09
    ADD CONSTRAINT server_health_checks_2026_09_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_10 server_health_checks_2026_10_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_10
    ADD CONSTRAINT server_health_checks_2026_10_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_11 server_health_checks_2026_11_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_11
    ADD CONSTRAINT server_health_checks_2026_11_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_health_checks_2026_12 server_health_checks_2026_12_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_health_checks_2026_12
    ADD CONSTRAINT server_health_checks_2026_12_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated server_metrics_aggregated_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated
    ADD CONSTRAINT server_metrics_aggregated_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_01 server_metrics_aggregated_2026_01_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_01
    ADD CONSTRAINT server_metrics_aggregated_2026_01_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_02 server_metrics_aggregated_2026_02_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_02
    ADD CONSTRAINT server_metrics_aggregated_2026_02_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_03 server_metrics_aggregated_2026_03_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_03
    ADD CONSTRAINT server_metrics_aggregated_2026_03_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_04 server_metrics_aggregated_2026_04_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_04
    ADD CONSTRAINT server_metrics_aggregated_2026_04_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_05 server_metrics_aggregated_2026_05_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_05
    ADD CONSTRAINT server_metrics_aggregated_2026_05_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_06 server_metrics_aggregated_2026_06_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_06
    ADD CONSTRAINT server_metrics_aggregated_2026_06_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_07 server_metrics_aggregated_2026_07_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_07
    ADD CONSTRAINT server_metrics_aggregated_2026_07_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_08 server_metrics_aggregated_2026_08_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_08
    ADD CONSTRAINT server_metrics_aggregated_2026_08_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_09 server_metrics_aggregated_2026_09_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_09
    ADD CONSTRAINT server_metrics_aggregated_2026_09_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_10 server_metrics_aggregated_2026_10_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_10
    ADD CONSTRAINT server_metrics_aggregated_2026_10_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_11 server_metrics_aggregated_2026_11_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_11
    ADD CONSTRAINT server_metrics_aggregated_2026_11_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_12 server_metrics_aggregated_2026_12_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_metrics_aggregated_2026_12
    ADD CONSTRAINT server_metrics_aggregated_2026_12_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: smart_alert_models smart_alert_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_alert_models
    ADD CONSTRAINT smart_alert_models_pkey PRIMARY KEY (id);


--
-- Name: subscription_tiers subscription_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_tiers
    ADD CONSTRAINT subscription_tiers_pkey PRIMARY KEY (id);


--
-- Name: subscription_tiers subscription_tiers_tier_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_tiers
    ADD CONSTRAINT subscription_tiers_tier_code_key UNIQUE (tier_code);


--
-- Name: terraform_drift_detections terraform_drift_detections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_drift_detections
    ADD CONSTRAINT terraform_drift_detections_pkey PRIMARY KEY (drift_id);


--
-- Name: terraform_executions terraform_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_executions
    ADD CONSTRAINT terraform_executions_pkey PRIMARY KEY (execution_id);


--
-- Name: terraform_resources terraform_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_resources
    ADD CONSTRAINT terraform_resources_pkey PRIMARY KEY (resource_id);


--
-- Name: terraform_resources terraform_resources_workspace_id_address_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_resources
    ADD CONSTRAINT terraform_resources_workspace_id_address_key UNIQUE (workspace_id, address);


--
-- Name: terraform_states terraform_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_states
    ADD CONSTRAINT terraform_states_pkey PRIMARY KEY (state_id);


--
-- Name: terraform_states terraform_states_workspace_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_states
    ADD CONSTRAINT terraform_states_workspace_id_version_key UNIQUE (workspace_id, version);


--
-- Name: terraform_variables terraform_variables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_variables
    ADD CONSTRAINT terraform_variables_pkey PRIMARY KEY (variable_id);


--
-- Name: terraform_variables terraform_variables_workspace_id_key_category_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_variables
    ADD CONSTRAINT terraform_variables_workspace_id_key_category_key UNIQUE (workspace_id, key, category);


--
-- Name: terraform_workspaces terraform_workspaces_name_environment_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_workspaces
    ADD CONSTRAINT terraform_workspaces_name_environment_key UNIQUE (name, environment);


--
-- Name: terraform_workspaces terraform_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_workspaces
    ADD CONSTRAINT terraform_workspaces_pkey PRIMARY KEY (workspace_id);


--
-- Name: tier_features tier_features_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tier_features
    ADD CONSTRAINT tier_features_pkey PRIMARY KEY (id);


--
-- Name: tier_features tier_features_tier_id_feature_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tier_features
    ADD CONSTRAINT tier_features_tier_id_feature_key_key UNIQUE (tier_id, feature_key);


--
-- Name: k8s_cost_attribution uk_k8s_cost_ns_date_hour; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_cost_attribution
    ADD CONSTRAINT uk_k8s_cost_ns_date_hour UNIQUE (namespace_id, date, hour);


--
-- Name: k8s_deployments uk_k8s_deploy_ns_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_deployments
    ADD CONSTRAINT uk_k8s_deploy_ns_name UNIQUE (namespace_id, name);


--
-- Name: k8s_helm_releases uk_k8s_helm_ns_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_helm_releases
    ADD CONSTRAINT uk_k8s_helm_ns_name UNIQUE (namespace_id, name);


--
-- Name: k8s_nodes uk_k8s_node_cluster_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_nodes
    ADD CONSTRAINT uk_k8s_node_cluster_name UNIQUE (cluster_id, name);


--
-- Name: k8s_namespaces uk_k8s_ns_cluster_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_namespaces
    ADD CONSTRAINT uk_k8s_ns_cluster_name UNIQUE (cluster_id, name);


--
-- Name: app_model_list_items unique_model_per_list; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_list_items
    ADD CONSTRAINT unique_model_per_list UNIQUE (list_id, model_id);


--
-- Name: permissions unique_resource_action; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT unique_resource_action UNIQUE (resource, action);


--
-- Name: resource_policies unique_resource_policy; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policies
    ADD CONSTRAINT unique_resource_policy UNIQUE (resource_type, resource_id);


--
-- Name: role_inheritance unique_role_inheritance; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_inheritance
    ADD CONSTRAINT unique_role_inheritance UNIQUE (parent_role_id, child_role_id);


--
-- Name: role_permissions unique_role_permission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT unique_role_permission UNIQUE (role_id, permission_id);


--
-- Name: cart_items unique_user_addon_cart; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT unique_user_addon_cart UNIQUE (user_id, add_on_id);


--
-- Name: add_on_reviews unique_user_addon_review; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_reviews
    ADD CONSTRAINT unique_user_addon_review UNIQUE (add_on_id, user_id);


--
-- Name: user_model_preferences unique_user_model_pref; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_model_preferences
    ADD CONSTRAINT unique_user_model_pref UNIQUE (user_id, model_id);


--
-- Name: user_roles unique_user_role_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT unique_user_role_org UNIQUE (user_email, role_id, organization_id);


--
-- Name: user_subscriptions uq_user_subscriptions_email; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT uq_user_subscriptions_email UNIQUE (email);


--
-- Name: usage_aggregates usage_aggregates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_aggregates
    ADD CONSTRAINT usage_aggregates_pkey PRIMARY KEY (id);


--
-- Name: usage_aggregates usage_aggregates_subscription_id_period_type_period_start_a_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_aggregates
    ADD CONSTRAINT usage_aggregates_subscription_id_period_type_period_start_a_key UNIQUE (subscription_id, period_type, period_start, api_key_id);


--
-- Name: usage_events usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_events
    ADD CONSTRAINT usage_events_pkey PRIMARY KEY (id, created_at);


--
-- Name: usage_events_2026_01 usage_events_2026_01_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_events_2026_01
    ADD CONSTRAINT usage_events_2026_01_pkey PRIMARY KEY (id, created_at);


--
-- Name: usage_events_2026_02 usage_events_2026_02_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_events_2026_02
    ADD CONSTRAINT usage_events_2026_02_pkey PRIMARY KEY (id, created_at);


--
-- Name: user_api_keys user_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_api_keys
    ADD CONSTRAINT user_api_keys_pkey PRIMARY KEY (id);


--
-- Name: user_byok_credits user_byok_credits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_byok_credits
    ADD CONSTRAINT user_byok_credits_pkey PRIMARY KEY (id);


--
-- Name: user_byok_credits user_byok_credits_user_id_tier_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_byok_credits
    ADD CONSTRAINT user_byok_credits_user_id_tier_code_key UNIQUE (user_id, tier_code);


--
-- Name: user_credit_allocations user_credit_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credit_allocations
    ADD CONSTRAINT user_credit_allocations_pkey PRIMARY KEY (id);


--
-- Name: user_credit_allocations user_credit_allocations_user_id_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credit_allocations
    ADD CONSTRAINT user_credit_allocations_user_id_org_id_key UNIQUE (user_id, org_id);


--
-- Name: user_llm_settings user_llm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_llm_settings
    ADD CONSTRAINT user_llm_settings_pkey PRIMARY KEY (user_id);


--
-- Name: user_model_preferences user_model_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_model_preferences
    ADD CONSTRAINT user_model_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_provider_keys user_provider_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_provider_keys
    ADD CONSTRAINT user_provider_keys_pkey PRIMARY KEY (id);


--
-- Name: user_provider_keys user_provider_keys_user_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_provider_keys
    ADD CONSTRAINT user_provider_keys_user_id_provider_key UNIQUE (user_id, provider);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: workspace_credentials workspace_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_credentials
    ADD CONSTRAINT workspace_credentials_pkey PRIMARY KEY (workspace_id, credential_id);


--
-- Name: idx_addon_categories_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_addon_categories_slug ON public.add_on_categories USING btree (slug);


--
-- Name: idx_addons_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_addons_active ON public.add_ons USING btree (is_active);


--
-- Name: idx_addons_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_addons_category ON public.add_ons USING btree (category_id);


--
-- Name: idx_addons_featured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_addons_featured ON public.add_ons USING btree (is_featured);


--
-- Name: idx_addons_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_addons_slug ON public.add_ons USING btree (slug);


--
-- Name: idx_alert_correlations_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_correlations_group ON public.alert_correlations USING btree (correlation_group_id);


--
-- Name: idx_alert_feedback_alert; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_feedback_alert ON public.alert_feedback USING btree (alert_id);


--
-- Name: idx_alert_predictions_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_predictions_device ON public.alert_predictions USING btree (device_id);


--
-- Name: idx_alert_suppression_rules_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_suppression_rules_active ON public.alert_suppression_rules USING btree (active);


--
-- Name: idx_anomaly_detections_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_anomaly_detections_device ON public.anomaly_detections USING btree (device_id);


--
-- Name: idx_anomaly_detections_metric; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_anomaly_detections_metric ON public.anomaly_detections USING btree (metric_name);


--
-- Name: idx_api_keys_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_active ON public.api_keys USING btree (is_active, is_revoked) WHERE ((is_active = true) AND (is_revoked = false));


--
-- Name: idx_api_keys_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_email ON public.api_keys USING btree (email);


--
-- Name: idx_api_keys_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_prefix ON public.api_keys USING btree (key_prefix);


--
-- Name: idx_api_keys_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_subscription ON public.api_keys USING btree (subscription_id);


--
-- Name: idx_app_definitions_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_definitions_active ON public.app_definitions USING btree (is_active);


--
-- Name: idx_app_definitions_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_definitions_category ON public.app_definitions USING btree (category);


--
-- Name: idx_app_model_lists_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_model_lists_active ON public.app_model_lists USING btree (is_active);


--
-- Name: idx_app_model_lists_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_model_lists_app ON public.app_model_lists USING btree (app_identifier);


--
-- Name: idx_app_model_lists_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_model_lists_slug ON public.app_model_lists USING btree (slug);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_action ON public.model_access_audit USING btree (action);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_actor ON public.model_access_audit USING btree (actor_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created ON public.model_access_audit USING btree (created_at);


--
-- Name: idx_audit_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_list ON public.model_access_audit USING btree (list_id);


--
-- Name: idx_branding_assets_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branding_assets_org ON public.branding_assets USING btree (org_id);


--
-- Name: idx_branding_assets_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branding_assets_type ON public.branding_assets USING btree (asset_type);


--
-- Name: idx_branding_audit_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branding_audit_org ON public.branding_audit_log USING btree (org_id);


--
-- Name: idx_branding_audit_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branding_audit_time ON public.branding_audit_log USING btree (created_at DESC);


--
-- Name: idx_budgets_alert_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_budgets_alert_level ON public.budgets USING btree (alert_level) WHERE (alert_enabled = true);


--
-- Name: idx_budgets_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_budgets_dates ON public.budgets USING btree (start_date, end_date);


--
-- Name: idx_budgets_org_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_budgets_org_active ON public.budgets USING btree (organization_id, is_active);


--
-- Name: idx_byok_keys_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_byok_keys_provider ON public.byok_keys USING btree (provider);


--
-- Name: idx_byok_keys_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_byok_keys_user_id ON public.byok_keys USING btree (user_id);


--
-- Name: idx_cart_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cart_user ON public.cart_items USING btree (user_id);


--
-- Name: idx_cloud_credentials_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cloud_credentials_provider ON public.cloud_credentials USING btree (provider);


--
-- Name: idx_compliance_controls_automated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_controls_automated ON public.compliance_controls USING btree (automated);


--
-- Name: idx_compliance_controls_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_controls_category ON public.compliance_controls USING btree (category);


--
-- Name: idx_compliance_controls_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_controls_status ON public.compliance_controls USING btree (implementation_status);


--
-- Name: idx_compliance_evidence_collected; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_evidence_collected ON public.compliance_evidence USING btree (collected_at);


--
-- Name: idx_compliance_evidence_control; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_evidence_control ON public.compliance_evidence USING btree (control_id);


--
-- Name: idx_compliance_evidence_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_evidence_expires ON public.compliance_evidence USING btree (expires_at);


--
-- Name: idx_compliance_evidence_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_evidence_type ON public.compliance_evidence USING btree (evidence_type);


--
-- Name: idx_compliance_metrics_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_metrics_category ON public.compliance_metrics USING btree (metric_category);


--
-- Name: idx_compliance_metrics_collected; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_metrics_collected ON public.compliance_metrics USING btree (collected_at);


--
-- Name: idx_compliance_metrics_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_metrics_name ON public.compliance_metrics USING btree (metric_name);


--
-- Name: idx_compliance_metrics_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_metrics_status ON public.compliance_metrics USING btree (status);


--
-- Name: idx_compliance_reports_generated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_reports_generated ON public.compliance_reports USING btree (generated_at);


--
-- Name: idx_compliance_reports_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_reports_period ON public.compliance_reports USING btree (period_start, period_end);


--
-- Name: idx_compliance_reports_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_reports_type ON public.compliance_reports USING btree (report_type);


--
-- Name: idx_compliance_schedules_control; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_schedules_control ON public.compliance_schedules USING btree (control_id);


--
-- Name: idx_compliance_schedules_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_schedules_enabled ON public.compliance_schedules USING btree (enabled);


--
-- Name: idx_compliance_schedules_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_schedules_next_run ON public.compliance_schedules USING btree (next_run_at);


--
-- Name: idx_cost_analysis_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cost_analysis_model ON public.cost_analysis USING btree (model_name, period_start DESC);


--
-- Name: idx_cost_analysis_org_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cost_analysis_org_period ON public.cost_analysis USING btree (organization_id, period_start DESC);


--
-- Name: idx_cost_analysis_period_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cost_analysis_period_type ON public.cost_analysis USING btree (period_type, period_start DESC);


--
-- Name: idx_cost_analysis_user_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cost_analysis_user_period ON public.cost_analysis USING btree (user_id, period_start DESC);


--
-- Name: idx_credit_purchases_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_purchases_session_id ON public.credit_purchases USING btree (stripe_checkout_session_id);


--
-- Name: idx_credit_purchases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_purchases_status ON public.credit_purchases USING btree (status);


--
-- Name: idx_credit_purchases_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_purchases_user_id ON public.credit_purchases USING btree (user_id);


--
-- Name: idx_credit_usage_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_usage_created_at ON public.credit_usage_attribution USING btree (created_at);


--
-- Name: idx_credit_usage_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_usage_org_id ON public.credit_usage_attribution USING btree (org_id);


--
-- Name: idx_credit_usage_service_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_usage_service_type ON public.credit_usage_attribution USING btree (service_type);


--
-- Name: idx_credit_usage_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_usage_user_id ON public.credit_usage_attribution USING btree (user_id);


--
-- Name: idx_custom_roles_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_roles_org ON public.custom_roles USING btree (organization_id);


--
-- Name: idx_custom_roles_system; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_roles_system ON public.custom_roles USING btree (is_system_role);


--
-- Name: idx_drift_detections_resolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drift_detections_resolved ON public.terraform_drift_detections USING btree (resolved);


--
-- Name: idx_drift_detections_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drift_detections_workspace ON public.terraform_drift_detections USING btree (workspace_id);


--
-- Name: idx_dunning_grace_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dunning_grace_period ON public.payment_dunning USING btree (grace_period_ends_at) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_dunning_next_retry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dunning_next_retry ON public.payment_dunning USING btree (next_retry_at) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_dunning_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dunning_status ON public.payment_dunning USING btree (status);


--
-- Name: idx_dunning_stripe_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dunning_stripe_invoice ON public.payment_dunning USING btree (stripe_invoice_id);


--
-- Name: idx_dunning_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dunning_subscription ON public.payment_dunning USING btree (subscription_id);


--
-- Name: idx_email_history_sent_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_history_sent_at ON public.email_history USING btree (sent_at DESC);


--
-- Name: idx_email_history_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_history_status ON public.email_history USING btree (status);


--
-- Name: idx_email_logs_metadata; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_logs_metadata ON public.email_logs USING gin (metadata);


--
-- Name: idx_email_logs_sent_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_logs_sent_at ON public.email_logs USING btree (sent_at DESC);


--
-- Name: idx_email_logs_success; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_logs_success ON public.email_logs USING btree (success);


--
-- Name: idx_email_logs_to_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_logs_to_email ON public.email_logs USING btree (to_email);


--
-- Name: idx_email_providers_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_providers_enabled ON public.email_providers USING btree (enabled);


--
-- Name: idx_email_providers_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_providers_type ON public.email_providers USING btree (provider_type);


--
-- Name: idx_forecasts_budget; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_forecasts_budget ON public.cost_forecasts USING btree (budget_id, forecast_date DESC);


--
-- Name: idx_forecasts_exhaustion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_forecasts_exhaustion ON public.cost_forecasts USING btree (budget_exhaustion_date) WHERE (budget_exhaustion_date IS NOT NULL);


--
-- Name: idx_forecasts_org_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_forecasts_org_date ON public.cost_forecasts USING btree (organization_id, forecast_date DESC);


--
-- Name: idx_iac_templates_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iac_templates_category ON public.iac_templates USING btree (category);


--
-- Name: idx_iac_templates_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iac_templates_provider ON public.iac_templates USING btree (cloud_provider);


--
-- Name: idx_iac_templates_public; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iac_templates_public ON public.iac_templates USING btree (is_public);


--
-- Name: idx_invite_code_redemptions_code_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_code_redemptions_code_id ON public.invite_code_redemptions USING btree (invite_code_id);


--
-- Name: idx_invite_code_redemptions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_code_redemptions_user_id ON public.invite_code_redemptions USING btree (user_id);


--
-- Name: idx_invite_codes_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_codes_active ON public.invite_codes USING btree (is_active);


--
-- Name: idx_invite_codes_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_codes_code ON public.invite_codes USING btree (code);


--
-- Name: idx_invite_codes_tier_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_codes_tier_code ON public.invite_codes USING btree (tier_code);


--
-- Name: idx_llm_models_cost; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_models_cost ON public.llm_models USING btree (cost_per_1m_input_tokens);


--
-- Name: idx_llm_models_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_models_enabled ON public.llm_models USING btree (enabled);


--
-- Name: idx_llm_models_power_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_models_power_level ON public.llm_models USING btree (power_level);


--
-- Name: idx_llm_models_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_models_provider ON public.llm_models USING btree (provider_id);


--
-- Name: idx_llm_providers_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_providers_enabled ON public.llm_providers USING btree (enabled);


--
-- Name: idx_llm_providers_health; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_providers_health ON public.llm_providers USING btree (health_status);


--
-- Name: idx_llm_providers_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_providers_priority ON public.llm_providers USING btree (priority DESC);


--
-- Name: idx_llm_usage_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_usage_created ON public.llm_usage_logs USING btree (created_at);


--
-- Name: idx_llm_usage_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_usage_provider ON public.llm_usage_logs USING btree (provider_id);


--
-- Name: idx_llm_usage_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_usage_status ON public.llm_usage_logs USING btree (status);


--
-- Name: idx_llm_usage_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_llm_usage_user ON public.llm_usage_logs USING btree (user_id);


--
-- Name: idx_managed_servers_environment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_environment ON public.managed_servers USING btree (environment);


--
-- Name: idx_managed_servers_health; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_health ON public.managed_servers USING btree (health_status);


--
-- Name: idx_managed_servers_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_last_seen ON public.managed_servers USING btree (last_seen_at);


--
-- Name: idx_managed_servers_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_org ON public.managed_servers USING btree (organization_id);


--
-- Name: idx_managed_servers_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_region ON public.managed_servers USING btree (region);


--
-- Name: idx_managed_servers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_status ON public.managed_servers USING btree (status);


--
-- Name: idx_managed_servers_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_servers_tags ON public.managed_servers USING gin (tags);


--
-- Name: idx_model_list_items_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_list_items_category ON public.app_model_list_items USING btree (category);


--
-- Name: idx_model_list_items_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_list_items_list ON public.app_model_list_items USING btree (list_id);


--
-- Name: idx_model_list_items_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_list_items_model ON public.app_model_list_items USING btree (model_id);


--
-- Name: idx_model_list_items_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_list_items_sort ON public.app_model_list_items USING btree (list_id, sort_order);


--
-- Name: idx_opportunities_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_assigned ON public.savings_opportunities USING btree (assigned_to) WHERE ((status)::text = ANY ((ARRAY['open'::character varying, 'investigating'::character varying, 'planned'::character varying])::text[]));


--
-- Name: idx_opportunities_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_org_status ON public.savings_opportunities USING btree (organization_id, status);


--
-- Name: idx_opportunities_savings; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_savings ON public.savings_opportunities USING btree (potential_savings DESC);


--
-- Name: idx_opportunities_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_type ON public.savings_opportunities USING btree (opportunity_type);


--
-- Name: idx_org_billing_history_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_billing_history_created_at ON public.org_billing_history USING btree (created_at);


--
-- Name: idx_org_billing_history_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_billing_history_org_id ON public.org_billing_history USING btree (org_id);


--
-- Name: idx_org_branding_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_branding_domain ON public.organization_branding USING btree (custom_domain) WHERE (custom_domain IS NOT NULL);


--
-- Name: idx_org_branding_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_branding_org_id ON public.organization_branding USING btree (org_id);


--
-- Name: idx_org_branding_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_branding_tier ON public.organization_branding USING btree (tier_code);


--
-- Name: idx_org_credit_pools_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_credit_pools_org_id ON public.organization_credit_pools USING btree (org_id);


--
-- Name: idx_org_subscriptions_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_subscriptions_org_id ON public.organization_subscriptions USING btree (org_id);


--
-- Name: idx_org_subscriptions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_subscriptions_status ON public.organization_subscriptions USING btree (status);


--
-- Name: idx_permissions_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_permissions_action ON public.permissions USING btree (action);


--
-- Name: idx_permissions_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_permissions_resource ON public.permissions USING btree (resource);


--
-- Name: idx_platform_settings_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_platform_settings_category ON public.platform_settings USING btree (category);


--
-- Name: idx_policy_ack_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_policy_ack_date ON public.policy_acknowledgments USING btree (acknowledged_at);


--
-- Name: idx_policy_ack_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_policy_ack_expires ON public.policy_acknowledgments USING btree (expires_at);


--
-- Name: idx_policy_ack_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_policy_ack_policy ON public.policy_acknowledgments USING btree (policy_name);


--
-- Name: idx_policy_ack_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_policy_ack_user ON public.policy_acknowledgments USING btree (user_email);


--
-- Name: idx_pricing_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_active ON public.model_pricing USING btree (is_active, effective_date DESC);


--
-- Name: idx_pricing_provider_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_provider_model ON public.model_pricing USING btree (provider, model_name);


--
-- Name: idx_pricing_rules_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rules_active ON public.pricing_rules USING btree (is_active);


--
-- Name: idx_pricing_rules_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rules_provider ON public.pricing_rules USING btree (provider);


--
-- Name: idx_pricing_rules_tier_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rules_tier_code ON public.pricing_rules USING btree (tier_code);


--
-- Name: idx_pricing_rules_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rules_type ON public.pricing_rules USING btree (rule_type);


--
-- Name: idx_pricing_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_tier ON public.model_pricing USING btree (model_tier);


--
-- Name: idx_purchases_addon; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_addon ON public.add_on_purchases USING btree (add_on_id);


--
-- Name: idx_purchases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_status ON public.add_on_purchases USING btree (status);


--
-- Name: idx_purchases_stripe_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_stripe_session ON public.add_on_purchases USING btree (stripe_session_id);


--
-- Name: idx_purchases_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_user ON public.add_on_purchases USING btree (user_id);


--
-- Name: idx_rate_limits_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_limits_expires ON public.rate_limits USING btree (expires_at);


--
-- Name: idx_rate_limits_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_limits_key ON public.rate_limits USING btree (api_key_id, window_type, window_start);


--
-- Name: idx_rbac_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rbac_audit_actor ON public.rbac_audit_log USING btree (actor_email);


--
-- Name: idx_rbac_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rbac_audit_created ON public.rbac_audit_log USING btree (created_at);


--
-- Name: idx_rbac_audit_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rbac_audit_event ON public.rbac_audit_log USING btree (event_type);


--
-- Name: idx_rbac_audit_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rbac_audit_target ON public.rbac_audit_log USING btree (target_user_email);


--
-- Name: idx_recommendations_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recommendations_org_status ON public.cost_recommendations USING btree (organization_id, status);


--
-- Name: idx_recommendations_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recommendations_priority ON public.cost_recommendations USING btree (priority_score DESC);


--
-- Name: idx_recommendations_savings; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recommendations_savings ON public.cost_recommendations USING btree (estimated_savings DESC);


--
-- Name: idx_recommendations_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recommendations_type ON public.cost_recommendations USING btree (recommendation_type);


--
-- Name: idx_recommendations_valid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recommendations_valid ON public.cost_recommendations USING btree (valid_until) WHERE ((status)::text = 'pending'::text);


--
-- Name: idx_resource_policies_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resource_policies_document ON public.resource_policies USING gin (policy_document);


--
-- Name: idx_resource_policies_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resource_policies_resource ON public.resource_policies USING btree (resource_id);


--
-- Name: idx_resource_policies_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resource_policies_type ON public.resource_policies USING btree (resource_type);


--
-- Name: idx_retention_data_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retention_data_type ON public.data_retention_policies USING btree (data_type);


--
-- Name: idx_retention_next_purge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retention_next_purge ON public.data_retention_policies USING btree (next_purge_at);


--
-- Name: idx_reviews_addon; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_addon ON public.add_on_reviews USING btree (add_on_id);


--
-- Name: idx_role_inheritance_child; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_inheritance_child ON public.role_inheritance USING btree (child_role_id);


--
-- Name: idx_role_inheritance_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_inheritance_parent ON public.role_inheritance USING btree (parent_role_id);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_permission ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_id);


--
-- Name: idx_saml_assertions_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_assertions_provider ON public.saml_assertions USING btree (provider_id);


--
-- Name: idx_saml_assertions_received; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_assertions_received ON public.saml_assertions USING btree (received_at);


--
-- Name: idx_saml_assertions_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_assertions_session ON public.saml_assertions USING btree (session_id);


--
-- Name: idx_saml_assertions_valid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_assertions_valid ON public.saml_assertions USING btree (is_valid);


--
-- Name: idx_saml_attr_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_attr_provider ON public.saml_attribute_mappings USING btree (provider_id);


--
-- Name: idx_saml_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_audit_created ON public.saml_audit_log USING btree (created_at);


--
-- Name: idx_saml_audit_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_audit_provider ON public.saml_audit_log USING btree (provider_id);


--
-- Name: idx_saml_audit_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_audit_type ON public.saml_audit_log USING btree (event_type);


--
-- Name: idx_saml_audit_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_audit_user ON public.saml_audit_log USING btree (user_id);


--
-- Name: idx_saml_providers_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_providers_active ON public.saml_providers USING btree (is_active);


--
-- Name: idx_saml_providers_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_providers_entity ON public.saml_providers USING btree (entity_id);


--
-- Name: idx_saml_providers_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_providers_org ON public.saml_providers USING btree (organization_id);


--
-- Name: idx_saml_sessions_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_sessions_active ON public.saml_sessions USING btree (is_active);


--
-- Name: idx_saml_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_sessions_expiry ON public.saml_sessions USING btree (session_expiry);


--
-- Name: idx_saml_sessions_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_sessions_provider ON public.saml_sessions USING btree (provider_id);


--
-- Name: idx_saml_sessions_saml_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_sessions_saml_id ON public.saml_sessions USING btree (saml_session_id);


--
-- Name: idx_saml_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saml_sessions_user ON public.saml_sessions USING btree (user_id);


--
-- Name: idx_security_incidents_detected; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_incidents_detected ON public.security_incidents USING btree (detected_at);


--
-- Name: idx_security_incidents_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_incidents_severity ON public.security_incidents USING btree (severity);


--
-- Name: idx_security_incidents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_incidents_status ON public.security_incidents USING btree (status);


--
-- Name: idx_security_incidents_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_incidents_type ON public.security_incidents USING btree (incident_type);


--
-- Name: idx_server_group_members_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_group_members_group ON public.server_group_members USING btree (group_id);


--
-- Name: idx_server_group_members_server; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_group_members_server ON public.server_group_members USING btree (server_id);


--
-- Name: idx_server_groups_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_groups_name ON public.server_groups USING btree (name);


--
-- Name: idx_server_groups_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_groups_org ON public.server_groups USING btree (organization_id);


--
-- Name: idx_server_health_server_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_health_server_time ON ONLY public.server_health_checks USING btree (server_id, "timestamp");


--
-- Name: idx_server_health_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_health_status ON ONLY public.server_health_checks USING btree (status, "timestamp");


--
-- Name: idx_server_metrics_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_metrics_period ON ONLY public.server_metrics_aggregated USING btree (period, "timestamp");


--
-- Name: idx_server_metrics_server_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_server_metrics_server_time ON ONLY public.server_metrics_aggregated USING btree (server_id, "timestamp");


--
-- Name: idx_smart_alert_models_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_smart_alert_models_device ON public.smart_alert_models USING btree (device_id);


--
-- Name: idx_smart_alert_models_metric; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_smart_alert_models_metric ON public.smart_alert_models USING btree (metric_name);


--
-- Name: idx_smart_alert_models_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_smart_alert_models_status ON public.smart_alert_models USING btree (status);


--
-- Name: idx_terraform_executions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_executions_status ON public.terraform_executions USING btree (status);


--
-- Name: idx_terraform_executions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_executions_type ON public.terraform_executions USING btree (execution_type);


--
-- Name: idx_terraform_executions_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_executions_workspace ON public.terraform_executions USING btree (workspace_id);


--
-- Name: idx_terraform_resources_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_resources_status ON public.terraform_resources USING btree (status);


--
-- Name: idx_terraform_resources_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_resources_type ON public.terraform_resources USING btree (resource_type);


--
-- Name: idx_terraform_resources_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_resources_workspace ON public.terraform_resources USING btree (workspace_id);


--
-- Name: idx_terraform_states_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_states_current ON public.terraform_states USING btree (workspace_id, is_current);


--
-- Name: idx_terraform_states_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_states_workspace ON public.terraform_states USING btree (workspace_id);


--
-- Name: idx_terraform_variables_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terraform_variables_workspace ON public.terraform_variables USING btree (workspace_id);


--
-- Name: idx_unique_default_per_app; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unique_default_per_app ON public.app_model_lists USING btree (app_identifier) WHERE (is_default = true);


--
-- Name: idx_usage_agg_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_agg_email ON public.usage_aggregates USING btree (email);


--
-- Name: idx_usage_agg_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_agg_period ON public.usage_aggregates USING btree (period_type, period_start);


--
-- Name: idx_usage_agg_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_agg_subscription ON public.usage_aggregates USING btree (subscription_id);


--
-- Name: idx_usage_events_api_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_events_api_key ON ONLY public.usage_events USING btree (api_key_id);


--
-- Name: idx_usage_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_events_created ON ONLY public.usage_events USING btree (created_at DESC);


--
-- Name: idx_usage_events_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_events_email ON ONLY public.usage_events USING btree (email);


--
-- Name: idx_usage_events_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_events_subscription ON ONLY public.usage_events USING btree (subscription_id);


--
-- Name: idx_usage_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_events_type ON ONLY public.usage_events USING btree (event_type);


--
-- Name: idx_user_api_keys_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_api_keys_active ON public.user_api_keys USING btree (is_active, expires_at);


--
-- Name: idx_user_api_keys_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_api_keys_prefix ON public.user_api_keys USING btree (key_prefix);


--
-- Name: idx_user_api_keys_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_api_keys_user_id ON public.user_api_keys USING btree (user_id);


--
-- Name: idx_user_byok_credits_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_byok_credits_active ON public.user_byok_credits USING btree (is_active);


--
-- Name: idx_user_byok_credits_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_byok_credits_tier ON public.user_byok_credits USING btree (tier_code);


--
-- Name: idx_user_byok_credits_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_byok_credits_user_id ON public.user_byok_credits USING btree (user_id);


--
-- Name: idx_user_credit_allocations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_credit_allocations_active ON public.user_credit_allocations USING btree (is_active);


--
-- Name: idx_user_credit_allocations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_credit_allocations_org_id ON public.user_credit_allocations USING btree (org_id);


--
-- Name: idx_user_credit_allocations_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_credit_allocations_user_id ON public.user_credit_allocations USING btree (user_id);


--
-- Name: idx_user_llm_settings_power; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_llm_settings_power ON public.user_llm_settings USING btree (power_level);


--
-- Name: idx_user_prefs_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_prefs_favorite ON public.user_model_preferences USING btree (user_id, is_favorite) WHERE (is_favorite = true);


--
-- Name: idx_user_prefs_hidden; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_prefs_hidden ON public.user_model_preferences USING btree (user_id, is_hidden) WHERE (is_hidden = true);


--
-- Name: idx_user_prefs_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_prefs_model ON public.user_model_preferences USING btree (model_id);


--
-- Name: idx_user_prefs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_prefs_user ON public.user_model_preferences USING btree (user_id);


--
-- Name: idx_user_provider_keys_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_provider_keys_enabled ON public.user_provider_keys USING btree (user_id, enabled);


--
-- Name: idx_user_provider_keys_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_provider_keys_user ON public.user_provider_keys USING btree (user_id);


--
-- Name: idx_user_roles_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_email ON public.user_roles USING btree (user_email);


--
-- Name: idx_user_roles_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_expires ON public.user_roles USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_user_roles_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_org ON public.user_roles USING btree (organization_id);


--
-- Name: idx_user_roles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_role ON public.user_roles USING btree (role_id);


--
-- Name: idx_webhooks_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhooks_enabled ON public.webhooks USING btree (enabled);


--
-- Name: idx_webhooks_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhooks_organization_id ON public.webhooks USING btree (organization_id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_organization_id ON public.audit_logs USING btree (organization_id);


--
-- Name: ix_audit_logs_resource_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_resource_type ON public.audit_logs USING btree (resource_type);


--
-- Name: ix_audit_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_status ON public.audit_logs USING btree (status);


--
-- Name: ix_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_timestamp ON public.audit_logs USING btree ("timestamp");


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_cloudflare_dns_records_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_dns_records_name ON public.cloudflare_dns_records USING btree (name);


--
-- Name: ix_cloudflare_dns_records_record_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cloudflare_dns_records_record_id ON public.cloudflare_dns_records USING btree (record_id);


--
-- Name: ix_cloudflare_dns_records_record_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_dns_records_record_type ON public.cloudflare_dns_records USING btree (record_type);


--
-- Name: ix_cloudflare_dns_records_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_dns_records_zone_id ON public.cloudflare_dns_records USING btree (zone_id);


--
-- Name: ix_cloudflare_domains_domain_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cloudflare_domains_domain_name ON public.cloudflare_domains USING btree (domain_name);


--
-- Name: ix_cloudflare_domains_expiration_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_domains_expiration_date ON public.cloudflare_domains USING btree (expiration_date);


--
-- Name: ix_cloudflare_domains_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_domains_user_id ON public.cloudflare_domains USING btree (user_id);


--
-- Name: ix_cloudflare_firewall_rules_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_firewall_rules_enabled ON public.cloudflare_firewall_rules USING btree (enabled);


--
-- Name: ix_cloudflare_firewall_rules_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cloudflare_firewall_rules_rule_id ON public.cloudflare_firewall_rules USING btree (rule_id);


--
-- Name: ix_cloudflare_firewall_rules_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_firewall_rules_zone_id ON public.cloudflare_firewall_rules USING btree (zone_id);


--
-- Name: ix_cloudflare_zones_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_zones_status ON public.cloudflare_zones USING btree (status);


--
-- Name: ix_cloudflare_zones_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cloudflare_zones_zone_id ON public.cloudflare_zones USING btree (zone_id);


--
-- Name: ix_cloudflare_zones_zone_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloudflare_zones_zone_name ON public.cloudflare_zones USING btree (zone_name);


--
-- Name: ix_invoices_issued_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoices_issued_at ON public.invoices USING btree (issued_at DESC);


--
-- Name: ix_invoices_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoices_status ON public.invoices USING btree (status);


--
-- Name: ix_invoices_stripe_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_invoices_stripe_invoice_id ON public.invoices USING btree (stripe_invoice_id);


--
-- Name: ix_invoices_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoices_subscription_id ON public.invoices USING btree (subscription_id);


--
-- Name: ix_migration_jobs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_migration_jobs_created_at ON public.migration_jobs USING btree (created_at);


--
-- Name: ix_migration_jobs_domain_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_migration_jobs_domain_name ON public.migration_jobs USING btree (domain_name);


--
-- Name: ix_migration_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_migration_jobs_status ON public.migration_jobs USING btree (status);


--
-- Name: ix_namecheap_domains_domain_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_namecheap_domains_domain_name ON public.namecheap_domains USING btree (domain_name);


--
-- Name: ix_namecheap_domains_expiration_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_namecheap_domains_expiration_date ON public.namecheap_domains USING btree (expiration_date);


--
-- Name: ix_namecheap_domains_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_namecheap_domains_user_id ON public.namecheap_domains USING btree (user_id);


--
-- Name: ix_organization_invitations_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organization_invitations_email ON public.organization_invitations USING btree (email);


--
-- Name: ix_organization_invitations_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organization_invitations_expires_at ON public.organization_invitations USING btree (expires_at);


--
-- Name: ix_organization_invitations_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organization_invitations_organization_id ON public.organization_invitations USING btree (organization_id);


--
-- Name: ix_organization_invitations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organization_invitations_status ON public.organization_invitations USING btree (status);


--
-- Name: ix_organization_invitations_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organization_invitations_token ON public.organization_invitations USING btree (token);


--
-- Name: ix_organization_members_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organization_members_organization_id ON public.organization_members USING btree (organization_id);


--
-- Name: ix_organization_members_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organization_members_user_id ON public.organization_members USING btree (user_id);


--
-- Name: ix_organizations_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organizations_created_at ON public.organizations USING btree (created_at);


--
-- Name: ix_organizations_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_organizations_is_active ON public.organizations USING btree (is_active);


--
-- Name: ix_organizations_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_slug ON public.organizations USING btree (slug);


--
-- Name: ix_organizations_stripe_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_organizations_stripe_customer_id ON public.organizations USING btree (stripe_customer_id);


--
-- Name: ix_user_subscriptions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_subscriptions_email ON public.user_subscriptions USING btree (email);


--
-- Name: ix_user_subscriptions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_subscriptions_status ON public.user_subscriptions USING btree (status);


--
-- Name: ix_user_subscriptions_stripe_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_subscriptions_stripe_customer_id ON public.user_subscriptions USING btree (stripe_customer_id);


--
-- Name: ix_user_subscriptions_stripe_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_subscriptions_stripe_subscription_id ON public.user_subscriptions USING btree (stripe_subscription_id);


--
-- Name: server_health_checks_2026_01_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_01_server_id_timestamp_idx ON public.server_health_checks_2026_01 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_01_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_01_status_timestamp_idx ON public.server_health_checks_2026_01 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_02_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_02_server_id_timestamp_idx ON public.server_health_checks_2026_02 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_02_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_02_status_timestamp_idx ON public.server_health_checks_2026_02 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_03_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_03_server_id_timestamp_idx ON public.server_health_checks_2026_03 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_03_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_03_status_timestamp_idx ON public.server_health_checks_2026_03 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_04_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_04_server_id_timestamp_idx ON public.server_health_checks_2026_04 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_04_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_04_status_timestamp_idx ON public.server_health_checks_2026_04 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_05_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_05_server_id_timestamp_idx ON public.server_health_checks_2026_05 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_05_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_05_status_timestamp_idx ON public.server_health_checks_2026_05 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_06_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_06_server_id_timestamp_idx ON public.server_health_checks_2026_06 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_06_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_06_status_timestamp_idx ON public.server_health_checks_2026_06 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_07_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_07_server_id_timestamp_idx ON public.server_health_checks_2026_07 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_07_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_07_status_timestamp_idx ON public.server_health_checks_2026_07 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_08_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_08_server_id_timestamp_idx ON public.server_health_checks_2026_08 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_08_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_08_status_timestamp_idx ON public.server_health_checks_2026_08 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_09_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_09_server_id_timestamp_idx ON public.server_health_checks_2026_09 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_09_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_09_status_timestamp_idx ON public.server_health_checks_2026_09 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_10_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_10_server_id_timestamp_idx ON public.server_health_checks_2026_10 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_10_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_10_status_timestamp_idx ON public.server_health_checks_2026_10 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_11_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_11_server_id_timestamp_idx ON public.server_health_checks_2026_11 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_11_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_11_status_timestamp_idx ON public.server_health_checks_2026_11 USING btree (status, "timestamp");


--
-- Name: server_health_checks_2026_12_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_12_server_id_timestamp_idx ON public.server_health_checks_2026_12 USING btree (server_id, "timestamp");


--
-- Name: server_health_checks_2026_12_status_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_health_checks_2026_12_status_timestamp_idx ON public.server_health_checks_2026_12 USING btree (status, "timestamp");


--
-- Name: server_metrics_aggregated_2026_01_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_01_period_timestamp_idx ON public.server_metrics_aggregated_2026_01 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_01_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_01_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_01 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_02_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_02_period_timestamp_idx ON public.server_metrics_aggregated_2026_02 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_02_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_02_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_02 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_03_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_03_period_timestamp_idx ON public.server_metrics_aggregated_2026_03 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_03_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_03_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_03 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_04_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_04_period_timestamp_idx ON public.server_metrics_aggregated_2026_04 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_04_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_04_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_04 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_05_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_05_period_timestamp_idx ON public.server_metrics_aggregated_2026_05 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_05_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_05_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_05 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_06_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_06_period_timestamp_idx ON public.server_metrics_aggregated_2026_06 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_06_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_06_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_06 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_07_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_07_period_timestamp_idx ON public.server_metrics_aggregated_2026_07 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_07_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_07_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_07 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_08_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_08_period_timestamp_idx ON public.server_metrics_aggregated_2026_08 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_08_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_08_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_08 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_09_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_09_period_timestamp_idx ON public.server_metrics_aggregated_2026_09 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_09_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_09_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_09 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_10_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_10_period_timestamp_idx ON public.server_metrics_aggregated_2026_10 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_10_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_10_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_10 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_11_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_11_period_timestamp_idx ON public.server_metrics_aggregated_2026_11 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_11_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_11_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_11 USING btree (server_id, "timestamp");


--
-- Name: server_metrics_aggregated_2026_12_period_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_12_period_timestamp_idx ON public.server_metrics_aggregated_2026_12 USING btree (period, "timestamp");


--
-- Name: server_metrics_aggregated_2026_12_server_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_metrics_aggregated_2026_12_server_id_timestamp_idx ON public.server_metrics_aggregated_2026_12 USING btree (server_id, "timestamp");


--
-- Name: usage_events_2026_01_api_key_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_01_api_key_id_idx ON public.usage_events_2026_01 USING btree (api_key_id);


--
-- Name: usage_events_2026_01_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_01_created_at_idx ON public.usage_events_2026_01 USING btree (created_at DESC);


--
-- Name: usage_events_2026_01_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_01_email_idx ON public.usage_events_2026_01 USING btree (email);


--
-- Name: usage_events_2026_01_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_01_event_type_idx ON public.usage_events_2026_01 USING btree (event_type);


--
-- Name: usage_events_2026_01_subscription_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_01_subscription_id_idx ON public.usage_events_2026_01 USING btree (subscription_id);


--
-- Name: usage_events_2026_02_api_key_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_02_api_key_id_idx ON public.usage_events_2026_02 USING btree (api_key_id);


--
-- Name: usage_events_2026_02_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_02_created_at_idx ON public.usage_events_2026_02 USING btree (created_at DESC);


--
-- Name: usage_events_2026_02_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_02_email_idx ON public.usage_events_2026_02 USING btree (email);


--
-- Name: usage_events_2026_02_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_02_event_type_idx ON public.usage_events_2026_02 USING btree (event_type);


--
-- Name: usage_events_2026_02_subscription_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_events_2026_02_subscription_id_idx ON public.usage_events_2026_02 USING btree (subscription_id);


--
-- Name: k8s_pods_2026_01_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_01_pkey;


--
-- Name: k8s_pods_2026_02_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_02_pkey;


--
-- Name: k8s_pods_2026_03_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_03_pkey;


--
-- Name: k8s_pods_2026_04_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_04_pkey;


--
-- Name: k8s_pods_2026_05_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_05_pkey;


--
-- Name: k8s_pods_2026_06_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_06_pkey;


--
-- Name: k8s_pods_2026_07_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_07_pkey;


--
-- Name: k8s_pods_2026_08_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_08_pkey;


--
-- Name: k8s_pods_2026_09_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_09_pkey;


--
-- Name: k8s_pods_2026_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_10_pkey;


--
-- Name: k8s_pods_2026_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_11_pkey;


--
-- Name: k8s_pods_2026_12_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_pods_pkey ATTACH PARTITION public.k8s_pods_2026_12_pkey;


--
-- Name: k8s_resource_metrics_2026_01_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_01_pkey;


--
-- Name: k8s_resource_metrics_2026_02_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_02_pkey;


--
-- Name: k8s_resource_metrics_2026_03_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_03_pkey;


--
-- Name: k8s_resource_metrics_2026_04_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_04_pkey;


--
-- Name: k8s_resource_metrics_2026_05_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_05_pkey;


--
-- Name: k8s_resource_metrics_2026_06_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_06_pkey;


--
-- Name: k8s_resource_metrics_2026_07_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_07_pkey;


--
-- Name: k8s_resource_metrics_2026_08_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_08_pkey;


--
-- Name: k8s_resource_metrics_2026_09_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_09_pkey;


--
-- Name: k8s_resource_metrics_2026_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_10_pkey;


--
-- Name: k8s_resource_metrics_2026_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_11_pkey;


--
-- Name: k8s_resource_metrics_2026_12_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.k8s_resource_metrics_pkey ATTACH PARTITION public.k8s_resource_metrics_2026_12_pkey;


--
-- Name: server_health_checks_2026_01_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_01_pkey;


--
-- Name: server_health_checks_2026_01_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_01_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_01_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_01_status_timestamp_idx;


--
-- Name: server_health_checks_2026_02_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_02_pkey;


--
-- Name: server_health_checks_2026_02_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_02_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_02_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_02_status_timestamp_idx;


--
-- Name: server_health_checks_2026_03_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_03_pkey;


--
-- Name: server_health_checks_2026_03_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_03_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_03_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_03_status_timestamp_idx;


--
-- Name: server_health_checks_2026_04_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_04_pkey;


--
-- Name: server_health_checks_2026_04_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_04_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_04_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_04_status_timestamp_idx;


--
-- Name: server_health_checks_2026_05_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_05_pkey;


--
-- Name: server_health_checks_2026_05_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_05_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_05_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_05_status_timestamp_idx;


--
-- Name: server_health_checks_2026_06_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_06_pkey;


--
-- Name: server_health_checks_2026_06_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_06_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_06_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_06_status_timestamp_idx;


--
-- Name: server_health_checks_2026_07_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_07_pkey;


--
-- Name: server_health_checks_2026_07_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_07_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_07_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_07_status_timestamp_idx;


--
-- Name: server_health_checks_2026_08_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_08_pkey;


--
-- Name: server_health_checks_2026_08_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_08_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_08_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_08_status_timestamp_idx;


--
-- Name: server_health_checks_2026_09_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_09_pkey;


--
-- Name: server_health_checks_2026_09_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_09_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_09_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_09_status_timestamp_idx;


--
-- Name: server_health_checks_2026_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_10_pkey;


--
-- Name: server_health_checks_2026_10_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_10_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_10_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_10_status_timestamp_idx;


--
-- Name: server_health_checks_2026_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_11_pkey;


--
-- Name: server_health_checks_2026_11_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_11_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_11_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_11_status_timestamp_idx;


--
-- Name: server_health_checks_2026_12_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_health_checks_pkey ATTACH PARTITION public.server_health_checks_2026_12_pkey;


--
-- Name: server_health_checks_2026_12_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_server_time ATTACH PARTITION public.server_health_checks_2026_12_server_id_timestamp_idx;


--
-- Name: server_health_checks_2026_12_status_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_health_status ATTACH PARTITION public.server_health_checks_2026_12_status_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_01_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_01_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_01_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_01_pkey;


--
-- Name: server_metrics_aggregated_2026_01_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_01_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_02_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_02_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_02_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_02_pkey;


--
-- Name: server_metrics_aggregated_2026_02_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_02_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_03_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_03_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_03_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_03_pkey;


--
-- Name: server_metrics_aggregated_2026_03_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_03_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_04_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_04_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_04_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_04_pkey;


--
-- Name: server_metrics_aggregated_2026_04_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_04_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_05_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_05_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_05_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_05_pkey;


--
-- Name: server_metrics_aggregated_2026_05_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_05_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_06_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_06_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_06_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_06_pkey;


--
-- Name: server_metrics_aggregated_2026_06_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_06_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_07_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_07_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_07_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_07_pkey;


--
-- Name: server_metrics_aggregated_2026_07_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_07_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_08_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_08_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_08_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_08_pkey;


--
-- Name: server_metrics_aggregated_2026_08_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_08_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_09_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_09_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_09_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_09_pkey;


--
-- Name: server_metrics_aggregated_2026_09_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_09_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_10_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_10_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_10_pkey;


--
-- Name: server_metrics_aggregated_2026_10_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_10_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_11_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_11_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_11_pkey;


--
-- Name: server_metrics_aggregated_2026_11_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_11_server_id_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_12_period_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_period ATTACH PARTITION public.server_metrics_aggregated_2026_12_period_timestamp_idx;


--
-- Name: server_metrics_aggregated_2026_12_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.server_metrics_aggregated_pkey ATTACH PARTITION public.server_metrics_aggregated_2026_12_pkey;


--
-- Name: server_metrics_aggregated_2026_12_server_id_timestamp_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_server_metrics_server_time ATTACH PARTITION public.server_metrics_aggregated_2026_12_server_id_timestamp_idx;


--
-- Name: usage_events_2026_01_api_key_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_api_key ATTACH PARTITION public.usage_events_2026_01_api_key_id_idx;


--
-- Name: usage_events_2026_01_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_created ATTACH PARTITION public.usage_events_2026_01_created_at_idx;


--
-- Name: usage_events_2026_01_email_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_email ATTACH PARTITION public.usage_events_2026_01_email_idx;


--
-- Name: usage_events_2026_01_event_type_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_type ATTACH PARTITION public.usage_events_2026_01_event_type_idx;


--
-- Name: usage_events_2026_01_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.usage_events_pkey ATTACH PARTITION public.usage_events_2026_01_pkey;


--
-- Name: usage_events_2026_01_subscription_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_subscription ATTACH PARTITION public.usage_events_2026_01_subscription_id_idx;


--
-- Name: usage_events_2026_02_api_key_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_api_key ATTACH PARTITION public.usage_events_2026_02_api_key_id_idx;


--
-- Name: usage_events_2026_02_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_created ATTACH PARTITION public.usage_events_2026_02_created_at_idx;


--
-- Name: usage_events_2026_02_email_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_email ATTACH PARTITION public.usage_events_2026_02_email_idx;


--
-- Name: usage_events_2026_02_event_type_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_type ATTACH PARTITION public.usage_events_2026_02_event_type_idx;


--
-- Name: usage_events_2026_02_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.usage_events_pkey ATTACH PARTITION public.usage_events_2026_02_pkey;


--
-- Name: usage_events_2026_02_subscription_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_usage_events_subscription ATTACH PARTITION public.usage_events_2026_02_subscription_id_idx;


--
-- Name: terraform_workspace_summary _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.terraform_workspace_summary AS
 SELECT w.workspace_id,
    w.name,
    w.environment,
    w.cloud_provider,
    w.locked,
    w.last_apply_at,
    count(DISTINCT r.resource_id) AS resource_count,
    count(DISTINCT
        CASE
            WHEN (r.status = 'active'::text) THEN r.resource_id
            ELSE NULL::uuid
        END) AS active_resources,
    count(DISTINCT d.drift_id) AS drift_count,
    max(e.triggered_at) AS last_execution_at
   FROM (((public.terraform_workspaces w
     LEFT JOIN public.terraform_resources r ON ((w.workspace_id = r.workspace_id)))
     LEFT JOIN public.terraform_drift_detections d ON (((w.workspace_id = d.workspace_id) AND (d.resolved = false))))
     LEFT JOIN public.terraform_executions e ON ((w.workspace_id = e.workspace_id)))
  GROUP BY w.workspace_id;


--
-- Name: organization_branding organization_branding_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER organization_branding_updated BEFORE UPDATE ON public.organization_branding FOR EACH ROW EXECUTE FUNCTION public.update_organization_branding_timestamp();


--
-- Name: app_model_lists trigger_app_model_lists_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_app_model_lists_updated BEFORE UPDATE ON public.app_model_lists FOR EACH ROW EXECUTE FUNCTION public.update_model_lists_updated_at();


--
-- Name: app_model_list_items trigger_model_list_items_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_model_list_items_updated BEFORE UPDATE ON public.app_model_list_items FOR EACH ROW EXECUTE FUNCTION public.update_model_lists_updated_at();


--
-- Name: user_model_preferences trigger_user_prefs_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_user_prefs_updated BEFORE UPDATE ON public.user_model_preferences FOR EACH ROW EXECUTE FUNCTION public.update_model_lists_updated_at();


--
-- Name: add_on_purchases add_on_purchases_add_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_purchases
    ADD CONSTRAINT add_on_purchases_add_on_id_fkey FOREIGN KEY (add_on_id) REFERENCES public.add_ons(id) ON DELETE CASCADE;


--
-- Name: add_on_reviews add_on_reviews_add_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_on_reviews
    ADD CONSTRAINT add_on_reviews_add_on_id_fkey FOREIGN KEY (add_on_id) REFERENCES public.add_ons(id) ON DELETE CASCADE;


--
-- Name: add_ons add_ons_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.add_ons
    ADD CONSTRAINT add_ons_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.add_on_categories(id) ON DELETE SET NULL;


--
-- Name: anomaly_detections anomaly_detections_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anomaly_detections
    ADD CONSTRAINT anomaly_detections_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.smart_alert_models(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.user_subscriptions(id) ON DELETE CASCADE;


--
-- Name: app_model_list_items app_model_list_items_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_model_list_items
    ADD CONSTRAINT app_model_list_items_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.app_model_lists(id) ON DELETE CASCADE;


--
-- Name: budgets budgets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cart_items cart_items_add_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_add_on_id_fkey FOREIGN KEY (add_on_id) REFERENCES public.add_ons(id) ON DELETE CASCADE;


--
-- Name: cloudflare_dns_records cloudflare_dns_records_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloudflare_dns_records
    ADD CONSTRAINT cloudflare_dns_records_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES public.cloudflare_zones(zone_id) ON DELETE CASCADE;


--
-- Name: cloudflare_firewall_rules cloudflare_firewall_rules_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloudflare_firewall_rules
    ADD CONSTRAINT cloudflare_firewall_rules_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES public.cloudflare_zones(zone_id) ON DELETE CASCADE;


--
-- Name: compliance_evidence compliance_evidence_control_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_evidence
    ADD CONSTRAINT compliance_evidence_control_id_fkey FOREIGN KEY (control_id) REFERENCES public.compliance_controls(control_id);


--
-- Name: compliance_schedules compliance_schedules_control_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_schedules
    ADD CONSTRAINT compliance_schedules_control_id_fkey FOREIGN KEY (control_id) REFERENCES public.compliance_controls(control_id);


--
-- Name: cost_analysis cost_analysis_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_analysis
    ADD CONSTRAINT cost_analysis_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cost_forecasts cost_forecasts_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_forecasts
    ADD CONSTRAINT cost_forecasts_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budgets(id) ON DELETE CASCADE;


--
-- Name: cost_forecasts cost_forecasts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_forecasts
    ADD CONSTRAINT cost_forecasts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: cost_recommendations cost_recommendations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_recommendations
    ADD CONSTRAINT cost_recommendations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: credit_usage_attribution credit_usage_attribution_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_usage_attribution
    ADD CONSTRAINT credit_usage_attribution_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: email_history email_history_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_history
    ADD CONSTRAINT email_history_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.email_providers(id) ON DELETE SET NULL;


--
-- Name: branding_assets fk_asset_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_assets
    ADD CONSTRAINT fk_asset_org FOREIGN KEY (org_id) REFERENCES public.organization_branding(org_id) ON DELETE CASCADE;


--
-- Name: branding_tier_limits fk_branding_tier; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_tier_limits
    ADD CONSTRAINT fk_branding_tier FOREIGN KEY (tier_code) REFERENCES public.subscription_tiers(tier_code) ON DELETE CASCADE;


--
-- Name: invoices fk_invoices_subscription_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT fk_invoices_subscription_id FOREIGN KEY (subscription_id) REFERENCES public.user_subscriptions(id) ON DELETE CASCADE;


--
-- Name: k8s_clusters fk_k8s_cluster_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_clusters
    ADD CONSTRAINT fk_k8s_cluster_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: k8s_cost_attribution fk_k8s_cost_cluster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_cost_attribution
    ADD CONSTRAINT fk_k8s_cost_cluster FOREIGN KEY (cluster_id) REFERENCES public.k8s_clusters(id) ON DELETE CASCADE;


--
-- Name: k8s_cost_attribution fk_k8s_cost_ns; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_cost_attribution
    ADD CONSTRAINT fk_k8s_cost_ns FOREIGN KEY (namespace_id) REFERENCES public.k8s_namespaces(id) ON DELETE CASCADE;


--
-- Name: k8s_deployments fk_k8s_deploy_cluster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_deployments
    ADD CONSTRAINT fk_k8s_deploy_cluster FOREIGN KEY (cluster_id) REFERENCES public.k8s_clusters(id) ON DELETE CASCADE;


--
-- Name: k8s_deployments fk_k8s_deploy_ns; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_deployments
    ADD CONSTRAINT fk_k8s_deploy_ns FOREIGN KEY (namespace_id) REFERENCES public.k8s_namespaces(id) ON DELETE CASCADE;


--
-- Name: k8s_helm_releases fk_k8s_helm_cluster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_helm_releases
    ADD CONSTRAINT fk_k8s_helm_cluster FOREIGN KEY (cluster_id) REFERENCES public.k8s_clusters(id) ON DELETE CASCADE;


--
-- Name: k8s_helm_releases fk_k8s_helm_ns; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_helm_releases
    ADD CONSTRAINT fk_k8s_helm_ns FOREIGN KEY (namespace_id) REFERENCES public.k8s_namespaces(id) ON DELETE CASCADE;


--
-- Name: k8s_nodes fk_k8s_node_cluster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_nodes
    ADD CONSTRAINT fk_k8s_node_cluster FOREIGN KEY (cluster_id) REFERENCES public.k8s_clusters(id) ON DELETE CASCADE;


--
-- Name: k8s_namespaces fk_k8s_ns_cluster; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.k8s_namespaces
    ADD CONSTRAINT fk_k8s_ns_cluster FOREIGN KEY (cluster_id) REFERENCES public.k8s_clusters(id) ON DELETE CASCADE;


--
-- Name: organization_branding fk_org_tier; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT fk_org_tier FOREIGN KEY (tier_code) REFERENCES public.subscription_tiers(tier_code) ON DELETE SET NULL;


--
-- Name: user_subscriptions fk_user_subscriptions_tier_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT fk_user_subscriptions_tier_id FOREIGN KEY (tier_id) REFERENCES public.subscription_tiers(id) ON DELETE RESTRICT;


--
-- Name: invite_code_redemptions invite_code_redemptions_invite_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_code_redemptions
    ADD CONSTRAINT invite_code_redemptions_invite_code_id_fkey FOREIGN KEY (invite_code_id) REFERENCES public.invite_codes(id) ON DELETE CASCADE;


--
-- Name: llm_models llm_models_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id) ON DELETE CASCADE;


--
-- Name: llm_usage_logs llm_usage_logs_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_usage_logs
    ADD CONSTRAINT llm_usage_logs_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id);


--
-- Name: managed_servers managed_servers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_servers
    ADD CONSTRAINT managed_servers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: model_access_audit model_access_audit_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_access_audit
    ADD CONSTRAINT model_access_audit_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.app_model_lists(id) ON DELETE SET NULL;


--
-- Name: org_billing_history org_billing_history_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_billing_history
    ADD CONSTRAINT org_billing_history_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_credit_pools organization_credit_pools_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_credit_pools
    ADD CONSTRAINT organization_credit_pools_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_members organization_members_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_subscriptions organization_subscriptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_subscriptions
    ADD CONSTRAINT organization_subscriptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: payment_dunning payment_dunning_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_dunning
    ADD CONSTRAINT payment_dunning_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.user_subscriptions(id) ON DELETE CASCADE;


--
-- Name: rate_limits rate_limits_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id) ON DELETE CASCADE;


--
-- Name: role_inheritance role_inheritance_child_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_inheritance
    ADD CONSTRAINT role_inheritance_child_role_id_fkey FOREIGN KEY (child_role_id) REFERENCES public.custom_roles(id) ON DELETE CASCADE;


--
-- Name: role_inheritance role_inheritance_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_inheritance
    ADD CONSTRAINT role_inheritance_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES public.custom_roles(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.custom_roles(id) ON DELETE CASCADE;


--
-- Name: saml_assertions saml_assertions_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_assertions
    ADD CONSTRAINT saml_assertions_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.saml_providers(provider_id) ON DELETE CASCADE;


--
-- Name: saml_assertions saml_assertions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_assertions
    ADD CONSTRAINT saml_assertions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.saml_sessions(session_id) ON DELETE SET NULL;


--
-- Name: saml_attribute_mappings saml_attribute_mappings_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_attribute_mappings
    ADD CONSTRAINT saml_attribute_mappings_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.saml_providers(provider_id) ON DELETE CASCADE;


--
-- Name: saml_audit_log saml_audit_log_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_audit_log
    ADD CONSTRAINT saml_audit_log_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.saml_providers(provider_id) ON DELETE SET NULL;


--
-- Name: saml_audit_log saml_audit_log_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_audit_log
    ADD CONSTRAINT saml_audit_log_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.saml_sessions(session_id) ON DELETE SET NULL;


--
-- Name: saml_sessions saml_sessions_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_sessions
    ADD CONSTRAINT saml_sessions_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.saml_providers(provider_id) ON DELETE CASCADE;


--
-- Name: savings_opportunities savings_opportunities_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.savings_opportunities
    ADD CONSTRAINT savings_opportunities_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: server_group_members server_group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_group_members
    ADD CONSTRAINT server_group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.server_groups(id) ON DELETE CASCADE;


--
-- Name: server_group_members server_group_members_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_group_members
    ADD CONSTRAINT server_group_members_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.managed_servers(id) ON DELETE CASCADE;


--
-- Name: server_groups server_groups_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_groups
    ADD CONSTRAINT server_groups_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: server_health_checks server_health_checks_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.server_health_checks
    ADD CONSTRAINT server_health_checks_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.managed_servers(id) ON DELETE CASCADE;


--
-- Name: server_metrics_aggregated server_metrics_aggregated_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.server_metrics_aggregated
    ADD CONSTRAINT server_metrics_aggregated_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.managed_servers(id) ON DELETE CASCADE;


--
-- Name: terraform_drift_detections terraform_drift_detections_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_drift_detections
    ADD CONSTRAINT terraform_drift_detections_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.terraform_resources(resource_id) ON DELETE CASCADE;


--
-- Name: terraform_drift_detections terraform_drift_detections_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_drift_detections
    ADD CONSTRAINT terraform_drift_detections_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.terraform_workspaces(workspace_id) ON DELETE CASCADE;


--
-- Name: terraform_executions terraform_executions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_executions
    ADD CONSTRAINT terraform_executions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.terraform_workspaces(workspace_id) ON DELETE CASCADE;


--
-- Name: terraform_resources terraform_resources_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_resources
    ADD CONSTRAINT terraform_resources_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.terraform_states(state_id) ON DELETE CASCADE;


--
-- Name: terraform_resources terraform_resources_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_resources
    ADD CONSTRAINT terraform_resources_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.terraform_workspaces(workspace_id) ON DELETE CASCADE;


--
-- Name: terraform_states terraform_states_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_states
    ADD CONSTRAINT terraform_states_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.terraform_workspaces(workspace_id) ON DELETE CASCADE;


--
-- Name: terraform_variables terraform_variables_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terraform_variables
    ADD CONSTRAINT terraform_variables_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.terraform_workspaces(workspace_id) ON DELETE CASCADE;


--
-- Name: tier_features tier_features_tier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tier_features
    ADD CONSTRAINT tier_features_tier_id_fkey FOREIGN KEY (tier_id) REFERENCES public.subscription_tiers(id) ON DELETE CASCADE;


--
-- Name: usage_aggregates usage_aggregates_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_aggregates
    ADD CONSTRAINT usage_aggregates_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id) ON DELETE SET NULL;


--
-- Name: usage_aggregates usage_aggregates_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_aggregates
    ADD CONSTRAINT usage_aggregates_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.user_subscriptions(id) ON DELETE CASCADE;


--
-- Name: usage_events usage_events_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.usage_events
    ADD CONSTRAINT usage_events_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id) ON DELETE CASCADE;


--
-- Name: usage_events usage_events_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.usage_events
    ADD CONSTRAINT usage_events_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.user_subscriptions(id) ON DELETE CASCADE;


--
-- Name: user_credit_allocations user_credit_allocations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credit_allocations
    ADD CONSTRAINT user_credit_allocations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.custom_roles(id) ON DELETE CASCADE;


--
-- Name: workspace_credentials workspace_credentials_credential_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_credentials
    ADD CONSTRAINT workspace_credentials_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES public.cloud_credentials(credential_id) ON DELETE CASCADE;


--
-- Name: workspace_credentials workspace_credentials_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_credentials
    ADD CONSTRAINT workspace_credentials_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.terraform_workspaces(workspace_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict BIvEkEgXBMpf9W9R7TpA72ups0jyrq2NrvTSGgDUXhXmV5R2FSShuSy2OtUdbvc

